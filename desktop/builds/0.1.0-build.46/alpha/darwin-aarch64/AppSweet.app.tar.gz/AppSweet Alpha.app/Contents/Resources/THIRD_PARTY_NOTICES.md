# AppSweet desktop third-party notices

Generated deterministically from the resolved Rust and JavaScript dependency graphs of the
Apple Silicon desktop bundle, including its Sweetheart Local worker, mistral.rs runtime and
read-aloud speech worker.

## Rust dependencies

## adler2 2.0.1

- Licence: `0BSD OR MIT OR Apache-2.0`
- Source: https://github.com/oyvindln/adler2

## aead 0.5.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## aegis 0.9.12

- Licence: `MIT`
- Source: https://github.com/jedisct1/rust-aegis

## aes 0.8.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/block-ciphers

## aes-gcm 0.10.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/AEADs

## ahash 0.8.12

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/tkaitchuck/ahash

## aho-corasick 1.1.4

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/aho-corasick

## aho-corasick 1.1.5

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/aho-corasick

## akin 0.4.0

- Licence: `MIT`
- Source: https://github.com/lyonsyonii/akin

## aligned 0.4.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-embedded-community/aligned

## aligned-vec 0.6.4

- Licence: `MIT`
- Source: https://github.com/sarah-ek/aligned-vec/

## alloc-no-stdlib 3.0.0

- Licence: `BSD-3-Clause`
- Source: https://github.com/dropbox/rust-alloc-no-stdlib

## alloc-stdlib 0.3.0

- Licence: `BSD-3-Clause`
- Source: https://github.com/dropbox/rust-alloc-no-stdlib

## allocator-api2 0.2.21

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/zakarumych/allocator-api2

## allocator-api2 0.4.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/zakarumych/allocator-api2

## annotate-snippets 0.12.16

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/annotate-snippets-rs

## anstream 1.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-cli/anstyle.git

## anstyle 1.0.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-cli/anstyle.git

## anstyle-parse 1.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-cli/anstyle.git

## anstyle-query 1.1.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-cli/anstyle.git

## anyhow 1.0.103

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/anyhow

## anyhow 1.0.104

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/anyhow

## apodize 1.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/snd/apodize.git

## apple-native-keyring-store 1.0.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/open-source-cooperative/apple-native-keyring-store.git

## approx 0.5.1

- Licence: `Apache-2.0`
- Source: https://github.com/brendanzab/approx

## arc-swap 1.9.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/vorner/arc-swap

## arg_enum_proc_macro 0.3.4

- Licence: `MIT`
- Source: https://github.com/lu-zero/arg_enum_proc_macro

## aristo 0.4.1

- Licence: `MIT`
- Source: https://github.com/aretta-ai/aristo

## aristo-macros 0.4.1

- Licence: `MIT`
- Source: https://github.com/aretta-ai/aristo

## arraydeque 0.5.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/andylokandy/arraydeque

## arrayref 0.3.9

- Licence: `BSD-2-Clause`
- Source: https://github.com/droundy/arrayref

## arrayvec 0.7.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/bluss/arrayvec

## as-any 0.3.2

- Licence: `MIT OR Apache-2.0`
- Source: https://codeberg.org/fogti/as-any

## as-slice 0.2.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/japaric/as-slice

## async-lock 3.4.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/async-lock

## async-stream 0.3.6

- Licence: `MIT`
- Source: https://github.com/tokio-rs/async-stream

## async-stream-impl 0.3.6

- Licence: `MIT`
- Source: https://github.com/tokio-rs/async-stream

## async-trait 0.1.92

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/async-trait

## atomic-waker 1.1.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/atomic-waker

## av-scenechange 0.14.1

- Licence: `MIT`
- Source: https://github.com/rust-av/av-scenechange

## av1-grain 0.2.5

- Licence: `BSD-2-Clause`
- Source: https://github.com/rust-av/av1-grain

## avif-serialize 0.8.9

- Licence: `BSD-3-Clause`
- Source: https://github.com/kornelski/avif-serialize

## aws-lc-rs 1.18.1

- Licence: `ISC AND (Apache-2.0 OR ISC)`
- Source: https://github.com/aws/aws-lc-rs

## aws-lc-sys 0.45.0

- Licence: `ISC AND (Apache-2.0 OR ISC) AND Apache-2.0 AND MIT AND BSD-3-Clause AND (Apache-2.0 OR ISC OR MIT) AND (Apache-2.0 OR ISC OR MIT-0)`
- Source: https://github.com/aws/aws-lc-rs

## axum 0.8.9

- Licence: `MIT`
- Source: https://github.com/tokio-rs/axum

## axum-core 0.5.6

- Licence: `MIT`
- Source: https://github.com/tokio-rs/axum

## az 1.3.0

- Licence: `MIT/Apache-2.0`
- Source: https://gitlab.com/tspiteri/az

## base16ct 0.2.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/base16ct

## base64 0.13.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/marshallpierce/rust-base64

## base64 0.21.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/marshallpierce/rust-base64

## base64 0.22.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/marshallpierce/rust-base64

## base64 0.23.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/marshallpierce/rust-base64

## base64ct 1.8.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats

## biblatex 0.12.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/typst/biblatex

## bigdecimal 0.4.10

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/akubera/bigdecimal-rs

## bincode 1.3.3

- Licence: `MIT`
- Source: https://github.com/servo/bincode

## bit_field 0.10.3

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/phil-opp/rust-bit-field

## bit-set 0.5.3

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/contain-rs/bit-set

## bit-set 0.8.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/contain-rs/bit-set

## bit-vec 0.6.3

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/contain-rs/bit-vec

## bit-vec 0.8.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/contain-rs/bit-vec

## bitflags 1.3.2

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/bitflags/bitflags

## bitflags 2.13.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/bitflags/bitflags

## bitflags 2.13.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/bitflags/bitflags

## bitpacking 0.9.3

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/bitpacking

## bitstream-io 4.10.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/tuffy/bitstream-io

## blake2 0.10.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/hashes

## blake2b_simd 1.0.5

- Licence: `MIT`
- Source: https://github.com/oconnor663/blake2_simd

## block-buffer 0.10.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## block-buffer 0.12.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## block-padding 0.3.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## block2 0.6.2

- Licence: `MIT`
- Source: https://github.com/madsmtm/objc2

## bm25 2.3.2

- Licence: `MIT`
- Source: https://github.com/Michael-JB/bm25

## bon 3.9.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/elastio/bon

## bon-macros 3.9.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/elastio/bon

## branches 0.4.4

- Licence: `MIT`
- Source: https://github.com/fereidani/branches

## brotli 9.0.0

- Licence: `BSD-3-Clause AND MIT`
- Source: https://github.com/dropbox/rust-brotli

## brotli-decompressor 6.0.1

- Licence: `BSD-3-Clause/MIT`
- Source: https://github.com/dropbox/rust-brotli-decompressor

## bs58 0.5.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/Nullus157/bs58-rs

## bstr 1.13.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/BurntSushi/bstr

## bumpalo 3.20.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/fitzgen/bumpalo

## by_address 1.2.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/mbrubeck/by_address

## bytemuck 1.25.0

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/bytemuck

## bytemuck 1.25.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/bytemuck

## bytemuck_derive 1.10.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/bytemuck

## bytemuck_derive 1.12.1

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/bytemuck

## byteorder 1.5.0

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/byteorder

## byteorder-lite 0.1.0

- Licence: `Unlicense OR MIT`
- Source: https://github.com/image-rs/byteorder-lite

## bytes 1.12.1

- Licence: `MIT`
- Source: https://github.com/tokio-rs/bytes

## cached 0.56.0

- Licence: `MIT`
- Source: https://github.com/jaemk/cached

## cached_proc_macro 0.25.0

- Licence: `MIT`
- Source: https://github.com/jaemk/cached

## cached_proc_macro_types 0.1.1

- Licence: `MIT`
- Source: https://github.com/jaemk/cached

## camino 1.2.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/camino-rs/camino

## candle-core 0.11.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/huggingface/candle

## candle-metal-kernels 0.11.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/huggingface/candle

## candle-nn 0.11.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/huggingface/candle

## cargo_metadata 0.19.2

- Licence: `MIT`
- Source: https://github.com/oli-obk/cargo_metadata

## cargo-platform 0.1.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/cargo

## castaway 0.2.4

- Licence: `MIT`
- Source: https://github.com/sagebind/castaway

## census 0.4.2

- Licence: `MIT`
- Source: https://github.com/quickwit-inc/census

## cfb 0.14.0

- Licence: `MIT`
- Source: https://github.com/mdsteele/rust-cfb

## cfg_block 0.1.1

- Licence: `Apache-2.0`
- Source: https://github.com/pluots/cfg_block
- Override evidence: crate LICENSE file in Cargo.lock checksum-pinned cfg_block 0.1.1

## cfg-if 1.0.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/cfg-if

## cfgrammar 0.14.2

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/softdevteam/grmtools

## chacha20 0.10.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/stream-ciphers

## chacha20 0.10.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/stream-ciphers

## chacha20 0.9.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/stream-ciphers

## chacha20poly1305 0.10.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/AEADs/tree/master/chacha20poly1305

## chinese-number 0.7.8

- Licence: `MIT`
- Source: https://github.com/magiclen/chinese-number

## chinese-variant 1.1.6

- Licence: `MIT`
- Source: https://github.com/magiclen/chinese-variant

## chrono 0.4.45

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/chronotope/chrono

## ciborium 0.2.2

- Licence: `Apache-2.0`
- Source: https://github.com/enarx/ciborium

## ciborium-io 0.2.2

- Licence: `Apache-2.0`
- Source: https://github.com/enarx/ciborium

## ciborium-ll 0.2.2

- Licence: `Apache-2.0`
- Source: https://github.com/enarx/ciborium

## cipher 0.4.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## cipher 0.5.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## citationberg 0.7.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/typst/citationberg

## clap 4.6.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/clap-rs/clap

## clap_builder 4.6.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/clap-rs/clap

## clap_derive 4.6.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/clap-rs/clap

## clap_lex 1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/clap-rs/clap

## cmov 0.5.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/utils

## cobs 0.3.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jamesmunns/cobs.rs

## codex 0.3.0

- Licence: `Apache-2.0`
- Source: https://github.com/typst/codex

## color 0.3.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/color

## color_quant 1.1.0

- Licence: `MIT`
- Source: https://github.com/image-rs/color_quant.git

## colorchoice 1.0.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-cli/anstyle.git

## comemo 0.5.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/typst/comemo

## comemo-macros 0.5.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/typst/comemo

## compact_str 0.9.1

- Licence: `MIT`
- Source: https://github.com/ParkMyCar/compact_str

## concurrent-queue 2.5.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/concurrent-queue

## console 0.15.11

- Licence: `MIT`
- Source: https://github.com/console-rs/console

## console 0.16.6

- Licence: `MIT`
- Source: https://github.com/console-rs/console

## const-oid 0.10.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats

## const-oid 0.9.6

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/const-oid

## constant_time_eq 0.1.5

- Licence: `CC0-1.0`
- Source: https://github.com/cesarb/constant_time_eq

## constant_time_eq 0.3.1

- Licence: `CC0-1.0 OR MIT-0 OR Apache-2.0`
- Source: https://github.com/cesarb/constant_time_eq

## constant_time_eq 0.4.2

- Licence: `CC0-1.0 OR MIT-0 OR Apache-2.0`
- Source: https://github.com/cesarb/constant_time_eq

## convert_case 0.10.0

- Licence: `MIT`
- Source: https://github.com/rutrum/convert-case

## cookie 0.18.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/SergioBenitez/cookie-rs

## core_maths 0.1.1

- Licence: `MIT`
- Source: https://github.com/robertbastian/core_maths

## core-foundation 0.10.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/core-foundation-rs

## core-foundation 0.9.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/core-foundation-rs

## core-foundation-sys 0.8.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/core-foundation-rs

## core-graphics 0.25.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/core-foundation-rs

## core-graphics-types 0.2.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/core-foundation-rs

## cpufeatures 0.2.17

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## cpufeatures 0.3.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## crc32c 0.6.8

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/zowens/crc32c

## crc32fast 1.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/srijs/rust-crc32fast

## crc32fast 1.5.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/srijs/rust-crc32fast

## crossbeam-channel 0.5.15

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/crossbeam-rs/crossbeam

## crossbeam-deque 0.8.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/crossbeam-rs/crossbeam

## crossbeam-deque 0.8.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/crossbeam-rs/crossbeam

## crossbeam-epoch 0.9.20

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/crossbeam-rs/crossbeam

## crossbeam-epoch 0.9.21

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/crossbeam-rs/crossbeam

## crossbeam-utils 0.8.21

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/crossbeam-rs/crossbeam

## crossbeam-utils 0.8.23

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/crossbeam-rs/crossbeam

## crossterm 0.29.0

- Licence: `MIT`
- Source: https://github.com/crossterm-rs/crossterm

## crunchy 0.2.4

- Licence: `MIT`
- Source: https://github.com/eira-fransham/crunchy

## crypto-bigint 0.5.5

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/crypto-bigint

## crypto-common 0.1.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## crypto-common 0.2.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## cssparser 0.36.0

- Licence: `MPL-2.0`
- Source: https://github.com/servo/rust-cssparser

## cssparser 0.37.0

- Licence: `MPL-2.0`
- Source: https://github.com/servo/rust-cssparser

## cssparser-macros 0.6.1

- Licence: `MPL-2.0`
- Source: https://github.com/servo/rust-cssparser

## cssparser-macros 0.7.1

- Licence: `MPL-2.0`
- Source: https://github.com/servo/rust-cssparser

## csv 1.4.0

- Licence: `Unlicense/MIT`
- Source: https://github.com/BurntSushi/rust-csv

## csv-core 0.1.13

- Licence: `Unlicense/MIT`
- Source: https://github.com/BurntSushi/rust-csv

## ctor 1.0.13

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/mmastrac/linktime

## ctr 0.9.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/block-modes

## ctutils 0.4.5

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/utils

## curve25519-dalek 4.1.3

- Licence: `BSD-3-Clause`
- Source: https://github.com/dalek-cryptography/curve25519-dalek/tree/main/curve25519-dalek

## daachorse 3.0.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/daac-tools/daachorse

## darling 0.11.0

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling 0.20.11

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling 0.23.0

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling 0.24.1

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling_core 0.11.0

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling_core 0.20.11

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling_core 0.23.0

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling_core 0.24.1

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling_macro 0.11.0

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling_macro 0.20.11

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling_macro 0.23.0

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling_macro 0.24.1

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## dary_heap 0.3.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/hanmertens/dary_heap

## dashmap 6.2.1

- Licence: `MIT`
- Source: https://github.com/xacrimon/dashmap

## data-encoding 2.11.0

- Licence: `MIT`
- Source: https://github.com/ia0/data-encoding

## data-encoding 2.11.1

- Licence: `MIT`
- Source: https://github.com/ia0/data-encoding

## data-url 0.3.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-url

## datasketches 0.2.0

- Licence: `Apache-2.0`
- Source: https://github.com/apache/datasketches-rust

## defmac 0.1.3

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/bluss/defmac

## defmt 1.1.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/knurling-rs/defmt

## defmt-macros 1.1.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/knurling-rs/defmt

## defmt-parser 1.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/knurling-rs/defmt

## der 0.7.10

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/der

## der 0.8.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats

## deranged 0.5.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jhpratt/deranged

## derive_builder 0.20.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/colin-kiegel/rust-derive-builder

## derive_builder_core 0.20.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/colin-kiegel/rust-derive-builder

## derive_builder_macro 0.20.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/colin-kiegel/rust-derive-builder

## derive_more 2.1.1

- Licence: `MIT`
- Source: https://github.com/JelteF/derive_more

## derive_more-impl 2.1.1

- Licence: `MIT`
- Source: https://github.com/JelteF/derive_more

## derive-new 0.7.0

- Licence: `MIT`
- Source: https://github.com/nrc/derive-new

## derivre 0.3.12

- Licence: `MIT`
- Source: https://github.com/microsoft/derivre

## deunicode 1.6.2

- Licence: `BSD-3-Clause`
- Source: https://github.com/kornelski/deunicode/

## digest 0.10.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## digest 0.11.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## dirs 4.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/soc/dirs-rs

## dirs 6.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/soc/dirs-rs

## dirs 7.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://codeberg.org/dirs/dirs-rs

## dirs-next 2.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/xdg-rs/dirs

## dirs-sys 0.3.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dirs-dev/dirs-sys-rs

## dirs-sys 0.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dirs-dev/dirs-sys-rs

## dirs-sys-next 0.1.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/xdg-rs/dirs/tree/master/dirs-sys

## dispatch2 0.3.1

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## displaydoc 0.2.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/yaahc/displaydoc

## displaydoc 0.2.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/yaahc/displaydoc

## doctest-file 1.1.1

- Licence: `0BSD`
- Source: https://codeberg.org/Goat7658/doctest-file

## document-features 0.2.12

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/slint-ui/document-features

## dom_query 0.28.0

- Licence: `MIT`
- Source: https://github.com/niklak/dom_query

## downcast-rs 2.0.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/marcianx/downcast-rs

## dpi 0.1.2

- Licence: `Apache-2.0 AND MIT`
- Source: https://github.com/rust-windowing/winit

## dtoa 1.0.11

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/dtoa

## dtoa-short 0.3.5

- Licence: `MPL-2.0`
- Source: https://github.com/upsuper/dtoa-short

## dunce 1.0.5

- Licence: `CC0-1.0 OR MIT-0 OR Apache-2.0`
- Source: https://gitlab.com/kornelski/dunce

## dyn-clone 1.0.20

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/dyn-clone

## dyn-stack 0.13.2

- Licence: `MIT`
- Source: https://codeberg.org/sarah-quinones/dyn-stack

## dyn-stack-macros 0.1.3

- Licence: `MIT`
- Source: https://github.com/kitegi/dynstack/

## ecdsa 0.16.9

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/signatures/tree/master/ecdsa

## ecow 0.2.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/typst/ecow

## ed25519 2.2.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/signatures/tree/master/ed25519

## ed25519-dalek 2.2.0

- Licence: `BSD-3-Clause`
- Source: https://github.com/dalek-cryptography/curve25519-dalek/tree/main/ed25519-dalek

## ed25519-zebra 4.2.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/ZcashFoundation/ed25519-zebra

## ego-tree 0.10.0

- Licence: `ISC`
- Source: https://github.com/rust-scraper/ego-tree

## either 1.16.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rayon-rs/either

## either 1.18.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rayon-rs/either

## elliptic-curve 0.13.8

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/traits/tree/master/elliptic-curve

## embed_plist 1.2.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/nvzqz/embed-plist-rs

## encoding_rs 0.8.41

- Licence: `(Apache-2.0 OR MIT) AND BSD-3-Clause`
- Source: https://github.com/hsivonen/encoding_rs

## encoding_rs_io 0.1.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/BurntSushi/encoding_rs_io

## endian-type 0.2.0

- Licence: `MIT`
- Source: https://github.com/Lolirofle/endian-type.git

## enum-as-inner 0.6.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/bluejekyll/enum-as-inner

## enum-ordinalize 4.4.2

- Licence: `MIT`
- Source: https://github.com/magiclen/enum-ordinalize

## enum-ordinalize-derive 4.4.2

- Licence: `MIT`
- Source: https://github.com/magiclen/enum-ordinalize

## env_filter 1.0.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-cli/env_logger

## env_logger 0.11.10

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-cli/env_logger

## equator 0.4.2

- Licence: `MIT`
- Source: https://github.com/sarah-ek/equator/

## equator-macro 0.4.2

- Licence: `MIT`
- Source: https://github.com/sarah-ek/equator/

## equivalent 1.0.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/indexmap-rs/equivalent

## erased-serde 0.4.10

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/erased-serde

## errno 0.3.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/lambda-fairy/rust-errno

## esaxx-rs 0.1.10

- Licence: `Apache-2.0`
- Source: https://github.com/Narsil/esaxx-rs

## espeak-ng 0.2.0

- Licence: `GPL-3.0-or-later`
- Source: https://github.com/eugenehp/espeak-ng-rs

## espeak-ng-data-dict-cmn 0.2.0

- Licence: `GPL-3.0-or-later`
- Source: https://github.com/eugenehp/espeak-ng-rs

## espeak-ng-data-dict-en 0.2.0

- Licence: `GPL-3.0-or-later`
- Source: https://github.com/eugenehp/espeak-ng-rs

## espeak-ng-data-dict-es 0.2.0

- Licence: `GPL-3.0-or-later`
- Source: https://github.com/eugenehp/espeak-ng-rs

## espeak-ng-data-dict-fr 0.2.0

- Licence: `GPL-3.0-or-later`
- Source: https://github.com/eugenehp/espeak-ng-rs

## espeak-ng-data-dict-hi 0.2.0

- Licence: `GPL-3.0-or-later`
- Source: https://github.com/eugenehp/espeak-ng-rs

## espeak-ng-data-dict-it 0.2.0

- Licence: `GPL-3.0-or-later`
- Source: https://github.com/eugenehp/espeak-ng-rs

## espeak-ng-data-dict-ja 0.2.0

- Licence: `GPL-3.0-or-later`
- Source: https://github.com/eugenehp/espeak-ng-rs

## espeak-ng-data-dict-pt 0.2.0

- Licence: `GPL-3.0-or-later`
- Source: https://github.com/eugenehp/espeak-ng-rs

## espeak-ng-data-phonemes 0.2.0

- Licence: `GPL-3.0-or-later`
- Source: https://github.com/eugenehp/espeak-ng-rs

## euclid 0.22.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/euclid

## event-listener 5.4.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/event-listener

## event-listener-strategy 0.5.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/event-listener-strategy

## eventsource-stream 0.2.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jpopesculian/eventsource-stream

## exr 1.74.2

- Licence: `BSD-3-Clause`
- Source: https://github.com/johannesvollmer/exrs

## extended 0.1.0

- Licence: `MIT`
- Source: https://github.com/depp/extended-rs

## fallible-iterator 0.3.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sfackler/rust-fallible-iterator

## fancy-regex 0.13.0

- Licence: `MIT`
- Source: https://github.com/fancy-regex/fancy-regex

## fancy-regex 0.14.0

- Licence: `MIT`
- Source: https://github.com/fancy-regex/fancy-regex

## fancy-regex 0.16.2

- Licence: `MIT`
- Source: https://github.com/fancy-regex/fancy-regex

## fancy-regex 0.17.0

- Licence: `MIT`
- Source: https://github.com/fancy-regex/fancy-regex

## fastbloom 0.14.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/tomtomwombat/fastbloom/

## fastdivide 0.4.2

- Licence: `zlib-acknowledgement OR MIT`
- Source: https://github.com/fulmicoton/fastdivide

## fastrand 2.4.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/fastrand

## fastrand 2.5.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/fastrand

## fax 0.2.7

- Licence: `MIT`
- Source: https://github.com/pdf-rs/fax

## fdeflate 0.3.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/image-rs/fdeflate

## fearless_simd 0.4.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/fearless_simd

## fearless_simd 1.2.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/fearless_simd

## ff 0.13.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/zkcrypto/ff

## filetime 0.2.29

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/alexcrichton/filetime

## flate2 1.1.10

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/flate2-rs

## float-cmp 0.9.0

- Licence: `MIT`
- Source: https://github.com/mikedilger/float-cmp

## float8 0.7.0

- Licence: `MIT`
- Source: https://github.com/EricLBuehler/float8

## fnv 1.0.7

- Licence: `Apache-2.0 / MIT`
- Source: https://github.com/servo/rust-fnv

## foldhash 0.1.5

- Licence: `Zlib`
- Source: https://github.com/orlp/foldhash

## foldhash 0.2.0

- Licence: `Zlib`
- Source: https://github.com/orlp/foldhash

## font-types 0.11.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/googlefonts/fontations

## fontdb 0.23.0

- Licence: `MIT`
- Source: https://github.com/RazrFalcon/fontdb

## foreign-types 0.5.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sfackler/foreign-types

## foreign-types-macros 0.2.3

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sfackler/foreign-types

## foreign-types-shared 0.3.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sfackler/foreign-types

## form_urlencoded 1.2.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-url

## fs4 0.13.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/al8n/fs4-rs

## futf 0.1.5

- Licence: `MIT / Apache-2.0`
- Source: https://github.com/servo/futf

## futures 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-channel 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-core 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-executor 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-io 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-macro 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-sink 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-task 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-timer 3.0.4

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/async-rs/futures-timer

## futures-util 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## fxhash 0.2.1

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/cbreeden/fxhash

## galil-seiferas 0.1.5

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/bluss/galil-seiferas

## gemm 0.19.0

- Licence: `MIT`
- Source: https://github.com/sarah-ek/gemm/

## gemm-c32 0.19.0

- Licence: `MIT`
- Source: https://github.com/sarah-ek/gemm/

## gemm-c64 0.19.0

- Licence: `MIT`
- Source: https://github.com/sarah-ek/gemm/

## gemm-common 0.19.0

- Licence: `MIT`
- Source: https://github.com/sarah-ek/gemm/

## gemm-f16 0.19.0

- Licence: `MIT`
- Source: https://github.com/sarah-ek/gemm/

## gemm-f32 0.19.0

- Licence: `MIT`
- Source: https://github.com/sarah-ek/gemm/

## gemm-f64 0.19.0

- Licence: `MIT`
- Source: https://github.com/sarah-ek/gemm/

## genawaiter 0.99.1

- Licence: `MIT`
- Source: https://github.com/whatisaphone/genawaiter

## genawaiter-macro 0.99.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/whatisaphone/genawaiter

## generic-array 0.14.7

- Licence: `MIT`
- Source: https://github.com/fizyk20/generic-array.git

## getopts 0.2.24

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/getopts

## getrandom 0.2.17

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/getrandom

## getrandom 0.3.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/getrandom

## getrandom 0.4.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/getrandom

## ghash 0.5.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/universal-hashes

## gif 0.14.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/image-rs/image-gif

## glidesort 0.1.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/orlp/glidesort

## glifo 0.1.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/vello

## glob 0.3.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/glob

## group 0.13.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/zkcrypto/group

## guillotiere 0.7.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/nical/guillotiere

## h2 0.4.16

- Licence: `MIT`
- Source: https://github.com/hyperium/h2

## h2 0.4.19

- Licence: `MIT`
- Source: https://github.com/hyperium/h2

## half 2.7.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/VoidStarKat/half-rs

## hashbrown 0.12.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/hashbrown

## hashbrown 0.14.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/hashbrown

## hashbrown 0.15.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/hashbrown

## hashbrown 0.16.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/hashbrown

## hashbrown 0.17.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/hashbrown

## hayagriva 0.10.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/typst/hayagriva

## hayro 0.7.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/LaurenzV/hayro

## hayro-ccitt 0.3.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/LaurenzV/hayro

## hayro-ccitt 0.4.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/LaurenzV/hayro

## hayro-cmap 0.1.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/LaurenzV/hayro

## hayro-interpret 0.7.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/LaurenzV/hayro

## hayro-jbig2 0.3.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/LaurenzV/hayro

## hayro-jpeg2000 0.3.5

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/LaurenzV/hayro

## hayro-postscript 0.1.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/LaurenzV/hayro

## hayro-svg 0.7.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/LaurenzV/hayro

## hayro-syntax 0.7.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/LaurenzV/hayro

## hayro-write 0.7.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/LaurenzV/hayro

## heck 0.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/withoutboats/heck

## hex 0.4.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/KokaKiwi/rust-hex

## hf-hub 0.4.3

- Licence: `Apache-2.0`
- Source: https://github.com/huggingface/hf-hub

## hkdf 0.12.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/KDFs/

## hmac 0.12.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/MACs

## hmac 0.13.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/MACs

## hound 3.5.1

- Licence: `Apache-2.0`
- Source: https://github.com/ruuda/hound

## html2text 0.16.7

- Licence: `MIT`
- Source: https://github.com/jugglerchris/rust-html2text/

## html5ever 0.36.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## html5ever 0.38.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## html5ever 0.39.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## htmlescape 0.3.1

- Licence: `Apache-2.0 / MIT / MPL-2.0`
- Source: https://github.com/veddan/rust-htmlescape

## http 1.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/hyperium/http

## http-body 1.0.1

- Licence: `MIT`
- Source: https://github.com/hyperium/http-body

## http-body 1.1.0

- Licence: `MIT`
- Source: https://github.com/hyperium/http-body

## http-body-util 0.1.5

- Licence: `MIT`
- Source: https://github.com/hyperium/http-body

## httparse 1.10.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/seanmonstar/httparse

## httpdate 1.0.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/pyfisch/httpdate

## hybrid-array 0.4.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/hybrid-array

## hyper 1.11.1

- Licence: `MIT`
- Source: https://github.com/hyperium/hyper

## hyper 1.12.0

- Licence: `MIT`
- Source: https://github.com/hyperium/hyper

## hyper-rustls 0.27.9

- Licence: `Apache-2.0 OR ISC OR MIT`
- Source: https://github.com/rustls/hyper-rustls

## hyper-util 0.1.20

- Licence: `MIT`
- Source: https://github.com/hyperium/hyper-util

## hyper-util 0.1.21

- Licence: `MIT`
- Source: https://github.com/hyperium/hyper-util

## hypher 0.1.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/typst/hypher

## iana-time-zone 0.1.65

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/strawlab/iana-time-zone

## ico 0.6.0

- Licence: `MIT`
- Source: https://github.com/mdsteele/rust-ico

## icu_collator 2.2.1

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_collator_data 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_collections 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_collections 2.3.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_locale 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_locale_core 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_locale_core 2.3.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_locale_data 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_normalizer 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_normalizer 2.3.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_normalizer_data 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_normalizer_data 2.3.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_properties 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_properties 2.3.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_properties_data 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_properties_data 2.3.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_provider 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_provider 2.3.1

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_provider_blob 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_segmenter 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_segmenter_data 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## ident_case 1.0.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/TedDriggs/ident_case

## idna 1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-url/

## idna_adapter 1.2.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/hsivonen/idna_adapter

## image 0.25.10

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/image-rs/image

## image-webp 0.2.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/image-rs/image-webp

## imagesize 0.14.0

- Licence: `MIT`
- Source: https://github.com/Roughsketch/imagesize

## imgref 1.12.3

- Licence: `CC0-1.0 OR Apache-2.0`
- Source: https://github.com/kornelski/imgref

## indexmap 1.9.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/bluss/indexmap

## indexmap 2.14.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/indexmap-rs/indexmap

## indexmap 2.14.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/indexmap-rs/indexmap

## indicatif 0.17.11

- Licence: `MIT`
- Source: https://github.com/console-rs/indicatif

## indicatif 0.18.6

- Licence: `MIT`
- Source: https://github.com/console-rs/indicatif

## infer 0.19.0

- Licence: `MIT`
- Source: https://github.com/bojand/infer

## infer 0.22.0

- Licence: `MIT`
- Source: https://github.com/bojand/infer

## Inflector 0.11.4

- Licence: `BSD-2-Clause`
- Source: https://github.com/whatisinternet/inflector

## inout 0.1.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## inout 0.2.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## interprocess 2.4.4

- Licence: `0BSD OR Apache-2.0`
- Source: https://github.com/kotauskas/interprocess

## intrusive-collections 0.9.7

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/Amanieu/intrusive-rs

## inventory 0.3.24

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/inventory

## iota_stronghold 2.1.0

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/stronghold.rs

## iota-crypto 0.23.2

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/crypto.rs

## ipnet 2.12.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/krisprice/ipnet

## ipnet 2.12.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/krisprice/ipnet

## is_terminal_polyfill 1.70.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/polyfill-rs/is_terminal_polyfill

## iterator-sorted 0.1.0

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/common-rs

## itertools 0.10.5

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/rust-itertools/itertools

## itertools 0.14.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-itertools/itertools

## itoa 1.0.18

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/itoa

## jiff 0.2.37

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/jiff

## jiff 0.2.38

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/jiff

## jiff-core 0.1.0

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/jiff

## jiff-core 0.1.1

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/jiff

## jiff-static 0.2.38

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/jiff

## jiff-tzdb 0.1.9

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/jiff

## json-patch 4.2.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/idubrov/json-patch

## jsonptr 0.7.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/chanced/jsonptr

## k256 0.13.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/elliptic-curves/tree/master/k256

## kamadak-exif 0.6.1

- Licence: `BSD-2-Clause`
- Source: https://github.com/kamadak/exif-rs

## keyboard-types 0.8.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-windowing/keyboard-types

## keyring 4.2.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/open-source-cooperative/keyring-rs

## keyring-core 1.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/open-source-cooperative/keyring-core.git

## krilla 0.8.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/LaurenzV/krilla

## krilla-svg 0.8.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/LaurenzV/krilla

## kurbo 0.13.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/kurbo

## lazy_static 1.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang-nursery/lazy-static.rs

## lebe 0.5.3

- Licence: `BSD-3-Clause`
- Source: https://github.com/johannesvollmer/lebe

## levenshtein_automata 0.2.1

- Licence: `MIT`
- Source: https://github.com/tantivy-search/levenshtein-automata

## libc 0.2.189

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/libc

## libc 0.2.191

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/libc

## libloading 0.8.9

- Licence: `ISC`
- Source: https://github.com/nagisa/rust_libloading/

## libloading 0.9.0

- Licence: `ISC`
- Source: https://github.com/nagisa/rust_libloading/

## libm 0.2.16

- Licence: `MIT`
- Source: https://github.com/rust-lang/compiler-builtins

## libmimalloc-sys 0.1.49

- Licence: `MIT`
- Source: https://github.com/purpleprotocol/mimalloc_rust/tree/master/libmimalloc-sys

## libsodium-sys-stable 1.24.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jedisct1/libsodium-sys-stable

## linebender_resource_handle 0.1.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/raw_resource_handle

## linked-hash-map 0.5.6

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/contain-rs/linked-hash-map

## lipsum 0.9.1

- Licence: `MIT`
- Source: https://github.com/mgeisler/lipsum/

## litemap 0.8.2

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## litemap 0.8.3

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## litrs 1.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/LukasKalbertodt/litrs

## llguidance 1.8.0

- Licence: `MIT`
- Source: https://github.com/guidance-ai/llguidance

## lock_api 0.4.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Amanieu/parking_lot

## log 0.4.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/log

## loop9 0.1.5

- Licence: `MIT`
- Source: https://gitlab.com/kornelski/loop9.git

## lrtable 0.14.2

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/softdevteam/grmtools

## lru 0.16.4

- Licence: `MIT`
- Source: https://github.com/jeromefroe/lru-rs.git

## lru-slab 0.1.2

- Licence: `MIT OR Apache-2.0 OR Zlib`
- Source: https://github.com/Ralith/lru-slab

## lru-slab 0.1.3

- Licence: `MIT OR Apache-2.0 OR Zlib`
- Source: https://github.com/Ralith/lru-slab

## lz4_flex 0.13.1

- Licence: `MIT`
- Source: https://github.com/pseitz/lz4_flex

## mac 0.1.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/reem/rust-mac.git

## macro_rules_attribute 0.2.3

- Licence: `Apache-2.0 OR MIT OR Zlib`
- Source: https://github.com/danielhenrymantilla/macro_rules_attribute-rs

## macro_rules_attribute-proc_macro 0.2.3

- Licence: `Apache-2.0 OR MIT OR Zlib`
- Source: https://github.com/danielhenrymantilla/macro_rules_attribute-rs

## malloc_buf 0.0.6

- Licence: `MIT`
- Source: https://github.com/SSheldon/malloc_buf

## markup5ever 0.36.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## markup5ever 0.38.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## markup5ever 0.39.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## matchers 0.2.0

- Licence: `MIT`
- Source: https://github.com/hawkw/matchers

## matchit 0.8.4

- Licence: `MIT AND BSD-3-Clause`
- Source: https://github.com/ibraheemdev/matchit

## matrixmultiply 0.3.11

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/bluss/matrixmultiply/

## maybe-rayon 0.1.1

- Licence: `MIT`
- Source: https://github.com/shssoichiro/maybe-rayon

## measure_time 0.9.0

- Licence: `MIT`
- Source: https://github.com/PSeitz/rust_measure_time

## memchr 2.8.2

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/memchr

## memchr 2.8.3

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/memchr

## memmap2 0.9.11

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RazrFalcon/memmap2-rs

## memo-map 0.3.4

- Licence: `Apache-2.0`
- Source: https://github.com/mitsuhiko/memo-map

## memoffset 0.6.5

- Licence: `MIT`
- Source: https://github.com/Gilnaa/memoffset

## memoffset 0.9.1

- Licence: `MIT`
- Source: https://github.com/Gilnaa/memoffset

## metrics 0.24.6

- Licence: `MIT`
- Source: https://github.com/metrics-rs/metrics

## miette 7.6.0

- Licence: `Apache-2.0`
- Source: https://github.com/zkat/miette

## miette-derive 7.6.0

- Licence: `Apache-2.0`
- Source: https://github.com/zkat/miette

## mimalloc 0.1.52

- Licence: `MIT`
- Source: https://github.com/purpleprotocol/mimalloc_rust

## mime 0.3.17

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/hyperium/mime

## mime_guess 2.0.5

- Licence: `MIT`
- Source: https://github.com/abonander/mime_guess

## minijinja 2.24.0

- Licence: `Apache-2.0`
- Source: https://github.com/mitsuhiko/minijinja

## minijinja-contrib 2.24.0

- Licence: `Apache-2.0`
- Source: https://github.com/mitsuhiko/minijinja

## minimal-lexical 0.2.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/Alexhuszagh/minimal-lexical

## minisign-verify 0.3.0

- Licence: `MIT`
- Source: https://github.com/jedisct1/rust-minisign-verify

## miniz_oxide 0.8.9

- Licence: `MIT OR Zlib OR Apache-2.0`
- Source: https://github.com/Frommi/miniz_oxide/tree/master/miniz_oxide

## miniz_oxide 0.9.1

- Licence: `MIT OR Zlib OR Apache-2.0`
- Source: https://github.com/Frommi/miniz_oxide/tree/master/miniz_oxide

## mio 1.2.1

- Licence: `MIT`
- Source: https://github.com/tokio-rs/mio

## mio 1.2.3

- Licence: `MIT`
- Source: https://github.com/tokio-rs/mio

## mistralrs 0.9.4

- Licence: `MIT`
- Source: https://github.com/EricLBuehler/mistral.rs

## mistralrs-audio 0.9.4

- Licence: `MIT`
- Source: https://github.com/EricLBuehler/mistral.rs

## mistralrs-code-exec 0.9.4

- Licence: `MIT`
- Source: https://github.com/EricLBuehler/mistral.rs

## mistralrs-core 0.9.4

- Licence: `MIT`
- Source: https://github.com/EricLBuehler/mistral.rs

## mistralrs-macros 0.9.4

- Licence: `MIT`
- Source: https://github.com/EricLBuehler/mistral.rs

## mistralrs-mcp 0.9.4

- Licence: `MIT`
- Source: https://github.com/EricLBuehler/mistral.rs

## mistralrs-metal-compile 0.9.4

- Licence: `MIT`
- Source: https://github.com/EricLBuehler/mistral.rs

## mistralrs-paged-attn 0.9.4

- Licence: `MIT`
- Source: https://github.com/EricLBuehler/mistral.rs

## mistralrs-quant 0.9.4

- Licence: `MIT AND Apache-2.0`
- Source: https://github.com/EricLBuehler/mistral.rs

## mistralrs-sandbox 0.9.4

- Licence: `MIT`
- Source: https://github.com/EricLBuehler/mistral.rs

## mistralrs-vision 0.9.4

- Licence: `MIT`
- Source: https://github.com/EricLBuehler/mistral.rs

## monostate 0.1.18

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/monostate

## monostate-impl 0.1.18

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/monostate

## moxcms 0.8.1

- Licence: `BSD-3-Clause OR Apache-2.0`
- Source: https://github.com/awxkee/moxcms.git

## muda 0.20.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/muda

## multiversion_no_op 1.0.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/hsivonen/multiversion_no_op

## murmurhash32 0.3.1

- Licence: `MIT`
- Source: https://github.com/quickwit-inc/murmurhash32

## mutate_once 0.1.2

- Licence: `BSD-2-Clause`
- Source: https://github.com/kamadak/mutate_once-rs

## nalgebra 0.33.3

- Licence: `Apache-2.0`
- Source: https://github.com/dimforge/nalgebra

## nanoid 0.4.0

- Licence: `MIT`
- Source: https://github.com/nikolay-govorov/nanoid.git

## native-tls 0.2.18

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-native-tls/rust-native-tls

## ndarray 0.17.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-ndarray/ndarray

## new_debug_unreachable 1.0.6

- Licence: `MIT`
- Source: https://github.com/mbrubeck/rust-debug-unreachable

## nibble_vec 0.1.0

- Licence: `MIT`
- Source: https://github.com/michaelsproul/rust_nibble_vec

## nix 0.24.3

- Licence: `MIT`
- Source: https://github.com/nix-rust/nix

## nix 0.31.3

- Licence: `MIT`
- Source: https://github.com/nix-rust/nix

## no_std_io2 0.9.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/wcampbell0x2a/no-std-io2

## nohash-hasher 0.2.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/paritytech/nohash-hasher

## nom 7.1.3

- Licence: `MIT`
- Source: https://github.com/Geal/nom

## nom 8.0.0

- Licence: `MIT`
- Source: https://github.com/rust-bakery/nom

## noop_proc_macro 0.3.0

- Licence: `MIT`
- Source: https://github.com/lu-zero/noop_proc_macro

## nu-ansi-term 0.50.3

- Licence: `MIT`
- Source: https://github.com/nushell/nu-ansi-term

## num_cpus 1.17.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/seanmonstar/num_cpus

## num-bigint 0.4.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-bigint

## num-bigint 0.4.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-bigint

## num-bigint-dig 0.8.6

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/dignifiedquire/num-bigint

## num-complex 0.4.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-complex

## num-conv 0.2.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jhpratt/num-conv

## num-derive 0.4.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-derive

## num-integer 0.1.46

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-integer

## num-integer 0.1.47

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-integer

## num-iter 0.1.45

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-iter

## num-rational 0.4.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-rational

## num-traits 0.2.19

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-traits

## number_prefix 0.4.0

- Licence: `MIT`
- Source: https://github.com/ogham/rust-number-prefix

## oauth2 5.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/ramosbugs/oauth2-rs

## objc 0.2.7

- Licence: `MIT`
- Source: http://github.com/SSheldon/rust-objc

## objc2 0.6.4

- Licence: `MIT`
- Source: https://github.com/madsmtm/objc2

## objc2 0.6.5

- Licence: `MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-app-kit 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-core-foundation 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-core-graphics 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-encode 4.1.0

- Licence: `MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-exception-helper 0.1.1

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-foundation 0.3.2

- Licence: `MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-io-kit 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-io-surface 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-metal 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-osa-kit 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-quartz-core 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-web-kit 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## once_cell 1.21.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/matklad/once_cell

## oneshot 0.1.13

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/faern/oneshot

## opaque-debug 0.3.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## open 5.3.5

- Licence: `MIT`
- Source: https://github.com/Byron/open-rs

## openai-harmony 0.0.8

- Licence: `Apache-2.0`
- Source: https://github.com/openai/harmony

## openidconnect 4.0.1

- Licence: `MIT`
- Source: https://github.com/ramosbugs/openidconnect-rs

## option-ext 0.2.0

- Licence: `MPL-2.0`
- Source: https://github.com/soc/option-ext.git

## ordered-float 2.10.1

- Licence: `MIT`
- Source: https://github.com/reem/rust-ordered-float

## ordered-float 5.3.0

- Licence: `MIT`
- Source: https://github.com/reem/rust-ordered-float

## ordered-float 5.5.0

- Licence: `MIT`
- Source: https://github.com/reem/rust-ordered-float

## ort 2.0.0-rc.12

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/pykeio/ort

## ort-sys 2.0.0-rc.12

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/pykeio/ort

## osakit 0.3.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/mdevils/rust-osakit

## ownedbytes 0.9.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## p256 0.13.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/elliptic-curves/tree/master/p256

## p384 0.13.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/elliptic-curves/tree/master/p384

## pack1 1.1.0

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/pack1

## packedvec 1.2.5

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/softdevteam/packedvec/

## palette 0.7.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Ogeon/palette

## palette_derive 0.7.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Ogeon/palette

## palette_math 0.7.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Ogeon/palette

## parking 2.2.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/parking

## parking_lot 0.12.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Amanieu/parking_lot

## parking_lot_core 0.9.12

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Amanieu/parking_lot

## paste 1.0.15

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/paste

## pastey 0.1.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/as1100k/pastey

## pastey 0.2.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/as1100k/pastey

## pathdiff 0.2.3

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/Manishearth/pathdiff

## pbkdf2 0.12.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/password-hashes/tree/master/pbkdf2

## pdf-writer 0.15.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/typst/pdf-writer

## pem-rfc7468 0.7.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/pem-rfc7468

## pem-rfc7468 1.0.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats

## peniko 0.6.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/peniko

## percent-encoding 2.3.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-url/

## phf 0.13.1

- Licence: `MIT`
- Source: https://github.com/rust-phf/rust-phf

## phf_generator 0.13.1

- Licence: `MIT`
- Source: https://github.com/rust-phf/rust-phf

## phf_macros 0.13.1

- Licence: `MIT`
- Source: https://github.com/rust-phf/rust-phf

## phf_shared 0.13.1

- Licence: `MIT`
- Source: https://github.com/rust-phf/rust-phf

## pic-scale 0.7.12

- Licence: `BSD-3-Clause OR Apache-2.0`
- Source: https://github.com/awxkee/pic-scale

## pico-args 0.5.0

- Licence: `MIT`
- Source: https://github.com/RazrFalcon/pico-args

## pin-project 1.1.13

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/taiki-e/pin-project

## pin-project-internal 1.1.13

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/taiki-e/pin-project

## pin-project-lite 0.2.17

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/taiki-e/pin-project-lite

## pkcs1 0.7.5

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/pkcs1

## pkcs8 0.10.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/pkcs8

## plist 1.10.0

- Licence: `MIT`
- Source: https://github.com/ebarnard/rust-plist/

## png 0.18.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/image-rs/image-png

## polling 3.11.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/polling

## poly1305 0.8.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/universal-hashes

## polycool 0.4.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/linebender/kurbo

## polyval 0.6.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/universal-hashes

## portable-atomic 1.15.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/taiki-e/portable-atomic

## postcard 1.1.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jamesmunns/postcard

## potential_utf 0.1.5

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## potential_utf 0.1.6

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## powerfmt 0.2.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jhpratt/powerfmt

## ppv-lite86 0.2.21

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/cryptocorrosion/cryptocorrosion

## precomputed-hash 0.1.1

- Licence: `MIT`
- Source: https://github.com/emilio/precomputed-hash

## prettyplease 0.2.37

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/prettyplease

## primal-check 0.3.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/huonw/primal

## primeorder 0.13.6

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/elliptic-curves/tree/master/primeorder

## proc-macro-hack 0.5.20+deprecated

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/proc-macro-hack

## proc-macro2 1.0.106

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/proc-macro2

## proc-macro2 1.0.107

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/proc-macro2

## profiling 1.0.18

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/aclysma/profiling

## profiling-procmacros 1.0.18

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/aclysma/profiling

## prost 0.14.4

- Licence: `Apache-2.0`
- Source: https://github.com/tokio-rs/prost

## prost-derive 0.14.4

- Licence: `Apache-2.0`
- Source: https://github.com/tokio-rs/prost

## psl 2.1.245

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/addr-rs/psl

## psl-types 2.0.11

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/addr-rs/psl-types

## psm 0.1.32

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/stacker/

## pulldown-cmark 0.13.5

- Licence: `MIT`
- Source: https://github.com/raphlinus/pulldown-cmark

## pulldown-cmark-escape 0.11.0

- Licence: `MIT`
- Source: https://github.com/raphlinus/pulldown-cmark

## pulp 0.22.3

- Licence: `MIT`
- Source: https://github.com/sarah-quinones/pulp/

## pulp-wasm-simd-flag 0.1.1

- Licence: `MIT`
- Source: https://github.com/sarah-quinones/pulp/

## pxfm 0.1.30

- Licence: `BSD-3-Clause OR Apache-2.0`
- Source: https://github.com/awxkee/pxfm

## qoi 0.4.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/aldanor/qoi-rust

## quick-error 2.0.1

- Licence: `MIT/Apache-2.0`
- Source: http://github.com/tailhook/quick-error

## quick-xml 0.38.4

- Licence: `MIT`
- Source: https://github.com/tafia/quick-xml

## quick-xml 0.41.0

- Licence: `MIT`
- Source: https://github.com/tafia/quick-xml

## quinn 0.11.12

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/quinn-rs/quinn

## quinn 0.11.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/quinn-rs/quinn

## quinn-proto 0.11.18

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/quinn-rs/quinn

## quinn-udp 0.5.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/quinn-rs/quinn

## quinn-udp 0.5.15

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/quinn-rs/quinn

## quote 1.0.45

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/quote

## quote 1.0.47

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/quote

## radix_trie 0.3.0

- Licence: `MIT`
- Source: https://github.com/michaelsproul/rust_radix_trie

## rand 0.10.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand 0.8.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand 0.8.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand 0.9.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand 0.9.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand_chacha 0.3.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand_chacha 0.9.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand_core 0.10.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand_core

## rand_core 0.6.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand_core 0.9.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand_distr 0.4.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand_distr 0.5.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand_distr

## rand_isaac 0.4.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rngs

## rand_pcg 0.10.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rngs

## rapidhash 4.4.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/hoxxep/rapidhash

## rapidhash 4.5.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/hoxxep/rapidhash

## rav1e 0.8.1

- Licence: `BSD-2-Clause`
- Source: https://github.com/xiph/rav1e/

## ravif 0.13.0

- Licence: `BSD-3-Clause`
- Source: https://github.com/kornelski/cavif-rs

## raw-cpuid 11.6.0

- Licence: `MIT`
- Source: https://github.com/gz/rust-cpuid

## raw-window-handle 0.6.2

- Licence: `MIT OR Apache-2.0 OR Zlib`
- Source: https://github.com/rust-windowing/raw-window-handle

## rawpointer 0.2.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/bluss/rawpointer/

## rayon 1.12.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rayon-rs/rayon

## rayon-cond 0.4.0

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/cuviper/rayon-cond

## rayon-core 1.13.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rayon-rs/rayon

## read-fonts 0.39.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/googlefonts/fontations

## realfft 3.5.0

- Licence: `MIT`
- Source: https://github.com/HEnquist/realfft

## reborrow 0.5.5

- Licence: `MIT`
- Source: https://github.com/sarah-ek/reborrow/

## ref-cast 1.0.25

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/ref-cast

## ref-cast 1.0.27

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/ref-cast

## ref-cast-impl 1.0.25

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/ref-cast

## ref-cast-impl 1.0.27

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/ref-cast

## regex 1.12.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/regex

## regex-automata 0.4.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/regex

## regex-automata 0.4.18

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/regex

## regex-syntax 0.8.11

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/regex

## reqwest 0.12.28

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/seanmonstar/reqwest

## reqwest 0.13.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/seanmonstar/reqwest

## resvg 0.47.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/resvg

## rfc6979 0.4.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/signatures/tree/master/rfc6979

## rfd 0.16.0

- Licence: `MIT`
- Source: https://github.com/PolyMeilex/rfd

## rgb 0.8.53

- Licence: `MIT`
- Source: https://github.com/kornelski/rust-rgb

## rig-core 0.39.0

- Licence: `MIT`
- Source: https://github.com/0xPlaygrounds/rig

## ring 0.17.14

- Licence: `Apache-2.0 AND ISC`
- Source: https://github.com/briansmith/ring

## roaring 0.11.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RoaringBitmap/roaring-rs

## roman-numerals-rs 3.1.0

- Licence: `0BSD OR CC0-1.0`
- Source: https://github.com/AA-Turner/roman-numerals/

## roxmltree 0.21.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RazrFalcon/roxmltree

## rsa 0.9.10

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/RSA

## rubato 0.16.2

- Licence: `MIT`
- Source: https://github.com/HEnquist/rubato

## rust_decimal 1.43.0

- Licence: `MIT`
- Source: https://github.com/paupino/rust-decimal

## rust-argon2 1.0.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sru-systems/rust-argon2

## rust-argon2 2.1.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sru-systems/rust-argon2

## rust-mcp-schema 0.9.6

- Licence: `MIT`
- Source: https://github.com/rust-mcp-stack/rust-mcp-schema

## rust-stemmers 1.2.0

- Licence: `MIT/BSD-3-Clause`
- Source: https://github.com/CurrySoftware/rust-stemmers

## rustc-hash 1.1.0

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/rust-lang-nursery/rustc-hash

## rustc-hash 2.1.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/rust-lang/rustc-hash

## rustc-hash 2.1.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/rust-lang/rustc-hash

## rustfft 6.4.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/ejmahler/RustFFT

## rustix 1.1.4

- Licence: `Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT`
- Source: https://github.com/bytecodealliance/rustix

## rustls 0.23.46

- Licence: `Apache-2.0 OR ISC OR MIT`
- Source: https://github.com/rustls/rustls

## rustls-native-certs 0.8.4

- Licence: `Apache-2.0 OR ISC OR MIT`
- Source: https://github.com/rustls/rustls-native-certs

## rustls-pki-types 1.14.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rustls/pki-types

## rustls-pki-types 1.15.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rustls/pki-types

## rustls-platform-verifier 0.7.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rustls/rustls-platform-verifier

## rustls-webpki 0.103.15

- Licence: `ISC`
- Source: https://github.com/rustls/webpki

## rustls-webpki 0.103.16

- Licence: `ISC`
- Source: https://github.com/rustls/webpki

## rustversion 1.0.22

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/rustversion

## rustversion 1.0.23

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/rustversion

## rustybuzz 0.20.1

- Licence: `MIT`
- Source: https://github.com/harfbuzz/rustybuzz

## ryu 1.0.23

- Licence: `Apache-2.0 OR BSL-1.0`
- Source: https://github.com/dtolnay/ryu

## safe_arch 0.7.4

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/safe_arch

## safetensors 0.8.0

- Licence: `Apache-2.0`
- Source: https://github.com/huggingface/safetensors

## salsa20 0.10.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/stream-ciphers

## same-file 1.0.6

- Licence: `Unlicense/MIT`
- Source: https://github.com/BurntSushi/same-file

## saphyr-parser-bw 0.0.605

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/bourumir-wyngs/saphyr

## schemars 0.8.22

- Licence: `MIT`
- Source: https://github.com/GREsau/schemars

## schemars 0.9.0

- Licence: `MIT`
- Source: https://github.com/GREsau/schemars

## schemars 1.2.2

- Licence: `MIT`
- Source: https://github.com/GREsau/schemars

## schemars 1.2.3

- Licence: `MIT`
- Source: https://github.com/GREsau/schemars

## schemars_derive 0.8.22

- Licence: `MIT`
- Source: https://github.com/GREsau/schemars

## schemars_derive 1.2.2

- Licence: `MIT`
- Source: https://github.com/GREsau/schemars

## schemars_derive 1.2.3

- Licence: `MIT`
- Source: https://github.com/GREsau/schemars

## scopeguard 1.2.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/bluss/scopeguard

## scraper 0.25.0

- Licence: `ISC`
- Source: https://github.com/rust-scraper/scraper

## scrypt 0.11.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/password-hashes/tree/master/scrypt

## sec1 0.7.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/sec1

## security-framework 3.7.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/kornelski/rust-security-framework

## security-framework-sys 2.17.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/kornelski/rust-security-framework

## selectors 0.33.0

- Licence: `MPL-2.0`
- Source: https://github.com/servo/stylo

## selectors 0.38.0

- Licence: `MPL-2.0`
- Source: https://github.com/servo/stylo

## semver 1.0.28

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/semver

## seq-macro 0.3.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/seq-macro

## serde 1.0.229

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/serde

## serde_core 1.0.229

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/serde

## serde_derive 1.0.229

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/serde

## serde_derive_internals 0.29.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/serde

## serde_derive_internals 0.30.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/serde

## serde_json 1.0.151

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/json

## serde_json 1.0.154

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/json

## serde_path_to_error 0.1.20

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/path-to-error

## serde_plain 1.0.2

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/mitsuhiko/serde-plain

## serde_repr 0.1.20

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/serde-repr

## serde_spanned 0.6.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## serde_spanned 1.1.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## serde_urlencoded 0.7.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/nox/serde_urlencoded

## serde_with 3.21.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jonasbb/serde_with/

## serde_with 3.23.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jonasbb/serde_with/

## serde_with_macros 3.21.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jonasbb/serde_with/

## serde_with_macros 3.23.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jonasbb/serde_with/

## serde_yaml 0.9.34+deprecated

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/serde-yaml

## serde-big-array 0.5.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/est31/serde-big-array

## serde-saphyr 0.0.16

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/bourumir-wyngs/serde-saphyr

## serde-untagged 0.1.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/serde-untagged

## serde-value 0.7.0

- Licence: `MIT`
- Source: https://github.com/arcnmx/serde-value

## serialize-to-javascript 0.1.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/chippers/serialize-to-javascript

## serialize-to-javascript-impl 0.1.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/chippers/serialize-to-javascript

## servo_arc 0.4.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/stylo

## sha1 0.10.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/hashes

## sha1 0.11.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/hashes

## sha1_smol 1.0.1

- Licence: `BSD-3-Clause`
- Source: https://github.com/mitsuhiko/sha1-smol

## sha2 0.10.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/hashes

## sha2 0.11.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/hashes

## sharded-slab 0.1.7

- Licence: `MIT`
- Source: https://github.com/hawkw/sharded-slab

## signal-hook 0.3.18

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/vorner/signal-hook

## signal-hook-mio 0.2.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/vorner/signal-hook

## signal-hook-registry 1.4.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/vorner/signal-hook

## signature 2.2.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/traits/tree/master/signature

## simba 0.9.1

- Licence: `Apache-2.0`
- Source: https://github.com/dimforge/simba

## simd_helpers 0.1.0

- Licence: `MIT`
- Source: https://github.com/lu-zero/simd_helpers

## simd-adler32 0.3.10

- Licence: `MIT`
- Source: https://github.com/mcountryman/simd-adler32

## simd-adler32 0.3.9

- Licence: `MIT`
- Source: https://github.com/mcountryman/simd-adler32

## simdutf8 0.1.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rusticstuff/simdutf8

## simplecss 0.2.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/simplecss

## simsimd 6.5.16

- Licence: `Apache-2.0`
- Source: https://github.com/ashvardanian/SimSIMD

## siphasher 1.0.3

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/jedisct1/rust-siphash

## sketches-ddsketch 0.4.0

- Licence: `Apache-2.0`
- Source: https://github.com/mheffner/rust-sketches-ddsketch

## skrifa 0.42.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/googlefonts/fontations

## slab 0.4.12

- Licence: `MIT`
- Source: https://github.com/tokio-rs/slab

## slotmap 1.1.1

- Licence: `Zlib`
- Source: https://github.com/orlp/slotmap

## smallstr 0.3.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/murarth/smallstr

## smallvec 1.15.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-smallvec

## smallvec 1.16.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-smallvec

## smallvec 2.0.0-alpha.13

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-smallvec

## socket2 0.6.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/socket2

## socket2 0.6.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/socket2

## socks 0.3.4

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sfackler/rust-socks

## softaes 0.1.5

- Licence: `MIT`
- Source: https://github.com/jedisct1/rust-softaes

## sparsevec 0.2.2

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/softdevteam/sparsevec/

## specta 2.0.0-rc.22

- Licence: `MIT`
- Source: https://github.com/oscartbeaumont/specta

## specta-macros 2.0.0-rc.18

- Licence: `MIT`
- Source: https://github.com/oscartbeaumont/specta

## specta-serde 0.0.9

- Licence: `MIT`
- Source: https://github.com/oscartbeaumont/specta

## specta-typescript 0.0.9

- Licence: `MIT`
- Source: https://github.com/oscartbeaumont/specta

## spin 0.9.8

- Licence: `MIT`
- Source: https://github.com/mvdnes/spin-rs.git

## spki 0.7.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/spki

## spm_precompiled 0.1.4

- Licence: `Apache-2.0`
- Source: https://github.com/huggingface/spm_precompiled

## stable_deref_trait 1.2.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/storyyeller/stable_deref_trait

## stacker 0.1.25

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/stacker

## static_assertions 1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/nvzqz/static-assertions-rs

## statrs 0.18.0

- Licence: `MIT`
- Source: https://github.com/statrs-dev/statrs

## stop-words 0.9.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/cmccomb/stop-words

## strength_reduce 0.2.4

- Licence: `MIT OR Apache-2.0`
- Source: http://github.com/ejmahler/strength_reduce

## strict-num 0.1.1

- Licence: `MIT`
- Source: https://github.com/RazrFalcon/strict-num

## string_cache 0.9.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/string-cache

## stronghold_engine 2.0.1

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/stronghold.rs

## stronghold-derive 1.0.0

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/stronghold.rs

## stronghold-runtime 2.0.1

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/stronghold.rs

## stronghold-utils 1.0.0

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/stronghold.rs

## strsim 0.10.0

- Licence: `MIT`
- Source: https://github.com/dguo/strsim-rs

## strsim 0.11.1

- Licence: `MIT`
- Source: https://github.com/rapidfuzz/strsim-rs

## strum 0.26.3

- Licence: `MIT`
- Source: https://github.com/Peternator7/strum

## strum 0.27.2

- Licence: `MIT`
- Source: https://github.com/Peternator7/strum

## strum 0.28.0

- Licence: `MIT`
- Source: https://github.com/Peternator7/strum

## strum_macros 0.26.4

- Licence: `MIT`
- Source: https://github.com/Peternator7/strum

## strum_macros 0.27.2

- Licence: `MIT`
- Source: https://github.com/Peternator7/strum

## strum_macros 0.28.0

- Licence: `MIT`
- Source: https://github.com/Peternator7/strum

## subsetter 0.2.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/typst/subsetter

## subtle 2.6.1

- Licence: `BSD-3-Clause`
- Source: https://github.com/dalek-cryptography/subtle

## svgtypes 0.16.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/svgtypes

## swift-rs 1.0.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Brendonovich/swift-rs

## symlink 0.1.0

- Licence: `MIT/Apache-2.0`
- Source: https://gitlab.com/chris-morgan/symlink

## symphonia 0.5.5

- Licence: `MPL-2.0`
- Source: https://github.com/pdeljanov/Symphonia

## symphonia-bundle-flac 0.5.5

- Licence: `MPL-2.0`
- Source: https://github.com/pdeljanov/Symphonia

## symphonia-bundle-mp3 0.5.5

- Licence: `MPL-2.0`
- Source: https://github.com/pdeljanov/Symphonia

## symphonia-codec-pcm 0.5.5

- Licence: `MPL-2.0`
- Source: https://github.com/pdeljanov/Symphonia

## symphonia-codec-vorbis 0.5.5

- Licence: `MPL-2.0`
- Source: https://github.com/pdeljanov/Symphonia

## symphonia-core 0.5.5

- Licence: `MPL-2.0`
- Source: https://github.com/pdeljanov/Symphonia

## symphonia-format-isomp4 0.5.5

- Licence: `MPL-2.0`
- Source: https://github.com/pdeljanov/Symphonia

## symphonia-format-ogg 0.5.5

- Licence: `MPL-2.0`
- Source: https://github.com/pdeljanov/Symphonia

## symphonia-format-riff 0.5.5

- Licence: `MPL-2.0`
- Source: https://github.com/pdeljanov/Symphonia

## symphonia-metadata 0.5.5

- Licence: `MPL-2.0`
- Source: https://github.com/pdeljanov/Symphonia

## symphonia-utils-xiph 0.5.5

- Licence: `MPL-2.0`
- Source: https://github.com/pdeljanov/Symphonia

## syn 1.0.109

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/syn

## syn 2.0.118

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/syn

## syn 2.0.119

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/syn

## syn 3.0.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/syn

## syn 3.0.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/syn

## sync_wrapper 1.0.2

- Licence: `Apache-2.0`
- Source: https://github.com/Actyx/sync_wrapper

## synstructure 0.13.2

- Licence: `MIT`
- Source: https://github.com/mystor/synstructure

## syntect 5.3.0

- Licence: `MIT`
- Source: https://github.com/trishume/syntect

## sysctl 0.6.0

- Licence: `MIT`
- Source: https://github.com/johalun/sysctl-rs

## sysinfo 0.36.1

- Licence: `MIT`
- Source: https://github.com/GuillaumeGomez/sysinfo

## system-configuration 0.7.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/mullvad/system-configuration-rs

## system-configuration-sys 0.6.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/mullvad/system-configuration-rs

## tantivy 0.26.2

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-bitpacker 0.10.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-columnar 0.7.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-common 0.11.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-fst 0.5.0

- Licence: `Unlicense/MIT`
- Source: https://github.com/quickwit-inc/fst

## tantivy-query-grammar 0.26.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-sstable 0.7.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-stacker 0.7.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-tokenizer-api 0.7.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tao 0.37.1

- Licence: `Apache-2.0`
- Source: https://github.com/tauri-apps/tao

## tar 0.4.46

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/composefs/tar-rs

## tauri 2.12.5

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri

## tauri-codegen 2.7.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri

## tauri-macros 2.7.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri

## tauri-plugin-dialog 2.8.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-plugin-fs 2.7.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-plugin-opener 2.7.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-plugin-process 2.4.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-plugin-single-instance 2.5.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-plugin-stronghold 2.4.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-plugin-updater 2.13.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-runtime 2.12.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri

## tauri-runtime-wry 2.12.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri

## tauri-specta 2.0.0-rc.21

- Licence: `MIT`
- Source: https://github.com/oscartbeaumont/tauri-specta

## tauri-specta-macros 2.0.0-rc.16

- Licence: `MIT`
- Source: https://github.com/oscartbeaumont/tauri-specta

## tauri-utils 2.10.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri

## tempfile 3.27.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Stebalien/tempfile

## tendril 0.4.3

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/servo/tendril

## tendril 0.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## tendril 0.5.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## terminal_size 0.4.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/eminence/terminal-size

## thin-vec 0.2.21

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/mozilla/thin-vec

## thiserror 1.0.69

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/thiserror

## thiserror 2.0.20

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/thiserror

## thiserror 2.0.21

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/thiserror

## thiserror-impl 1.0.69

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/thiserror

## thiserror-impl 2.0.20

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/thiserror

## thiserror-impl 2.0.21

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/thiserror

## thread_local 1.1.10

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Amanieu/thread_local-rs

## thread_local 1.1.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Amanieu/thread_local-rs

## tiff 0.11.3

- Licence: `MIT`
- Source: https://github.com/image-rs/image-tiff

## time 0.3.55

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/time-rs/time

## time-core 0.1.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/time-rs/time

## time-macros 0.2.32

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/time-rs/time

## tiny-keccak 2.0.2

- Licence: `CC0-1.0`
- Source: https://github.com/debris/tiny-keccak

## tiny-skia 0.12.0

- Licence: `BSD-3-Clause`
- Source: https://github.com/linebender/tiny-skia

## tiny-skia-path 0.12.0

- Licence: `BSD-3-Clause`
- Source: https://github.com/linebender/tiny-skia/tree/master/path

## tinystr 0.8.3

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## tinystr 0.8.4

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## tinyvec 1.11.0

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/tinyvec

## tinyvec 1.13.3

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/tinyvec

## tinyvec_macros 0.1.1

- Licence: `MIT OR Apache-2.0 OR Zlib`
- Source: https://github.com/Soveu/tinyvec_macros

## tokenizers 0.21.4

- Licence: `Apache-2.0`
- Source: https://github.com/huggingface/tokenizers

## tokenizers 0.23.2

- Licence: `Apache-2.0`
- Source: https://github.com/huggingface/tokenizers

## tokio 1.53.1

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tokio

## tokio 1.54.1

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tokio

## tokio-macros 2.7.0

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tokio

## tokio-macros 2.7.2

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tokio

## tokio-rayon 2.1.0

- Licence: `MIT`
- Source: https://github.com/andybarron/tokio-rayon

## tokio-rustls 0.26.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rustls/tokio-rustls

## tokio-rustls 0.26.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rustls/tokio-rustls

## tokio-stream 0.1.19

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tokio

## tokio-tungstenite 0.28.0

- Licence: `MIT`
- Source: https://github.com/snapview/tokio-tungstenite

## tokio-tungstenite 0.30.0

- Licence: `MIT`
- Source: https://github.com/snapview/tokio-tungstenite

## tokio-util 0.7.18

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tokio

## tokio-util 0.7.19

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tokio

## toktrie 1.8.0

- Licence: `MIT`
- Source: https://github.com/guidance-ai/llguidance

## toktrie_hf_tokenizers 1.8.0

- Licence: `MIT`
- Source: https://github.com/guidance-ai/llguidance

## toml 0.8.23

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml 0.9.12+spec-1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml 1.1.2+spec-1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml_datetime 0.6.11

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml_datetime 0.7.5+spec-1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml_datetime 1.1.1+spec-1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml_edit 0.22.27

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml_parser 1.1.2+spec-1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml_parser 1.1.3+spec-1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml_write 0.1.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml_writer 1.1.1+spec-1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml_writer 1.1.2+spec-1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## tower 0.5.3

- Licence: `MIT`
- Source: https://github.com/tower-rs/tower

## tower-http 0.6.11

- Licence: `MIT`
- Source: https://github.com/tower-rs/tower-http

## tower-layer 0.3.3

- Licence: `MIT`
- Source: https://github.com/tower-rs/tower

## tower-service 0.3.3

- Licence: `MIT`
- Source: https://github.com/tower-rs/tower

## tqdm 0.8.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/mrlazy1708/tqdm

## tracing 0.1.44

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-appender 0.2.5

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-attributes 0.1.31

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-core 0.1.36

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-futures 0.2.5

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-log 0.2.0

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-serde 0.2.0

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-subscriber 0.3.23

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## transpose 0.2.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/ejmahler/transpose

## tray-icon 0.25.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/tauri-apps/tray-icon

## try-lock 0.2.5

- Licence: `MIT`
- Source: https://github.com/seanmonstar/try-lock

## ttf-parser 0.25.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/harfbuzz/ttf-parser

## tungstenite 0.28.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/snapview/tungstenite-rs

## tungstenite 0.30.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/snapview/tungstenite-rs

## turso 0.8.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_core 0.8.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_ext 0.8.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_macros 0.8.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_parser 0.8.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_sdk_kit 0.8.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_sdk_kit_macros 0.8.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_sync_engine 0.8.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_sync_sdk_kit 0.8.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## two-face 0.4.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/CosmicHorrorDev/two-face

## twox-hash 2.1.2

- Licence: `MIT`
- Source: https://github.com/shepmaster/twox-hash

## typed-arena 2.0.2

- Licence: `MIT`
- Source: https://github.com/SimonSapin/rust-typed-arena

## typed-path 0.12.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/chipsenkbeil/typed-path

## typeid 1.0.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/typeid

## typenum 1.20.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/paholg/typenum

## typetag 0.2.22

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/typetag

## typetag-impl 0.2.22

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/typetag

## typst 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## typst-assets 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst-assets

## typst-eval 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## typst-html 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## typst-kit 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## typst-layout 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## typst-library 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## typst-macros 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## typst-pdf 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## typst-realize 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## typst-svg 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## typst-syntax 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## typst-timing 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## typst-utils 0.15.1

- Licence: `Apache-2.0`
- Source: https://github.com/typst/typst

## uncased 0.9.10

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/SergioBenitez/uncased

## unchecked-index 0.2.2

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/bluss/unchecked-index

## unic-langid 0.9.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/zbraniecki/unic-locale

## unic-langid-impl 0.9.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/zbraniecki/unic-locale

## unic-langid-macros 0.9.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/zbraniecki/unic-locale

## unic-langid-macros-impl 0.9.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/zbraniecki/unic-locale

## unicase 2.9.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/seanmonstar/unicase

## unicode_categories 0.1.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/swgillespie/unicode-categories

## unicode-bidi 0.3.18

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/unicode-bidi

## unicode-bidi-mirroring 0.4.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/RazrFalcon/unicode-bidi-mirroring

## unicode-ccc 0.4.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/RazrFalcon/unicode-ccc

## unicode-ident 1.0.24

- Licence: `(MIT OR Apache-2.0) AND Unicode-3.0`
- Source: https://github.com/dtolnay/unicode-ident

## unicode-math-class 0.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/typst/unicode-math-class

## unicode-normalization 0.1.26

- Licence: `(MIT OR Apache-2.0) AND Unicode-3.0`
- Source: https://github.com/unicode-rs/unicode-normalization

## unicode-normalization-alignments 0.1.12

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/n1t0/unicode-normalization

## unicode-properties 0.1.4

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/unicode-rs/unicode-properties

## unicode-script 0.5.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/unicode-rs/unicode-script

## unicode-security 0.1.2

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/unicode-rs/unicode-security

## unicode-segmentation 1.13.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/unicode-rs/unicode-segmentation

## unicode-vo 0.1.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/RazrFalcon/unicode-vo

## unicode-width 0.1.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/unicode-rs/unicode-width

## unicode-width 0.2.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/unicode-rs/unicode-width

## unit-prefix 0.5.2

- Licence: `MIT`
- Source: https://codeberg.org/commons-rs/unit-prefix

## universal-hash 0.5.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## unsafe-libyaml 0.2.11

- Licence: `MIT`
- Source: https://github.com/dtolnay/unsafe-libyaml

## unscanny 0.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/typst/unscanny

## untrusted 0.9.0

- Licence: `ISC`
- Source: https://github.com/briansmith/untrusted

## ureq 2.12.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/algesten/ureq

## ureq 3.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/algesten/ureq

## ureq-proto 0.6.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/algesten/ureq-proto

## url 2.5.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-url

## urlencoding 2.1.3

- Licence: `MIT`
- Source: https://github.com/kornelski/rust_urlencoding

## urlpattern 0.6.0

- Licence: `MIT`
- Source: https://github.com/denoland/rust-urlpattern

## usvg 0.47.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/resvg

## utf-8 0.7.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/SimonSapin/rust-utf8

## utf16_iter 1.0.5

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/hsivonen/utf16_iter

## utf8_iter 1.0.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/hsivonen/utf8_iter

## utf8-ranges 1.0.5

- Licence: `Unlicense/MIT`
- Source: https://github.com/BurntSushi/utf8-ranges

## utf8-zero 0.8.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/algesten/utf8-zero

## utf8parse 0.2.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/alacritty/vte

## utoipa 5.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/juhaku/utoipa

## utoipa-gen 5.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/juhaku/utoipa

## uuid 0.8.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/uuid-rs/uuid

## uuid 1.26.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/uuid-rs/uuid

## uuid 1.28.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/uuid-rs/uuid

## v_frame 0.3.9

- Licence: `BSD-2-Clause`
- Source: https://github.com/rust-av/v_frame

## variantly 0.4.0

- Licence: `MIT`
- Source: https://github.com/luker-os/variantly

## vello_common 0.0.8

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/vello

## vello_common 0.0.9

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/vello

## vello_cpu 0.0.8

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/linebender/vello

## vob 3.0.6

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/softdevteam/vob/

## walkdir 2.5.0

- Licence: `Unlicense/MIT`
- Source: https://github.com/BurntSushi/walkdir

## want 0.3.1

- Licence: `MIT`
- Source: https://github.com/seanmonstar/want

## want 0.3.2

- Licence: `MIT`
- Source: https://github.com/seanmonstar/want

## wasm-bindgen 0.2.128

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/wasm-bindgen/wasm-bindgen

## wasm-bindgen-macro 0.2.128

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/wasm-bindgen/wasm-bindgen/tree/master/crates/macro

## wasm-bindgen-macro-support 0.2.128

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/wasm-bindgen/wasm-bindgen/tree/main/crates/macro-support

## wasm-bindgen-shared 0.2.128

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/wasm-bindgen/wasm-bindgen/tree/master/crates/shared

## wasmi 1.1.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/wasmi-labs/wasmi

## wasmi_collections 1.1.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/wasmi-labs/wasmi

## wasmi_core 1.1.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/wasmi-labs/wasmi

## wasmi_ir 1.1.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/wasmi-labs/wasmi

## wasmparser 0.239.0

- Licence: `Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT`
- Source: https://github.com/bytecodealliance/wasm-tools/tree/main/crates/wasmparser

## web_atoms 0.2.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## web_atoms 0.2.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## web-time 1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/daxpedda/web-time

## webpki-root-certs 1.0.11

- Licence: `CDLA-Permissive-2.0`
- Source: https://github.com/rustls/webpki-roots

## webpki-roots 0.26.11

- Licence: `CDLA-Permissive-2.0`
- Source: https://github.com/rustls/webpki-roots

## webpki-roots 1.0.11

- Licence: `CDLA-Permissive-2.0`
- Source: https://github.com/rustls/webpki-roots

## webpki-roots 1.0.9

- Licence: `CDLA-Permissive-2.0`
- Source: https://github.com/rustls/webpki-roots

## weezl 0.1.12

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/image-rs/weezl

## wide 0.7.33

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/wide

## window-vibrancy 0.8.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri-plugin-vibrancy

## winnow 0.7.15

- Licence: `MIT`
- Source: https://github.com/winnow-rs/winnow

## winnow 1.0.3

- Licence: `MIT`
- Source: https://github.com/winnow-rs/winnow

## winnow 1.0.4

- Licence: `MIT`
- Source: https://github.com/winnow-rs/winnow

## write-fonts 0.48.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/googlefonts/fontations

## write16 1.0.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/hsivonen/write16

## writeable 0.6.3

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## writeable 0.6.4

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## wry 0.57.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/wry

## x25519-dalek 2.0.1

- Licence: `BSD-3-Clause`
- Source: https://github.com/dalek-cryptography/curve25519-dalek/tree/main/x25519-dalek

## xattr 1.6.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Stebalien/xattr

## xmlwriter 0.1.0

- Licence: `MIT`
- Source: https://github.com/RazrFalcon/xmlwriter

## xmp-writer 0.3.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/typst/xmp-writer

## y4m 0.8.0

- Licence: `MIT`
- Source: https://github.com/image-rs/y4m.git

## yaml-rust 0.4.5

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/chyh1990/yaml-rust

## yoke 0.8.3

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## yoke-derive 0.8.2

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## yrs 0.27.4

- Licence: `MIT`
- Source: https://github.com/y-crdt/y-crdt/

## zerocopy 0.8.52

- Licence: `BSD-2-Clause OR Apache-2.0 OR MIT`
- Source: https://github.com/google/zerocopy

## zerocopy 0.8.57

- Licence: `BSD-2-Clause OR Apache-2.0 OR MIT`
- Source: https://github.com/google/zerocopy

## zerocopy-derive 0.8.52

- Licence: `BSD-2-Clause OR Apache-2.0 OR MIT`
- Source: https://github.com/google/zerocopy

## zerocopy-derive 0.8.57

- Licence: `BSD-2-Clause OR Apache-2.0 OR MIT`
- Source: https://github.com/google/zerocopy

## zerofrom 0.1.8

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zerofrom-derive 0.1.7

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zeroize 1.9.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/utils

## zeroize 1.9.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/utils

## zeroize_derive 1.5.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/utils

## zerotrie 0.2.4

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zerotrie 0.2.5

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zerovec 0.11.6

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zerovec 0.11.8

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zerovec-derive 0.11.3

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zerovec-derive 0.11.6

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zip 9.0.5

- Licence: `MIT`
- Source: https://github.com/zip-rs/zip2

## zlib-rs 0.6.7

- Licence: `Zlib`
- Source: https://github.com/trifectatechfoundation/zlib-rs

## zmij 1.0.21

- Licence: `MIT`
- Source: https://github.com/dtolnay/zmij

## zmij 1.0.23

- Licence: `MIT`
- Source: https://github.com/dtolnay/zmij

## zopfli 0.8.3

- Licence: `Apache-2.0`
- Source: https://github.com/zopfli-rs/zopfli

## zopfli 0.8.4

- Licence: `Apache-2.0`
- Source: https://github.com/zopfli-rs/zopfli

## zstd 0.13.3

- Licence: `MIT`
- Source: https://github.com/gyscos/zstd-rs

## zstd-safe 7.3.0

- Licence: `BSD-3-Clause`
- Source: https://github.com/gyscos/zstd-rs

## zstd-sys 2.1.2+zstd.1.5.7

- Licence: `BSD-3-Clause`
- Source: https://github.com/gyscos/zstd-rs

## zune-core 0.5.3

- Licence: `MIT OR Apache-2.0 OR Zlib`
- Source: https://github.com/etemesi254/zune-image

## zune-inflate 0.2.54

- Licence: `MIT OR Apache-2.0 OR Zlib`
- Source: https://github.com/etemesi254/zune-image/tree/main/zune-inflate

## zune-jpeg 0.5.15

- Licence: `MIT OR Apache-2.0 OR Zlib`
- Source: https://github.com/etemesi254/zune-image/tree/dev/crates/zune-jpeg

## Bundled native libraries

## ONNX Runtime 1.24.2

- Licence: `MIT`
- Source: https://github.com/microsoft/onnxruntime/tree/v1.24.2
- Linked by: ort-sys 2.0.0-rc.12 (statically linked into the Sweetheart speech worker)

#### LICENSE

```text
MIT License

Copyright (c) Microsoft Corporation

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

#### ThirdPartyNotices.txt

```text
THIRD PARTY SOFTWARE NOTICES AND INFORMATION

Do Not Translate or Localize

This software incorporates material from third parties. Microsoft makes certain
open source code available at http://3rdpartysource.microsoft.com, or you may
send a check or money order for US $5.00, including the product name, the open
source component name, and version number, to:

Source Code Compliance Team
Microsoft Corporation
One Microsoft Way
Redmond, WA 98052
USA

Notwithstanding any other terms, you may reverse engineer this software to the
extent required to debug changes to any libraries licensed under the GNU Lesser
General Public License.

_____

Intel Math Kernel Library (Intel MKL)

Intel Simplified Software License (Version April 2018)

Copyright (c) 2018 Intel Corporation.

Use and Redistribution.  You may use and redistribute the software (the “Software”), without modification,
provided the following conditions are met:

* Redistributions must reproduce the above copyright notice and the following terms of use in the Software
and in the documentation and/or other materials provided with the distribution.

* Neither the name of Intel nor the names of its suppliers may be used to endorse or promote products
derived from this Software without specific prior written permission.

* No reverse engineering, decompilation, or disassembly of this Software is permitted.

Limited patent license.  Intel grants you a world-wide, royalty-free, non-exclusive license under patents it now
or hereafter owns or controls to make, have made, use, import, offer to sell and sell (“Utilize”) this Software,
but solely to the extent that any such patent is necessary to Utilize the Software alone. The patent license
shall not apply to any combinations which include this software.  No hardware per se is licensed hereunder.

Third party and other Intel programs.  “Third Party Programs” are the files listed in the “third-party-programs.txt”
text file that is included with the Software and may include Intel programs under separate license terms.
Third Party Programs, even if included with the distribution of the Materials, are governed by
separate license terms and those license terms solely govern your use of those programs.

DISCLAIMER.  THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT ARE DISCLAIMED. THIS SOFTWARE IS
NOT INTENDED FOR USE IN SYSTEMS OR APPLICATIONS WHERE FAILURE OF THE SOFTWARE
MAY CAUSE PERSONAL INJURY OR DEATH AND YOU AGREE THAT YOU ARE FULLY RESPONSIBLE FOR ANY
CLAIMS, COSTS, DAMAGES, EXPENSES, AND ATTORNEYS’ FEES ARISING OUT OF ANY SUCH USE,
EVEN IF ANY CLAIM ALLEGES THAT INTEL WAS NEGLIGENT REGARDING THE DESIGN OR MANUFACTURE OF
THE MATERIALS.

LIMITATION OF LIABILITY. IN NO EVENT WILL INTEL BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE. YOU AGREE TO INDEMNIFY AND HOLD INTEL HARMLESS AGAINST ANY CLAIMS
AND EXPENSES RESULTING FROM YOUR USE OR UNAUTHORIZED USE OF THE SOFTWARE.

No support.  Intel may make changes to the Software, at any time without notice, and is not obligated to
support, update or provide training for the Software.

Termination. Intel may terminate your right to use the Software in the event of your breach of this Agreement
and you fail to cure the breach within a reasonable period of time.

Feedback.  Should you provide Intel with comments, modifications, corrections, enhancements or other input
(“Feedback”) related to the Software Intel will be free to use, disclose, reproduce, license or otherwise
distribute or exploit the Feedback in its sole discretion without any obligations or restrictions of any kind,
including without limitation, intellectual property rights or licensing obligations.

Compliance with laws.  You agree to comply with all relevant laws and regulations governing your use,
transfer, import or export (or prohibition thereof) of the Software.

Governing law.  All disputes will be governed by the laws of the United States of America and the State of
Delaware without reference to conflict of law principles and subject to the exclusive jurisdiction of the state or
federal courts sitting in the State of Delaware, and each party agrees that it submits to the personal
jurisdiction and venue of those courts and waives any objections. The United Nations Convention on
Contracts for the International Sale of Goods (1980) is specifically excluded and will not apply to the
Software.

*Other names and brands may be claimed as the property of others.

_____

protocolbuffers/protobuf

Copyright 2008 Google Inc.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the
distribution.

    * Neither the name of Google Inc. nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Code generated by the Protocol Buffer compiler is owned by the owner
of the input file used when generating it.  This code is not
standalone and requires a support library to be linked with it.  This
support library is itself covered by the above license.

_____

madler/zlib

The deflate format used by zlib was defined by Phil Katz.  The deflate and
zlib specifications were written by L.  Peter Deutsch.  Thanks to all the
people who reported problems and suggested various improvements in zlib; they
are too numerous to cite here.

Copyright notice:

 (C) 1995-2017 Jean-loup Gailly and Mark Adler

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.

  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.

  3. This notice may not be removed or altered from any source distribution.

  Jean-loup Gailly        Mark Adler
  jloup@gzip.org          madler@alumni.caltech.edu

If you use the zlib library in a product, we would appreciate *not* receiving
lengthy legal documents to sign.  The sources are provided for free but without
warranty of any kind.  The library has been entirely written by Jean-loup
Gailly and Mark Adler; it does not include third-party code.

If you redistribute modified sources, we would appreciate that you include in
the file ChangeLog history information documenting your changes.  Please read
the FAQ for more information on the distribution of modified source versions.

_____

pybind/pybind11

Copyright (c) 2016 Wenzel Jakob <wenzel.jakob@epfl.ch>, All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Please also refer to the file CONTRIBUTING.md, which clarifies licensing of
external contributions to this project including patches, pull requests, etc.

_____

onnx
Open Neural Network Exchange

Copyright (c) Facebook, Inc. and Microsoft Corporation. All rights reserved.

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

_____

Eigen

MPL v2.0
Mozilla Public License Version 2.0


==================================

1. Definitions

--------------

1.1. "Contributor"
    means each individual or legal entity that creates, contributes to
    the creation of, or owns Covered Software.

1.2. "Contributor Version"
    means the combination of the Contributions of others (if any) used
    by a Contributor and that particular Contributor's Contribution.

1.3. "Contribution"
    means Covered Software of a particular Contributor.

1.4. "Covered Software"
    means Source Code Form to which the initial Contributor has attached
    the notice in Exhibit A, the Executable Form of such Source Code
    Form, and Modifications of such Source Code Form, in each case
    including portions thereof.

1.5. "Incompatible With Secondary Licenses"
    means

    (a) that the initial Contributor has attached the notice described
        in Exhibit B to the Covered Software; or

    (b) that the Covered Software was made available under the terms of
        version 1.1 or earlier of the License, but not also under the
        terms of a Secondary License.

1.6. "Executable Form"
    means any form of the work other than Source Code Form.

1.7. "Larger Work"
    means a work that combines Covered Software with other material, in
    a separate file or files, that is not Covered Software.

1.8. "License"
    means this document.

1.9. "Licensable"
    means having the right to grant, to the maximum extent possible,
    whether at the time of the initial grant or subsequently, any and
    all of the rights conveyed by this License.

1.10. "Modifications"
    means any of the following:

    (a) any file in Source Code Form that results from an addition to,
        deletion from, or modification of the contents of Covered
        Software; or

    (b) any new file in Source Code Form that contains any Covered
        Software.

1.11. "Patent Claims" of a Contributor
    means any patent claim(s), including without limitation, method,
    process, and apparatus claims, in any patent Licensable by such
    Contributor that would be infringed, but for the grant of the
    License, by the making, using, selling, offering for sale, having
    made, import, or transfer of either its Contributions or its
    Contributor Version.

1.12. "Secondary License"
    means either the GNU General Public License, Version 2.0, the GNU
    Lesser General Public License, Version 2.1, the GNU Affero General
    Public License, Version 3.0, or any later versions of those
    licenses.

1.13. "Source Code Form"
    means the form of the work preferred for making modifications.

1.14. "You" (or "Your")
    means an individual or a legal entity exercising rights under this
    License. For legal entities, "You" includes any entity that
    controls, is controlled by, or is under common control with You. For
    purposes of this definition, "control" means (a) the power, direct
    or indirect, to cause the direction or management of such entity,
    whether by contract or otherwise, or (b) ownership of more than
    fifty percent (50%) of the outstanding shares or beneficial
    ownership of such entity.

2. License Grants and Conditions

--------------------------------

2.1. Grants

Each Contributor hereby grants You a world-wide, royalty-free,
non-exclusive license:

(a) under intellectual property rights (other than patent or trademark)
    Licensable by such Contributor to use, reproduce, make available,
    modify, display, perform, distribute, and otherwise exploit its
    Contributions, either on an unmodified basis, with Modifications, or
    as part of a Larger Work; and

(b) under Patent Claims of such Contributor to make, use, sell, offer
    for sale, have made, import, and otherwise transfer either its
    Contributions or its Contributor Version.

2.2. Effective Date

The licenses granted in Section 2.1 with respect to any Contribution
become effective for each Contribution on the date the Contributor first
distributes such Contribution.

2.3. Limitations on Grant Scope

The licenses granted in this Section 2 are the only rights granted under
this License. No additional rights or licenses will be implied from the
distribution or licensing of Covered Software under this License.
Notwithstanding Section 2.1(b) above, no patent license is granted by a
Contributor:

(a) for any code that a Contributor has removed from Covered Software;
    or

(b) for infringements caused by: (i) Your and any other third party's
    modifications of Covered Software, or (ii) the combination of its
    Contributions with other software (except as part of its Contributor
    Version); or

(c) under Patent Claims infringed by Covered Software in the absence of
    its Contributions.

This License does not grant any rights in the trademarks, service marks,
or logos of any Contributor (except as may be necessary to comply with
the notice requirements in Section 3.4).

2.4. Subsequent Licenses

No Contributor makes additional grants as a result of Your choice to
distribute the Covered Software under a subsequent version of this
License (see Section 10.2) or under the terms of a Secondary License (if
permitted under the terms of Section 3.3).

2.5. Representation

Each Contributor represents that the Contributor believes its
Contributions are its original creation(s) or it has sufficient rights
to grant the rights to its Contributions conveyed by this License.

2.6. Fair Use

This License is not intended to limit any rights You have under
applicable copyright doctrines of fair use, fair dealing, or other
equivalents.

2.7. Conditions

Sections 3.1, 3.2, 3.3, and 3.4 are conditions of the licenses granted
in Section 2.1.

3. Responsibilities

-------------------

3.1. Distribution of Source Form

All distribution of Covered Software in Source Code Form, including any
Modifications that You create or to which You contribute, must be under
the terms of this License. You must inform recipients that the Source
Code Form of the Covered Software is governed by the terms of this
License, and how they can obtain a copy of this License. You may not
attempt to alter or restrict the recipients' rights in the Source Code
Form.

3.2. Distribution of Executable Form

If You distribute Covered Software in Executable Form then:

(a) such Covered Software must also be made available in Source Code
    Form, as described in Section 3.1, and You must inform recipients of
    the Executable Form how they can obtain a copy of such Source Code
    Form by reasonable means in a timely manner, at a charge no more
    than the cost of distribution to the recipient; and

(b) You may distribute such Executable Form under the terms of this
    License, or sublicense it under different terms, provided that the
    license for the Executable Form does not attempt to limit or alter
    the recipients' rights in the Source Code Form under this License.

3.3. Distribution of a Larger Work

You may create and distribute a Larger Work under terms of Your choice,
provided that You also comply with the requirements of this License for
the Covered Software. If the Larger Work is a combination of Covered
Software with a work governed by one or more Secondary Licenses, and the
Covered Software is not Incompatible With Secondary Licenses, this
License permits You to additionally distribute such Covered Software
under the terms of such Secondary License(s), so that the recipient of
the Larger Work may, at their option, further distribute the Covered
Software under the terms of either this License or such Secondary
License(s).

3.4. Notices

You may not remove or alter the substance of any license notices
(including copyright notices, patent notices, disclaimers of warranty,
or limitations of liability) contained within the Source Code Form of
the Covered Software, except that You may alter any license notices to
the extent required to remedy known factual inaccuracies.

3.5. Application of Additional Terms

You may choose to offer, and to charge a fee for, warranty, support,
indemnity or liability obligations to one or more recipients of Covered
Software. However, You may do so only on Your own behalf, and not on
behalf of any Contributor. You must make it absolutely clear that any
such warranty, support, indemnity, or liability obligation is offered by
You alone, and You hereby agree to indemnify every Contributor for any
liability incurred by such Contributor as a result of warranty, support,
indemnity or liability terms You offer. You may include additional
disclaimers of warranty and limitations of liability specific to any
jurisdiction.

4. Inability to Comply Due to Statute or Regulation

---------------------------------------------------

If it is impossible for You to comply with any of the terms of this
License with respect to some or all of the Covered Software due to
statute, judicial order, or regulation then You must: (a) comply with
the terms of this License to the maximum extent possible; and (b)
describe the limitations and the code they affect. Such description must
be placed in a text file included with all distributions of the Covered
Software under this License. Except to the extent prohibited by statute
or regulation, such description must be sufficiently detailed for a
recipient of ordinary skill to be able to understand it.

5. Termination

--------------

5.1. The rights granted under this License will terminate automatically
if You fail to comply with any of its terms. However, if You become
compliant, then the rights granted under this License from a particular
Contributor are reinstated (a) provisionally, unless and until such
Contributor explicitly and finally terminates Your grants, and (b) on an
ongoing basis, if such Contributor fails to notify You of the
non-compliance by some reasonable means prior to 60 days after You have
come back into compliance. Moreover, Your grants from a particular
Contributor are reinstated on an ongoing basis if such Contributor
notifies You of the non-compliance by some reasonable means, this is the
first time You have received notice of non-compliance with this License
from such Contributor, and You become compliant prior to 30 days after
Your receipt of the notice.

5.2. If You initiate litigation against any entity by asserting a patent
infringement claim (excluding declaratory judgment actions,
counter-claims, and cross-claims) alleging that a Contributor Version
directly or indirectly infringes any patent, then the rights granted to
You by any and all Contributors for the Covered Software under Section
2.1 of this License shall terminate.

5.3. In the event of termination under Sections 5.1 or 5.2 above, all
end user license agreements (excluding distributors and resellers) which
have been validly granted by You or Your distributors under this License
prior to termination shall survive termination.

************************************************************************
*                                                                      *
*  6. Disclaimer of Warranty                                           *
*  -------------------------                                           *
*                                                                      *
*  Covered Software is provided under this License on an "as is"       *
*  basis, without warranty of any kind, either expressed, implied, or  *
*  statutory, including, without limitation, warranties that the       *
*  Covered Software is free of defects, merchantable, fit for a        *
*  particular purpose or non-infringing. The entire risk as to the     *
*  quality and performance of the Covered Software is with You.        *
*  Should any Covered Software prove defective in any respect, You     *
*  (not any Contributor) assume the cost of any necessary servicing,   *
*  repair, or correction. This disclaimer of warranty constitutes an   *
*  essential part of this License. No use of any Covered Software is   *
*  authorized under this License except under this disclaimer.         *
*                                                                      *
************************************************************************

************************************************************************
*                                                                      *
*  7. Limitation of Liability                                          *
*  --------------------------                                          *
*                                                                      *
*  Under no circumstances and under no legal theory, whether tort      *
*  (including negligence), contract, or otherwise, shall any           *
*  Contributor, or anyone who distributes Covered Software as          *
*  permitted above, be liable to You for any direct, indirect,         *
*  special, incidental, or consequential damages of any character      *
*  including, without limitation, damages for lost profits, loss of    *
*  goodwill, work stoppage, computer failure or malfunction, or any    *
*  and all other commercial damages or losses, even if such party      *
*  shall have been informed of the possibility of such damages. This   *
*  limitation of liability shall not apply to liability for death or   *
*  personal injury resulting from such party's negligence to the       *
*  extent applicable law prohibits such limitation. Some               *
*  jurisdictions do not allow the exclusion or limitation of           *
*  incidental or consequential damages, so this exclusion and          *
*  limitation may not apply to You.                                    *
*                                                                      *
************************************************************************
8. Litigation
-------------

Any litigation relating to this License may be brought only in the
courts of a jurisdiction where the defendant maintains its principal
place of business and such litigation shall be governed by laws of that
jurisdiction, without reference to its conflict-of-law provisions.
Nothing in this Section shall prevent a party's ability to bring
cross-claims or counter-claims.

9. Miscellaneous
----------------

This License represents the complete agreement concerning the subject
matter hereof. If any provision of this License is held to be
unenforceable, such provision shall be reformed only to the extent
necessary to make it enforceable. Any law or regulation which provides
that the language of a contract shall be construed against the drafter
shall not be used to construe this License against a Contributor.

10. Versions of the License
---------------------------

10.1. New Versions

Mozilla Foundation is the license steward. Except as provided in Section
10.3, no one other than the license steward has the right to modify or
publish new versions of this License. Each version will be given a
distinguishing version number.

10.2. Effect of New Versions

You may distribute the Covered Software under the terms of the version
of the License under which You originally received the Covered Software,
or under the terms of any subsequent version published by the license
steward.

10.3. Modified Versions

If you create software not governed by this License, and you want to
create a new license for such software, you may create and use a
modified version of this License if you rename the license and remove
any references to the name of the license steward (except to note that
such modified license differs from this License).

10.4. Distributing Source Code Form that is Incompatible With Secondary
Licenses

If You choose to distribute Source Code Form that is Incompatible With
Secondary Licenses under the terms of this version of the License, the
notice described in Exhibit B of this License must be attached.

Exhibit A - Source Code Form License Notice
-------------------------------------------

  This Source Code Form is subject to the terms of the Mozilla Public
  License, v. 2.0. If a copy of the MPL was not distributed with this
  file, You can obtain one at http://mozilla.org/MPL/2.0/.

If it is not possible or desirable to put the notice in a particular
file, then You may include the notice in a location (such as a LICENSE
file in a relevant directory) where a recipient would be likely to look
for such a notice.

You may add additional accurate notices of copyright ownership.

Exhibit B - "Incompatible With Secondary Licenses" Notice
---------------------------------------------------------

  This Source Code Form is "Incompatible With Secondary Licenses", as
  defined by the Mozilla Public License, v. 2.0.

_____

intel/dnnl

Copyright 2016-2018 Intel Corporation

Apache License
Version 2.0, January 2004
http://www.apache.org/licenses/

TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "{}"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright {yyyy} {name of copyright owner}

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

sub-components:

xbyak

Copyright (c) 2007 MITSUNARI Shigeo. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
Neither the name of the copyright owner nor the names of its contributors may
be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.

_____

Microsoft GSL

Copyright (c) 2015 Microsoft Corporation. All rights reserved.

This code is licensed under the MIT License (MIT).

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

_____

Tensorflow

Copyright 2018 The TensorFlow Authors. All rights reserved.

Apache License
Version 2.0, January 2004
http://www.apache.org/licenses/

TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

1. Definitions.

"License" shall mean the terms and conditions for use, reproduction,
and distribution as defined by Sections 1 through 9 of this document.

"Licensor" shall mean the copyright owner or entity authorized by
the copyright owner that is granting the License.

"Legal Entity" shall mean the union of the acting entity and all
other entities that control, are controlled by, or are under common
control with that entity. For the purposes of this definition,
"control" means (i) the power, direct or indirect, to cause the
direction or management of such entity, whether by contract or
otherwise, or (ii) ownership of fifty percent (50%) or more of the
outstanding shares, or (iii) beneficial ownership of such entity.

"You" (or "Your") shall mean an individual or Legal Entity
exercising permissions granted by this License.

"Source" form shall mean the preferred form for making modifications,
including but not limited to software source code, documentation
source, and configuration files.

"Object" form shall mean any form resulting from mechanical
transformation or translation of a Source form, including but
not limited to compiled object code, generated documentation,
and conversions to other media types.

"Work" shall mean the work of authorship, whether in Source or
Object form, made available under the License, as indicated by a
copyright notice that is included in or attached to the work
(an example is provided in the Appendix below).

"Derivative Works" shall mean any work, whether in Source or Object
form, that is based on (or derived from) the Work and for which the
editorial revisions, annotations, elaborations, or other modifications
represent, as a whole, an original work of authorship. For the purposes
of this License, Derivative Works shall not include works that remain
separable from, or merely link (or bind by name) to the interfaces of,
the Work and Derivative Works thereof.

"Contribution" shall mean any work of authorship, including
the original version of the Work and any modifications or additions
to that Work or Derivative Works thereof, that is intentionally
submitted to Licensor for inclusion in the Work by the copyright owner
or by an individual or Legal Entity authorized to submit on behalf of
the copyright owner. For the purposes of this definition, "submitted"
means any form of electronic, verbal, or written communication sent
to the Licensor or its representatives, including but not limited to
communication on electronic mailing lists, source code control systems,
and issue tracking systems that are managed by, or on behalf of, the
Licensor for the purpose of discussing and improving the Work, but
excluding communication that is conspicuously marked or otherwise
designated in writing by the copyright owner as "Not a Contribution."

"Contributor" shall mean Licensor and any individual or Legal Entity
on behalf of whom a Contribution has been received by Licensor and
subsequently incorporated within the Work.

2. Grant of Copyright License. Subject to the terms and conditions of
this License, each Contributor hereby grants to You a perpetual,
worldwide, non-exclusive, no-charge, royalty-free, irrevocable
copyright license to reproduce, prepare Derivative Works of,
publicly display, publicly perform, sublicense, and distribute the
Work and such Derivative Works in Source or Object form.

3. Grant of Patent License. Subject to the terms and conditions of
this License, each Contributor hereby grants to You a perpetual,
worldwide, non-exclusive, no-charge, royalty-free, irrevocable
(except as stated in this section) patent license to make, have made,
use, offer to sell, sell, import, and otherwise transfer the Work,
where such license applies only to those patent claims licensable
by such Contributor that are necessarily infringed by their
Contribution(s) alone or by combination of their Contribution(s)
with the Work to which such Contribution(s) was submitted. If You
institute patent litigation against any entity (including a
cross-claim or counterclaim in a lawsuit) alleging that the Work
or a Contribution incorporated within the Work constitutes direct
or contributory patent infringement, then any patent licenses
granted to You under this License for that Work shall terminate
as of the date such litigation is filed.

4. Redistribution. You may reproduce and distribute copies of the
Work or Derivative Works thereof in any medium, with or without
modifications, and in Source or Object form, provided that You
meet the following conditions:

(a) You must give any other recipients of the Work or
Derivative Works a copy of this License; and

(b) You must cause any modified files to carry prominent notices
stating that You changed the files; and

(c) You must retain, in the Source form of any Derivative Works
that You distribute, all copyright, patent, trademark, and
attribution notices from the Source form of the Work,
excluding those notices that do not pertain to any part of
the Derivative Works; and

(d) If the Work includes a "NOTICE" text file as part of its
distribution, then any Derivative Works that You distribute must
include a readable copy of the attribution notices contained
within such NOTICE file, excluding those notices that do not
pertain to any part of the Derivative Works, in at least one
of the following places: within a NOTICE text file distributed
as part of the Derivative Works; within the Source form or
documentation, if provided along with the Derivative Works; or,
within a display generated by the Derivative Works, if and
wherever such third-party notices normally appear. The contents
of the NOTICE file are for informational purposes only and
do not modify the License. You may add Your own attribution
notices within Derivative Works that You distribute, alongside
or as an addendum to the NOTICE text from the Work, provided
that such additional attribution notices cannot be construed
as modifying the License.

You may add Your own copyright statement to Your modifications and
may provide additional or different license terms and conditions
for use, reproduction, or distribution of Your modifications, or
for any such Derivative Works as a whole, provided Your use,
reproduction, and distribution of the Work otherwise complies with
the conditions stated in this License.

5. Submission of Contributions. Unless You explicitly state otherwise,
any Contribution intentionally submitted for inclusion in the Work
by You to the Licensor shall be under the terms and conditions of
this License, without any additional terms or conditions.
Notwithstanding the above, nothing herein shall supersede or modify
the terms of any separate license agreement you may have executed
with Licensor regarding such Contributions.

6. Trademarks. This License does not grant permission to use the trade
names, trademarks, service marks, or product names of the Licensor,
except as required for reasonable and customary use in describing the
origin of the Work and reproducing the content of the NOTICE file.

7. Disclaimer of Warranty. Unless required by applicable law or
agreed to in writing, Licensor provides the Work (and each
Contributor provides its Contributions) on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
implied, including, without limitation, any warranties or conditions
of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
PARTICULAR PURPOSE. You are solely responsible for determining the
appropriateness of using or redistributing the Work and assume any
risks associated with Your exercise of permissions under this License.

8. Limitation of Liability. In no event and under no legal theory,
whether in tort (including negligence), contract, or otherwise,
unless required by applicable law (such as deliberate and grossly
negligent acts) or agreed to in writing, shall any Contributor be
liable to You for damages, including any direct, indirect, special,
incidental, or consequential damages of any character arising as a
result of this License or out of the use or inability to use the
Work (including but not limited to damages for loss of goodwill,
work stoppage, computer failure or malfunction, or any and all
other commercial damages or losses), even if such Contributor
has been advised of the possibility of such damages.

9. Accepting Warranty or Additional Liability. While redistributing
the Work or Derivative Works thereof, You may choose to offer,
and charge a fee for, acceptance of support, warranty, indemnity,
or other liability obligations and/or rights consistent with this
License. However, in accepting such obligations, You may act only
on Your own behalf and on Your sole responsibility, not on behalf
of any other Contributor, and only if You agree to indemnify,
defend, and hold each Contributor harmless for any liability
incurred by, or claims asserted against, such Contributor by reason
of your accepting any such warranty or additional liability.

END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright 2017, The TensorFlow Authors.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

_____

Microsoft Cognitive Toolkit (CNTK)

Copyright (c) Microsoft Corporation. All rights reserved.

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

_____

NumPy License

Copyright (c) 2005, NumPy Developers

All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

    Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
    Neither the name of the NumPy Developers nor the names of any contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

_____

Pytorch / Caffe2

From PyTorch:

Copyright (c) 2016-     Facebook, Inc            (Adam Paszke)
Copyright (c) 2014-     Facebook, Inc            (Soumith Chintala)
Copyright (c) 2011-2014 Idiap Research Institute (Ronan Collobert)
Copyright (c) 2012-2014 Deepmind Technologies    (Koray Kavukcuoglu)
Copyright (c) 2011-2012 NEC Laboratories America (Koray Kavukcuoglu)
Copyright (c) 2011-2013 NYU                      (Clement Farabet)
Copyright (c) 2006-2010 NEC Laboratories America (Ronan Collobert, Leon Bottou, Iain Melvin, Jason Weston)
Copyright (c) 2006      Idiap Research Institute (Samy Bengio)
Copyright (c) 2001-2004 Idiap Research Institute (Ronan Collobert, Samy Bengio, Johnny Mariethoz)

From Caffe2:

Copyright (c) 2016-present, Facebook Inc. All rights reserved.

All contributions by Facebook:
Copyright (c) 2016 Facebook Inc.

All contributions by Google:
Copyright (c) 2015 Google Inc.
All rights reserved.

All contributions by Yangqing Jia:
Copyright (c) 2015 Yangqing Jia
All rights reserved.

All contributions from Caffe:
Copyright(c) 2013, 2014, 2015, the respective contributors
All rights reserved.

All other contributions:
Copyright(c) 2015, 2016 the respective contributors
All rights reserved.

Caffe2 uses a copyright model similar to Caffe: each contributor holds
copyright over their contributions to Caffe2. The project versioning records
all such contribution and copyright details. If a contributor wants to further
mark their specific copyright on a particular contribution, they should
indicate their copyright solely in the commit message of the change when it is
committed. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. Neither the names of Facebook, Deepmind Technologies, NYU, NEC Laboratories America
   and IDIAP Research Institute nor the names of its contributors may be
   used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

_____

Caffe

COPYRIGHT

All contributions by the University of California:
Copyright (c) 2014-2017 The Regents of the University of California (Regents)
All rights reserved.

All other contributions:
Copyright (c) 2014-2017, the respective contributors
All rights reserved.

Caffe uses a shared copyright model: each contributor holds copyright over
their contributions to Caffe. The project versioning records all such
contribution and copyright details. If a contributor wants to further mark
their specific copyright on a particular contribution, they should indicate
their copyright solely in the commit message of the change when it is
committed.

LICENSE

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

CONTRIBUTION AGREEMENT

By contributing to the BVLC/caffe repository through pull-request, comment,
or otherwise, the contributor releases their content to the
license and copyright terms herein.

_____

The LLVM Compiler Infrastructure

==============================================================================
LLVM Release License
==============================================================================
University of Illinois/NCSA
Open Source License

Copyright (c) 2003-2017 University of Illinois at Urbana-Champaign.
All rights reserved.

Developed by:

    LLVM Team

    University of Illinois at Urbana-Champaign

    http://llvm.org

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal with
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimers.

    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimers in the
      documentation and/or other materials provided with the distribution.

    * Neither the names of the LLVM Team, University of Illinois at
      Urbana-Champaign, nor the names of its contributors may be used to
      endorse or promote products derived from this Software without specific
      prior written permission.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS WITH THE
SOFTWARE.

==============================================================================
Copyrights and Licenses for Third Party Software Distributed with LLVM:
==============================================================================
The LLVM software contains code written by third parties.  Such software will
have its own individual LICENSE.TXT file in the directory in which it appears.
This file will describe the copyrights, license, and restrictions which apply
to that code.

The disclaimer of warranty in the University of Illinois Open Source License
applies to all code in the LLVM Distribution, and nothing in any of the
other licenses gives permission to use the names of the LLVM Team or the
University of Illinois to endorse or promote products derived from this
Software.

The following pieces of software have additional or alternate copyrights,
licenses, and/or restrictions:

Program             Directory
-------             ---------
Google Test         llvm/utils/unittest/googletest
OpenBSD regex       llvm/lib/Support/{reg*, COPYRIGHT.regex}
pyyaml tests        llvm/test/YAMLParser/{*.data, LICENSE.TXT}
ARM contributions   llvm/lib/Target/ARM/LICENSE.TXT
md5 contributions   llvm/lib/Support/MD5.cpp llvm/include/llvm/Support/MD5.h

_____

google/benchmark


                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

CONTRIBUTORS

# People who have agreed to one of the CLAs and can contribute patches.
# The AUTHORS file lists the copyright holders; this file
# lists people.  For example, Google employees are listed here
# but not in AUTHORS, because Google holds the copyright.
#
# Names should be added to this file only after verifying that
# the individual or the individual's organization has agreed to
# the appropriate Contributor License Agreement, found here:
#
# https://developers.google.com/open-source/cla/individual
# https://developers.google.com/open-source/cla/corporate
#
# The agreement for individuals can be filled out on the web.
#
# When adding J Random Contributor's name to this file,
# either J's name or J's organization's name should be
# added to the AUTHORS file, depending on whether the
# individual or corporate CLA was used.
#
# Names should be added to this file as:
#     Name <email address>
#
# Please keep the list sorted.

Albert Pretorius <pretoalb@gmail.com>
Arne Beer <arne@twobeer.de>
Billy Robert O'Neal III <billy.oneal@gmail.com> <bion@microsoft.com>
Chris Kennelly <ckennelly@google.com> <ckennelly@ckennelly.com>
Christopher Seymour <chris.j.seymour@hotmail.com>
David Coeurjolly <david.coeurjolly@liris.cnrs.fr>
Deniz Evrenci <denizevrenci@gmail.com>
Dominic Hamon <dma@stripysock.com> <dominic@google.com>
Dominik Czarnota <dominik.b.czarnota@gmail.com>
Eric Fiselier <eric@efcs.ca>
Eugene Zhuk <eugene.zhuk@gmail.com>
Evgeny Safronov <division494@gmail.com>
Federico Ficarelli <federico.ficarelli@gmail.com>
Felix Homann <linuxaudio@showlabor.de>
Ismael Jimenez Martinez <ismael.jimenez.martinez@gmail.com>
Jern-Kuan Leong <jernkuan@gmail.com>
JianXiong Zhou <zhoujianxiong2@gmail.com>
Joao Paulo Magalhaes <joaoppmagalhaes@gmail.com>
John Millikin <jmillikin@stripe.com>
Jussi Knuuttila <jussi.knuuttila@gmail.com>
Kai Wolf <kai.wolf@gmail.com>
Kishan Kumar <kumar.kishan@outlook.com>
Kaito Udagawa <umireon@gmail.com>
Lei Xu <eddyxu@gmail.com>
Matt Clarkson <mattyclarkson@gmail.com>
Maxim Vafin <maxvafin@gmail.com>
Nick Hutchinson <nshutchinson@gmail.com>
Oleksandr Sochka <sasha.sochka@gmail.com>
Pascal Leroy <phl@google.com>
Paul Redmond <paul.redmond@gmail.com>
Pierre Phaneuf <pphaneuf@google.com>
Radoslav Yovchev <radoslav.tm@gmail.com>
Raul Marin <rmrodriguez@cartodb.com>
Ray Glover <ray.glover@uk.ibm.com>
Robert Guo <robert.guo@mongodb.com>
Roman Lebedev <lebedev.ri@gmail.com>
Shuo Chen <chenshuo@chenshuo.com>
Tobias Ulvgård <tobias.ulvgard@dirac.se>
Tom Madams <tom.ej.madams@gmail.com> <tmadams@google.com>
Yixuan Qiu <yixuanq@gmail.com>
Yusuke Suzuki <utatane.tea@gmail.com>
Zbigniew Skowron <zbychs@gmail.com>

AUTHORS

# This is the official list of benchmark authors for copyright purposes.
# This file is distinct from the CONTRIBUTORS files.
# See the latter for an explanation.
#
# Names should be added to this file as:
#	Name or Organization <email address>
# The email address is not required for organizations.
#
# Please keep the list sorted.

Albert Pretorius <pretoalb@gmail.com>
Arne Beer <arne@twobeer.de>
Carto
Christopher Seymour <chris.j.seymour@hotmail.com>
David Coeurjolly <david.coeurjolly@liris.cnrs.fr>
Deniz Evrenci <denizevrenci@gmail.com>
Dirac Research
Dominik Czarnota <dominik.b.czarnota@gmail.com>
Eric Fiselier <eric@efcs.ca>
Eugene Zhuk <eugene.zhuk@gmail.com>
Evgeny Safronov <division494@gmail.com>
Federico Ficarelli <federico.ficarelli@gmail.com>
Felix Homann <linuxaudio@showlabor.de>
Google Inc.
International Business Machines Corporation
Ismael Jimenez Martinez <ismael.jimenez.martinez@gmail.com>
Jern-Kuan Leong <jernkuan@gmail.com>
JianXiong Zhou <zhoujianxiong2@gmail.com>
Joao Paulo Magalhaes <joaoppmagalhaes@gmail.com>
Jussi Knuuttila <jussi.knuuttila@gmail.com>
Kaito Udagawa <umireon@gmail.com>
Kishan Kumar <kumar.kishan@outlook.com>
Lei Xu <eddyxu@gmail.com>
Matt Clarkson <mattyclarkson@gmail.com>
Maxim Vafin <maxvafin@gmail.com>
MongoDB Inc.
Nick Hutchinson <nshutchinson@gmail.com>
Oleksandr Sochka <sasha.sochka@gmail.com>
Paul Redmond <paul.redmond@gmail.com>
Radoslav Yovchev <radoslav.tm@gmail.com>
Roman Lebedev <lebedev.ri@gmail.com>
Shuo Chen <chenshuo@chenshuo.com>
Steinar H. Gunderson <sgunderson@bigfoot.com>
Stripe, Inc.
Yixuan Qiu <yixuanq@gmail.com>
Yusuke Suzuki <utatane.tea@gmail.com>
Zbigniew Skowron <zbychs@gmail.com>

_____

HalideIR

Copyright (c) 2016 HalideIR contributors
Copyright (c) 2012-2014 MIT CSAIL, Google Inc., and other contributors
HalideIR is derived from the Halide project.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

_____

Distributed Machine Learning Common Codebase

Copyright (c) 2015 by Contributors

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

_____

DLPack: Open In Memory Tensor Structure

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "{}"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright 2017 by Contributors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

_____

HowardHinnant/date

The source code in this project is released using the MIT License. There is no
global license for the project because each file is licensed individually with
different author names and/or dates.

If you contribute to this project, please add your name to the license of each
file you modify.  If you have already contributed to this project and forgot to
add your name to the license, please feel free to submit a new P/R to add your
name to the license in each file you modified.

For convenience, here is a copy of the MIT license found in each file except
without author names or dates:

The MIT License (MIT)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

_____

FreeBSD: getopt.c file

Copyright (c) 1987, 1993, 1994
The Regents of the University of California.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

 1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

3. Neither the name of the University nor the names of its contributors
may be used to endorse or promote products derived from this software
without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
_____


google/googletest

Copyright 2008, Google Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the
distribution.
    * Neither the name of Google Inc. nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

_____

G3log : Asynchronous logger with Dynamic Sinks

This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org/>
_____

Scikit-learn

Copyright (c) 2007–2018 The scikit-learn developers.
All rights reserved.


Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  a. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.
  b. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  c. Neither the name of the Scikit-learn Developers  nor the names of
     its contributors may be used to endorse or promote products
     derived from this software without specific prior written
     permission.


THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.

_____

google/re2

Copyright (c) 2009 The RE2 Authors. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

   * Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the
distribution.
  * Neither the name of Google Inc. nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
_____
onnx/onnx-tensorrt

MIT License

Copyright (c) 2018, NVIDIA CORPORATION. All rights reserved.
Copyright (c) 2018 Open Neural Network Exchange

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

_____
nvidia/cutlass

Copyright (c) 2017 - 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: BSD-3-Clause

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

_____
Boost

Boost Software License - Version 1.0 - August 17th, 2003

Permission is hereby granted, free of charge, to any person or organization
obtaining a copy of the software and accompanying documentation covered by
this license (the "Software") to use, reproduce, display, distribute,
execute, and transmit the Software, and to prepare derivative works of the
Software, and to permit third-parties to whom the Software is furnished to
do so, all subject to the following:

The copyright notices in the Software and this entire statement, including
the above license grant, this restriction and the following disclaimer,
must be included in all copies of the Software, in whole or in part, and
all derivative works of the Software, unless such copies or derivative
works are solely in the form of machine-executable object code generated by
a source language processor.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT
SHALL THE COPYRIGHT HOLDERS OR ANYONE DISTRIBUTING THE SOFTWARE BE LIABLE
FOR ANY DAMAGES OR OTHER LIABILITY, WHETHER IN CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


_____

JDAI-CV/DNNLibrary

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [2019] [JD.com Inc. JD AI]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.


_____

google/flatbuffers


                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright 2014 Google Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.


_____

google/glog

Copyright (c) 2008, Google Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the
distribution.
    * Neither the name of Google Inc. nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


A function gettimeofday in utilities.cc is based on

http://www.google.com/codesearch/p?hl=en#dR3YEbitojA/COPYING&q=GetSystemTimeAsFileTime%20license:bsd

The license of this code is:

Copyright (c) 2003-2008, Jouni Malinen <j@w1.fi> and contributors
All Rights Reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. Neither the name(s) of the above-listed copyright holder(s) nor the
   names of its contributors may be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

_____

abseil-cpp
https://github.com/abseil/abseil-cpp

                                 Apache License
                           Version 2.0, January 2004
                        https://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       https://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.


_____

microsoft/wil

MIT License

Copyright (c) Microsoft Corporation. All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE

_____

nlohmann/json

MIT License

Copyright (c) 2013-2019 Niels Lohmann

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

_____

dcleblanc/SafeInt

MIT License

Copyright (c) 2018 Microsoft

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

_____
Open MPI

3-Clause BSD License

Most files in this release are marked with the copyrights of the
organizations who have edited them.  The copyrights below are in no
particular order and generally reflect members of the Open MPI core
team who have contributed code to this release.  The copyrights for
code used under license from other parties are included in the
corresponding files.

Copyright (c) 2004-2010 The Trustees of Indiana University and Indiana
                        University Research and Technology
                        Corporation.  All rights reserved.
Copyright (c) 2004-2017 The University of Tennessee and The University
                        of Tennessee Research Foundation.  All rights
                        reserved.
Copyright (c) 2004-2010 High Performance Computing Center Stuttgart,
                        University of Stuttgart.  All rights reserved.
Copyright (c) 2004-2008 The Regents of the University of California.
                        All rights reserved.
Copyright (c) 2006-2017 Los Alamos National Security, LLC.  All rights
                        reserved.
Copyright (c) 2006-2017 Cisco Systems, Inc.  All rights reserved.
Copyright (c) 2006-2010 Voltaire, Inc. All rights reserved.
Copyright (c) 2006-2017 Sandia National Laboratories. All rights reserved.
Copyright (c) 2006-2010 Sun Microsystems, Inc.  All rights reserved.
                        Use is subject to license terms.
Copyright (c) 2006-2017 The University of Houston. All rights reserved.
Copyright (c) 2006-2009 Myricom, Inc.  All rights reserved.
Copyright (c) 2007-2017 UT-Battelle, LLC. All rights reserved.
Copyright (c) 2007-2017 IBM Corporation.  All rights reserved.
Copyright (c) 1998-2005 Forschungszentrum Juelich, Juelich Supercomputing
                        Centre, Federal Republic of Germany
Copyright (c) 2005-2008 ZIH, TU Dresden, Federal Republic of Germany
Copyright (c) 2007      Evergrid, Inc. All rights reserved.
Copyright (c) 2008      Chelsio, Inc.  All rights reserved.
Copyright (c) 2008-2009 Institut National de Recherche en
                        Informatique.  All rights reserved.
Copyright (c) 2007      Lawrence Livermore National Security, LLC.
                        All rights reserved.
Copyright (c) 2007-2017 Mellanox Technologies.  All rights reserved.
Copyright (c) 2006-2010 QLogic Corporation.  All rights reserved.
Copyright (c) 2008-2017 Oak Ridge National Labs.  All rights reserved.
Copyright (c) 2006-2012 Oracle and/or its affiliates.  All rights reserved.
Copyright (c) 2009-2015 Bull SAS.  All rights reserved.
Copyright (c) 2010      ARM ltd.  All rights reserved.
Copyright (c) 2016      ARM, Inc.  All rights reserved.
Copyright (c) 2010-2011 Alex Brick .  All rights reserved.
Copyright (c) 2012      The University of Wisconsin-La Crosse. All rights
                        reserved.
Copyright (c) 2013-2016 Intel, Inc. All rights reserved.
Copyright (c) 2011-2017 NVIDIA Corporation.  All rights reserved.
Copyright (c) 2016      Broadcom Limited.  All rights reserved.
Copyright (c) 2011-2017 Fujitsu Limited.  All rights reserved.
Copyright (c) 2014-2015 Hewlett-Packard Development Company, LP.  All
                        rights reserved.
Copyright (c) 2013-2017 Research Organization for Information Science (RIST).
                        All rights reserved.
Copyright (c) 2017-2018 Amazon.com, Inc. or its affiliates.  All Rights
                        reserved.
Copyright (c) 2018      DataDirect Networks. All rights reserved.
Copyright (c) 2018-2019 Triad National Security, LLC. All rights reserved.

$COPYRIGHT$

Additional copyrights may follow

$HEADER$

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

- Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

- Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer listed
  in this license in the documentation and/or other materials
  provided with the distribution.

- Neither the name of the copyright holders nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

The copyright holders provide no reassurances that the source code
provided does not infringe any patent, copyright, or any other
intellectual property rights of third parties.  The copyright holders
disclaim any liability to any recipient for claims brought against
recipient by any third party for infringement of that parties
intellectual property rights.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

_____

The Android Open Source Project

Copyright (C) 2017 The Android Open Source Project
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

------

libprotobuf-mutator

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   -----

   openucx/ucx
   https://github.com/openucx/ucx

   Copyright (c) 2014-2015      UT-Battelle, LLC. All rights reserved.
   Copyright (C) 2014-2020      Mellanox Technologies Ltd. All rights reserved.
   Copyright (C) 2014-2015      The University of Houston System. All rights reserved.
   Copyright (C) 2015           The University of Tennessee and The University
                              of Tennessee Research Foundation. All rights reserved.
   Copyright (C) 2016-2020      ARM Ltd. All rights reserved.
   Copyright (c) 2016           Los Alamos National Security, LLC. All rights reserved.
   Copyright (C) 2016-2020      Advanced Micro Devices, Inc.  All rights reserved.
   Copyright (C) 2019           UChicago Argonne, LLC.  All rights reserved.
   Copyright (c) 2018-2020      NVIDIA CORPORATION. All rights reserved.
   Copyright (C) 2020           Huawei Technologies Co., Ltd. All rights reserved.
   Copyright (C) 2016-2020      Stony Brook University. All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
   3. Neither the name of the copyright holder nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
   HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

   -----

   From PyTorch:

   Copyright (c) 2016-     Facebook, Inc            (Adam Paszke)
   Copyright (c) 2014-     Facebook, Inc            (Soumith Chintala)
   Copyright (c) 2011-2014 Idiap Research Institute (Ronan Collobert)
   Copyright (c) 2012-2014 Deepmind Technologies    (Koray Kavukcuoglu)
   Copyright (c) 2011-2012 NEC Laboratories America (Koray Kavukcuoglu)
   Copyright (c) 2011-2013 NYU                      (Clement Farabet)
   Copyright (c) 2006-2010 NEC Laboratories America (Ronan Collobert, Leon Bottou, Iain Melvin, Jason Weston)
   Copyright (c) 2006      Idiap Research Institute (Samy Bengio)
   Copyright (c) 2001-2004 Idiap Research Institute (Ronan Collobert, Samy Bengio, Johnny Mariethoz)

   From Caffe2:

   Copyright (c) 2016-present, Facebook Inc. All rights reserved.

   All contributions by Facebook:
   Copyright (c) 2016 Facebook Inc.

   All contributions by Google:
   Copyright (c) 2015 Google Inc.
   All rights reserved.

   All contributions by Yangqing Jia:
   Copyright (c) 2015 Yangqing Jia
   All rights reserved.

   All contributions from Caffe:
   Copyright(c) 2013, 2014, 2015, the respective contributors
   All rights reserved.

   All other contributions:
   Copyright(c) 2015, 2016 the respective contributors
   All rights reserved.

   Caffe2 uses a copyright model similar to Caffe: each contributor holds
   copyright over their contributions to Caffe2. The project versioning records
   all such contribution and copyright details. If a contributor wants to further
   mark their specific copyright on a particular contribution, they should
   indicate their copyright solely in the commit message of the change when it is
   committed.

   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.

   3. Neither the names of Facebook, Deepmind Technologies, NYU, NEC Laboratories America
      and IDIAP Research Institute nor the names of its contributors may be
      used to endorse or promote products derived from this software without
      specific prior written permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
   AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
   IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
   ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
   LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
   CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
   SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
   INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
   CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
   ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
   POSSIBILITY OF SUCH DAMAGE.

_____

   mpi4py
   https://github.com/mpi4py/mpi4py/

   =======================
   LICENSE: MPI for Python
   =======================

   :Author:  Lisandro Dalcin
   :Contact: dalcinl@gmail.com


   Copyright (c) 2019, Lisandro Dalcin.
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

   * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
   HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
_____
huggingface/transformers

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
_____
msgpack/msgpack-python

Copyright (C) 2008-2011 INADA Naoki <songofacandy@gmail.com>

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
_____
lanpa/tensorboardX

MIT License

Copyright (c) 2017 Tzu-Wei Huang

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
_____
tensorflow/tensorboard

Copyright 2017 The TensorFlow Authors.  All rights reserved.

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright 2017, The TensorFlow Authors.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.


_____

cerberus

Cerberus is a lightweight and extensible data validation library for Python.

ISC License

Copyright (c) 2012-2016 Nicola Iarocci.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.

_____

MurmurHash3

MIT license

https://github.com/aappleby/smhasher

SMHasher is a test suite designed to test the distribution, collision, and
performance properties of non-cryptographic hash functions.
This is the home for the MurmurHash family of hash functions along with the
SMHasher test suite used to verify them.
SMHasher is released under the MIT license.
All MurmurHash versions are public domain software, and the author disclaims all copyright to their code.

_____

gtest-ios-framework

https://github.com/mestevens/gtest-ios-framework

Copyright (c) 2013 Matthew Stevens

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

_____

DLPack

https://github.com/dmlc/dlpack

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "{}"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright 2017 by Contributors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

_____

emsdk

MIT/Expat license

https://github.com/emscripten-core/emsdk

Copyright (c) 2018 Emscripten authors (see AUTHORS in Emscripten)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

----------------------------------------------------------------------------

This is the MIT/Expat License. For more information see:

1. http://www.opensource.org/licenses/mit-license.php

2. http://en.wikipedia.org/wiki/MIT_License

_____

coremltools

BSD-3-Clause License

https://github.com/apple/coremltools

Copyright (c) 2020, Apple Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1.  Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2.  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3.  Neither the name of the copyright holder(s) nor the names of any contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
© 2021 GitHub, Inc.

_____

react-native

MIT License

https://github.com/facebook/react-native

Copyright (c) Facebook, Inc. and its affiliates.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

_____

pytorch/cpuinfo

BSD 2-Clause "Simplified" License

https://github.com/pytorch/cpuinfo

Copyright (c) 2019 Google LLC
Copyright (c) 2017-2018 Facebook Inc.
Copyright (C) 2012-2017 Georgia Institute of Technology
Copyright (C) 2010-2012 Marat Dukhan

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

_____

SQLite Is Public Domain

All of the code and documentation in SQLite has been dedicated to the public
domain by the authors. All code authors, and representatives of the companies
they work for, have signed affidavits dedicating their contributions to the
public domain and originals of those signed affidavits are stored in a firesafe
at the main offices of Hwaci. Anyone is free to copy, modify, publish, use,
compile, sell, or distribute the original SQLite code, either in source code
form or as a compiled binary, for any purpose, commercial or non-commercial,
and by any means.

The previous paragraph applies to the deliverable code and documentation in
SQLite - those parts of the SQLite library that you actually bundle and ship
with a larger application. Some scripts used as part of the build process (for
example the "configure" scripts generated by autoconf) might fall under other
open-source licenses. Nothing from these build scripts ever reaches the final
deliverable SQLite library, however, and so the licenses associated with those
scripts should not be a factor in assessing your rights to copy and use the
SQLite library.

All of the deliverable code in SQLite has been written from scratch. No code
has been taken from other projects or from the open internet. Every line of
code can be traced back to its original author, and all of those authors have
public domain dedications on file. So the SQLite code base is clean and is
uncontaminated with licensed code from other projects.

_____

google/XNNPACK

BSD License

For XNNPACK software

Copyright (c) Facebook, Inc. and its affiliates. All rights reserved.
Copyright 2019 Google LLC

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

 * Neither the name Facebook nor the names of its contributors may be used to
   endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

_____

google/sentencepiece, https://github.com/google/sentencepiece
(included when statically linked with onnxruntime-extensions)

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

_____

dlfcn-win32/dlfcn-win32 is licensed under the MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

_____

The Python Imaging Library (PIL) is

    Copyright © 1997-2011 by Secret Labs AB
    Copyright © 1995-2011 by Fredrik Lundh

Pillow is the friendly PIL fork. It is

    Copyright © 2010-2023 by Alex Clark and contributors

Like PIL, Pillow is licensed under the open source HPND License:

By obtaining, using, and/or copying this software and/or its associated
documentation, you agree that you have read, understood, and will comply
with the following terms and conditions:

Permission to use, copy, modify, and distribute this software and its
associated documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appears in all copies, and that
both that copyright notice and this permission notice appear in supporting
documentation, and that the name of Secret Labs AB or the author not be
used in advertising or publicity pertaining to distribution of the software
without specific, written prior permission.

SECRET LABS AB AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS.
IN NO EVENT SHALL SECRET LABS AB OR THE AUTHOR BE LIABLE FOR ANY SPECIAL,
INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.

_____

openssl/openssl, https://github.com/openssl/openssl

                                 Apache License
                           Version 2.0, January 2004
                        https://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

_____

Tencent/rapidjson, https://github.com/Tencent/rapidjson

Tencent is pleased to support the open source community by making RapidJSON available.

Copyright (C) 2015 THL A29 Limited, a Tencent company, and Milo Yip.  All rights reserved.

If you have downloaded a copy of the RapidJSON binary from Tencent, please note that the RapidJSON binary is licensed under the MIT License.
If you have downloaded a copy of the RapidJSON source code from Tencent, please note that RapidJSON source code is licensed under the MIT License, except for the third-party components listed below which are subject to different license terms.  Your integration of RapidJSON into your own projects may require compliance with the MIT License, as well as the other licenses applicable to the third-party components included within RapidJSON. To avoid the problematic JSON license in your own projects, it's sufficient to exclude the bin/jsonchecker/ directory, as it's the only code under the JSON license.
A copy of the MIT License is included in this file.

Other dependencies and licenses:

Open Source Software Licensed Under the BSD License:
--------------------------------------------------------------------

The msinttypes r29
Copyright (c) 2006-2013 Alexander Chemeris
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
* Neither the name of  copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Open Source Software Licensed Under the JSON License:
--------------------------------------------------------------------

json.org
Copyright (c) 2002 JSON.org
All Rights Reserved.

JSON_checker
Copyright (c) 2002 JSON.org
All Rights Reserved.


Terms of the JSON License:
---------------------------------------------------

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

The Software shall be used for Good, not Evil.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


Terms of the MIT License:
--------------------------------------------------------------------

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

_____

boostorg/boost, https://github.com/boostorg/boost

Boost Software License - Version 1.0 - August 17th, 2003

Permission is hereby granted, free of charge, to any person or organization
obtaining a copy of the software and accompanying documentation covered by
this license (the "Software") to use, reproduce, display, distribute,
execute, and transmit the Software, and to prepare derivative works of the
Software, and to permit third-parties to whom the Software is furnished to
do so, all subject to the following:

The copyright notices in the Software and this entire statement, including
the above license grant, this restriction and the following disclaimer,
must be included in all copies of the Software, in whole or in part, and
all derivative works of the Software, unless such copies or derivative
works are solely in the form of machine-executable object code generated by
a source language processor.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT
SHALL THE COPYRIGHT HOLDERS OR ANYONE DISTRIBUTING THE SOFTWARE BE LIABLE
FOR ANY DAMAGES OR OTHER LIABILITY, WHETHER IN CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.

_____

libb64/libb64, https://github.com/libb64/libb64

Copyright-Only Dedication (based on United States law) or Public Domain Certification

The person or persons who have associated work with this document (the "Dedicator" or "Certifier") hereby either (a) certifies that, to the best of his knowledge, the work of authorship identified is in the public domain of the country from which the work is published, or (b) hereby dedicates whatever copyright the dedicators holds in the work of authorship identified below (the "Work") to the public domain. A certifier, moreover, dedicates any copyright interest he may have in the associated work, and for these purposes, is described as a "dedicator" below.

A certifier has taken reasonable steps to verify the copyright status of this work. Certifier recognizes that his good faith efforts may not shield him from liability if in fact the work certified is not in the public domain.

Dedicator makes this dedication for the benefit of the public at large and to the detriment of the Dedicator's heirs and successors. Dedicator intends this dedication to be an overt act of relinquishment in perpetuity of all present and future rights under copyright law, whether vested or contingent, in the Work. Dedicator understands that such relinquishment of all rights includes the relinquishment of all rights to enforce (by lawsuit or otherwise) those copyrights in the Work.

Dedicator recognizes that, once placed in the public domain, the Work may be freely reproduced, distributed, transmitted, used, modified, built upon, or otherwise exploited by anyone for any purpose, commercial or non-commercial, and in any way, including by methods that have not yet been invented or conceived.

_____

posix pthread library, https://sourceforge.net/projects/pthreads4w


                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

_____

Triton Inference Server & Client, https://github.com/triton-inference-server

Copyright (c) 2022, NVIDIA CORPORATION. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of NVIDIA CORPORATION nor the names of its
   contributors may be used to endorse or promote products derived
   from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

_____

microsoft/mimalloc, https://github.com/microsoft/mimalloc

MIT License

Copyright (c) 2018-2021 Microsoft Corporation, Daan Leijen

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

_____

TensorFlow.js

https://github.com/tensorflow/tfjs


                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

——

curl/curl

https://github.com/curl

COPYRIGHT AND PERMISSION NOTICE

Copyright (C) Daniel Stenberg, <daniel@haxx.se>, and many
contributors, see the THANKS file.

All rights reserved.

Permission to use, copy, modify, and distribute this software for any purpose
with or without fee is hereby granted, provided that the above copyright
notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the name of a copyright holder shall not
be used in advertising or otherwise to promote the sale, use or other dealings
in this Software without prior written authorization of the copyright holder.

_____

Intel neural-compressor

https://github.com/intel/neural-compressor

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   ============================================================================

   Copyright 2016-2019 Intel Corporation
   Copyright 2018 YANDEX LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   This distribution includes third party software ("third party programs").
   This third party software, even if included with the distribution of
   the Intel software, may be governed by separate license terms, including
   without limitation, third party license terms, other Intel software license
   terms, and open source software license terms. These separate license terms
   govern your use of the third party programs as set forth in the
   "THIRD-PARTY-PROGRAMS" file.

_____

FlashAttention, https://github.com/Dao-AILab/flash-attention

BSD 3-Clause License

Copyright (c) 2022, the respective contributors, as shown by the AUTHORS file.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

* Neither the name of the copyright holder nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

_____

neural-speed

https://github.com/intel/neural-speed

                                 Apache License
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   ============================================================================

   Copyright 2016-2019 Intel Corporation
   Copyright 2018 YANDEX LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   This distribution includes third party software ("third party programs").
   This third party software, even if included with the distribution of
   the Intel software, may be governed by separate license terms, including
   without limitation, third party license terms, other Intel software license
   terms, and open source software license terms. These separate license terms
   govern your use of the third party programs as set forth in the
   "THIRD-PARTY-PROGRAMS" file.

_____

dawn

https://dawn.googlesource.com/dawn

   BSD 3-Clause License

   Copyright 2017-2023 The Dawn & Tint Authors

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this
      list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

   3. Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived from
      this software without specific prior written permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
   AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
   IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
   FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
   DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
   SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
   CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

_____

KleidiAI

https://gitlab.arm.com/kleidi/kleidiai

Apache License
Version 2.0, January 2004
http://www.apache.org/licenses/

TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

1. Definitions.

"License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.

"Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.

"Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.

"You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.

"Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.

"Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.

"Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).

"Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.

"Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."

"Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

     (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

     (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

     (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

     (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

     You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability.

END OF TERMS AND CONDITIONS

Copyright 2024-2025 Arm Limited and/or its affiliates <open-source-office@arm.com>

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
```

## JavaScript dependencies

## @ag-ui/client 1.0.3

- Licence: `MIT`
- Source: https://github.com/ag-ui-protocol/ag-ui#readme

## @ag-ui/core 1.0.3

- Licence: `MIT`
- Source: https://github.com/ag-ui-protocol/ag-ui#readme

## @ag-ui/encoder 1.0.3

- Licence: `MIT`
- Source: https://github.com/ag-ui-protocol/ag-ui#readme

## @ag-ui/proto 1.0.3

- Licence: `MIT`
- Source: https://github.com/ag-ui-protocol/ag-ui#readme

## @bufbuild/protobuf 2.14.1

- Licence: `(Apache-2.0 AND BSD-3-Clause)`
- Source: https://protobufes.com/

## @dnd-kit/accessibility 3.1.1

- Licence: `MIT`
- Source: https://github.com/clauderic/dnd-kit#readme

## @dnd-kit/core 6.3.1

- Licence: `MIT`
- Source: https://github.com/clauderic/dnd-kit#readme

## @dnd-kit/sortable 10.0.0

- Licence: `MIT`
- Source: https://github.com/clauderic/dnd-kit#readme

## @dnd-kit/utilities 3.2.2

- Licence: `MIT`
- Source: https://github.com/clauderic/dnd-kit#readme

## @floating-ui/core 1.8.0

- Licence: `MIT`
- Source: https://floating-ui.com

## @floating-ui/dom 1.8.0

- Licence: `MIT`
- Source: https://floating-ui.com

## @floating-ui/utils 0.2.12

- Licence: `MIT`
- Source: https://floating-ui.com

## @fontsource-variable/hanken-grotesk 5.3.0

- Licence: `OFL-1.1`
- Source: https://fontsource.org/fonts/hanken-grotesk

## @fontsource-variable/jetbrains-mono 5.3.0

- Licence: `OFL-1.1`
- Source: https://fontsource.org/fonts/jetbrains-mono

## @fontsource-variable/space-grotesk 5.3.0

- Licence: `OFL-1.1`
- Source: https://fontsource.org/fonts/space-grotesk

## @protobuf-ts/protoc 2.11.1

- Licence: `Apache-2.0`
- Source: https://github.com/timostamm/protobuf-ts

## @radix-ui/primitive 1.2.0

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-compose-refs 1.1.5

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-context 1.3.0

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-dialog 1.3.1

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-dismissable-layer 1.2.1

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-focus-guards 1.2.0

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-focus-scope 1.3.1

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-id 1.1.4

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-portal 1.2.0

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-presence 1.1.11

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-primitive 2.2.0

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-slot 1.5.0

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-use-callback-ref 1.1.5

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-use-controllable-state 1.3.0

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-use-effect-event 0.0.5

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-use-layout-effect 1.1.4

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @tauri-apps/api 2.12.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri#readme

## @tauri-apps/plugin-dialog 2.8.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/tauri-apps/plugins-workspace#readme

## @tauri-apps/plugin-process 2.4.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/tauri-apps/plugins-workspace#readme

## @tauri-apps/plugin-updater 2.13.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/tauri-apps/plugins-workspace#readme

## @tiptap/core 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-blockquote 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-bold 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-bubble-menu 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-bullet-list 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-character-count 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-code 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-code-block 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-collaboration 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-document 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-dropcursor 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-floating-menu 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-gapcursor 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-hard-break 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-heading 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-horizontal-rule 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-italic 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-link 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-list 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-list-item 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-list-keymap 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-ordered-list 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-paragraph 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-placeholder 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-strike 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-text 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-text-align 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-underline 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extensions 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/pm 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/react 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/starter-kit 3.32.0

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/y-tiptap 3.0.7

- Licence: `MIT`
- Source: https://github.com/ueberdosis/y-tiptap#readme

## @types/debug 4.1.13

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/debug

## @types/estree 1.0.9

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/estree

## @types/estree-jsx 1.0.5

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/estree-jsx

## @types/hast 3.0.5

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hast

## @types/mdast 4.0.4

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mdast

## @types/ms 2.1.0

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/ms

## @types/react 19.3.0

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react

## @types/react-dom 19.3.0

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-dom

## @types/unist 2.0.11

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/unist

## @types/unist 3.0.3

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/unist

## @types/use-sync-external-store 0.0.6

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/use-sync-external-store

## @types/uuid 10.0.0

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/uuid

## @ungap/structured-clone 1.3.2

- Licence: `ISC`
- Source: https://github.com/ungap/structured-clone#readme

## aria-hidden 1.2.6

- Licence: `MIT`
- Source: https://github.com/theKashey/aria-hidden#readme

## bail 2.0.2

- Licence: `MIT`
- Source: https://github.com/wooorm/bail#readme

## ccount 2.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/ccount#readme

## character-entities 2.0.2

- Licence: `MIT`
- Source: https://github.com/wooorm/character-entities#readme

## character-entities-html4 2.1.0

- Licence: `MIT`
- Source: https://github.com/wooorm/character-entities-html4#readme

## character-entities-legacy 3.0.0

- Licence: `MIT`
- Source: https://github.com/wooorm/character-entities-legacy#readme

## character-reference-invalid 2.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/character-reference-invalid#readme

## comma-separated-tokens 2.0.3

- Licence: `MIT`
- Source: https://github.com/wooorm/comma-separated-tokens#readme

## compare-versions 6.1.1

- Licence: `MIT`
- Source: https://github.com/omichelsen/compare-versions#readme

## csstype 3.2.3

- Licence: `MIT`
- Source: https://github.com/frenic/csstype#readme

## debug 4.4.3

- Licence: `MIT`
- Source: https://github.com/debug-js/debug#readme

## decode-named-character-reference 1.3.0

- Licence: `MIT`
- Source: https://github.com/wooorm/decode-named-character-reference#readme

## dequal 2.0.3

- Licence: `MIT`
- Source: https://github.com/lukeed/dequal#readme

## detect-node-es 1.1.0

- Licence: `MIT`
- Source: https://github.com/thekashey/detect-node

## devlop 1.1.0

- Licence: `MIT`
- Source: https://github.com/wooorm/devlop#readme

## escape-string-regexp 5.0.0

- Licence: `MIT`
- Source: https://github.com/sindresorhus/escape-string-regexp#readme

## estree-util-is-identifier-name 3.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/estree-util-is-identifier-name#readme

## extend 3.0.2

- Licence: `MIT`
- Source: https://github.com/justmoon/node-extend#readme

## fast-equals 5.4.2

- Licence: `MIT`
- Source: https://github.com/planttheidea/fast-equals#readme

## fast-json-patch 3.1.1

- Licence: `MIT`
- Source: https://github.com/Starcounter-Jack/JSON-Patch

## get-nonce 1.0.1

- Licence: `MIT`
- Source: https://github.com/theKashey/get-nonce

## hast-util-to-jsx-runtime 2.3.6

- Licence: `MIT`
- Source: https://github.com/syntax-tree/hast-util-to-jsx-runtime#readme

## hast-util-whitespace 3.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/hast-util-whitespace#readme

## html-url-attributes 3.0.1

- Licence: `MIT`
- Source: https://github.com/rehypejs/rehype-minify/tree/main#readme

## inline-style-parser 0.2.7

- Licence: `MIT`
- Source: https://github.com/remarkablemark/inline-style-parser#readme

## is-alphabetical 2.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/is-alphabetical#readme

## is-alphanumerical 2.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/is-alphanumerical#readme

## is-decimal 2.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/is-decimal#readme

## is-hexadecimal 2.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/is-hexadecimal#readme

## is-plain-obj 4.1.0

- Licence: `MIT`
- Source: https://github.com/sindresorhus/is-plain-obj#readme

## isomorphic.js 0.2.5

- Licence: `MIT`
- Source: https://github.com/dmonad/isomorphic.js#readme

## lib0 0.2.117

- Licence: `MIT`
- Source: https://github.com/dmonad/lib0#readme

## lib0 0.2.119

- Licence: `MIT`
- Source: https://github.com/dmonad/lib0#readme

## linkifyjs 4.3.3

- Licence: `MIT`
- Source: https://linkify.js.org

## longest-streak 3.1.0

- Licence: `MIT`
- Source: https://github.com/wooorm/longest-streak#readme

## markdown-table 3.0.4

- Licence: `MIT`
- Source: https://github.com/wooorm/markdown-table#readme

## mdast-util-find-and-replace 3.0.2

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-find-and-replace#readme

## mdast-util-from-markdown 2.0.3

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-from-markdown#readme

## mdast-util-gfm 3.1.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-gfm#readme

## mdast-util-gfm-autolink-literal 2.0.1

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-gfm-autolink-literal#readme

## mdast-util-gfm-footnote 2.1.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-gfm-footnote#readme

## mdast-util-gfm-strikethrough 2.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-gfm-strikethrough#readme

## mdast-util-gfm-table 2.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-gfm-table#readme

## mdast-util-gfm-task-list-item 2.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-gfm-task-list-item#readme

## mdast-util-mdx-expression 2.0.1

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-mdx-expression#readme

## mdast-util-mdx-jsx 3.2.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-mdx-jsx#readme

## mdast-util-mdxjs-esm 2.0.1

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-mdxjs-esm#readme

## mdast-util-phrasing 4.1.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-phrasing#readme

## mdast-util-to-hast 13.2.1

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-to-hast#readme

## mdast-util-to-markdown 2.1.2

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-to-markdown#readme

## mdast-util-to-string 4.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-to-string#readme

## micromark 4.0.2

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-core-commonmark 2.0.3

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-extension-gfm 3.0.0

- Licence: `MIT`
- Source: https://github.com/micromark/micromark-extension-gfm#readme

## micromark-extension-gfm-autolink-literal 2.1.0

- Licence: `MIT`
- Source: https://github.com/micromark/micromark-extension-gfm-autolink-literal#readme

## micromark-extension-gfm-footnote 2.1.0

- Licence: `MIT`
- Source: https://github.com/micromark/micromark-extension-gfm-footnote#readme

## micromark-extension-gfm-strikethrough 2.1.0

- Licence: `MIT`
- Source: https://github.com/micromark/micromark-extension-gfm-strikethrough#readme

## micromark-extension-gfm-table 2.1.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark-extension-gfm-table#readme

## micromark-extension-gfm-tagfilter 2.0.0

- Licence: `MIT`
- Source: https://github.com/micromark/micromark-extension-gfm-tagfilter#readme

## micromark-extension-gfm-task-list-item 2.1.0

- Licence: `MIT`
- Source: https://github.com/micromark/micromark-extension-gfm-task-list-item#readme

## micromark-factory-destination 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-factory-label 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-factory-space 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-factory-title 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-factory-whitespace 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-character 2.1.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-chunked 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-classify-character 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-combine-extensions 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-decode-numeric-character-reference 2.0.2

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-decode-string 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-encode 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-html-tag-name 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-normalize-identifier 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-resolve-all 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-sanitize-uri 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-subtokenize 2.1.0

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-symbol 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-types 2.0.2

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## ms 2.1.3

- Licence: `MIT`
- Source: https://github.com/vercel/ms#readme

## orderedmap 2.1.1

- Licence: `MIT`
- Source: https://github.com/marijnh/orderedmap#readme

## parse-entities 4.0.2

- Licence: `MIT`
- Source: https://github.com/wooorm/parse-entities#readme

## property-information 7.2.0

- Licence: `MIT`
- Source: https://github.com/wooorm/property-information#readme

## prosemirror-changeset 2.4.4

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-changeset/v/2.4.4

## prosemirror-commands 1.7.2

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-commands/v/1.7.2

## prosemirror-dropcursor 1.8.4

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-dropcursor/v/1.8.4

## prosemirror-gapcursor 1.4.1

- Licence: `MIT`
- Source: https://github.com/prosemirror/prosemirror-gapcursor#readme

## prosemirror-history 1.5.1

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-history/v/1.5.1

## prosemirror-inputrules 1.5.1

- Licence: `MIT`
- Source: https://github.com/prosemirror/prosemirror-inputrules#readme

## prosemirror-keymap 1.2.3

- Licence: `MIT`
- Source: https://github.com/prosemirror/prosemirror-keymap#readme

## prosemirror-model 1.25.11

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-model/v/1.25.11

## prosemirror-model 1.25.12

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-model/v/1.25.12

## prosemirror-schema-list 1.5.1

- Licence: `MIT`
- Source: https://github.com/prosemirror/prosemirror-schema-list#readme

## prosemirror-state 1.4.4

- Licence: `MIT`
- Source: https://github.com/prosemirror/prosemirror-state#readme

## prosemirror-tables 1.8.5

- Licence: `MIT`
- Source: https://github.com/ProseMirror/prosemirror-tables#readme

## prosemirror-transform 1.12.1

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-transform/v/1.12.1

## prosemirror-transform 1.12.4

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-transform/v/1.12.4

## prosemirror-view 1.42.3

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-view/v/1.42.3

## prosemirror-view 1.42.7

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-view/v/1.42.7

## qrcode.react 4.2.0

- Licence: `ISC`
- Source: http://zpao.github.io/qrcode.react

## react 19.3.1

- Licence: `MIT`
- Source: https://react.dev/

## react-dom 19.3.1

- Licence: `MIT`
- Source: https://react.dev/

## react-markdown 10.1.0

- Licence: `MIT`
- Source: https://github.com/remarkjs/react-markdown#readme

## react-remove-scroll 2.7.2

- Licence: `MIT`
- Source: https://github.com/theKashey/react-remove-scroll#readme

## react-remove-scroll-bar 2.3.8

- Licence: `MIT`
- Source: https://github.com/theKashey/react-remove-scroll-bar#readme

## react-style-singleton 2.2.3

- Licence: `MIT`
- Source: https://github.com/theKashey/react-style-singleton#readme

## remark-parse 11.0.0

- Licence: `MIT`
- Source: https://remark.js.org

## remark-rehype 11.1.2

- Licence: `MIT`
- Source: https://github.com/remarkjs/remark-rehype#readme

## rope-sequence 1.3.4

- Licence: `MIT`
- Source: https://github.com/marijnh/rope-sequence#readme

## rxjs 7.8.2

- Licence: `Apache-2.0`
- Source: https://rxjs.dev

## scheduler 0.28.0

- Licence: `MIT`
- Source: https://react.dev/

## space-separated-tokens 2.0.2

- Licence: `MIT`
- Source: https://github.com/wooorm/space-separated-tokens#readme

## stringify-entities 4.0.4

- Licence: `MIT`
- Source: https://github.com/wooorm/stringify-entities#readme

## style-to-js 1.1.21

- Licence: `MIT`
- Source: https://github.com/remarkablemark/style-to-js#readme

## style-to-object 1.0.14

- Licence: `MIT`
- Source: https://github.com/remarkablemark/style-to-object#readme

## supports-color 10.2.2

- Licence: `MIT`
- Source: https://github.com/chalk/supports-color#readme

## trim-lines 3.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/trim-lines#readme

## trough 2.2.0

- Licence: `MIT`
- Source: https://github.com/wooorm/trough#readme

## tslib 2.8.1

- Licence: `0BSD`
- Source: https://www.typescriptlang.org/

## unified 11.0.5

- Licence: `MIT`
- Source: https://unifiedjs.com

## unist-util-is 6.0.1

- Licence: `MIT`
- Source: https://github.com/syntax-tree/unist-util-is#readme

## unist-util-position 5.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/unist-util-position#readme

## unist-util-stringify-position 4.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/unist-util-stringify-position#readme

## unist-util-visit 5.1.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/unist-util-visit#readme

## unist-util-visit-parents 6.0.2

- Licence: `MIT`
- Source: https://github.com/syntax-tree/unist-util-visit-parents#readme

## untruncate-json 0.0.1

- Licence: `MIT`
- Source: https://github.com/dphilipson/untruncate-json

## use-callback-ref 1.3.3

- Licence: `MIT`
- Source: https://github.com/theKashey/use-callback-ref#readme

## use-sidecar 1.1.3

- Licence: `MIT`
- Source: https://github.com/theKashey/use-sidecar

## use-sync-external-store 1.7.0

- Licence: `MIT`
- Source: https://github.com/react/react#readme

## uuid 11.1.1

- Licence: `MIT`
- Source: https://github.com/uuidjs/uuid#readme

## vfile 6.0.3

- Licence: `MIT`
- Source: https://github.com/vfile/vfile#readme

## vfile-message 4.0.3

- Licence: `MIT`
- Source: https://github.com/vfile/vfile-message#readme

## w3c-keyname 2.2.8

- Licence: `MIT`
- Source: https://github.com/marijnh/w3c-keyname#readme

## y-prosemirror 1.3.7

- Licence: `MIT`
- Source: https://github.com/yjs/y-prosemirror#readme

## y-protocols 1.0.7

- Licence: `MIT`
- Source: https://github.com/yjs/y-protocols#readme

## yjs 13.6.33

- Licence: `MIT`
- Source: https://docs.yjs.dev

## zod 4.6.7

- Licence: `MIT`
- Source: https://zod.dev

## zustand 5.0.16

- Licence: `MIT`
- Source: https://github.com/pmndrs/zustand

## zwitch 2.0.4

- Licence: `MIT`
- Source: https://github.com/wooorm/zwitch#readme

## Embedded assets

## Hanken Grotesk (Regular, Italic, Bold, Bold Italic) 3.014

- Licence: `OFL-1.1`
- Source: https://github.com/marcologous/hanken-grotesk/tree/eff37d18946b018ad239cf5fd3992db5d19b82a0

## Space Grotesk (Medium, Bold) 2.000

- Licence: `OFL-1.1`
- Source: https://github.com/floriankarsten/space-grotesk/tree/03507d024a01282884232081fc6011c09ff4e849
