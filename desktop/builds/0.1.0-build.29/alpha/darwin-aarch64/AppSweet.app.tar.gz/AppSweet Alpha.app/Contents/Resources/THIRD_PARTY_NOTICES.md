# AppSweet desktop third-party notices

Generated deterministically from the resolved Rust and JavaScript dependency graphs of the
Apple Silicon desktop bundle.

## Rust dependencies

## adler2 2.0.1

- Licence: `0BSD OR MIT OR Apache-2.0`
- Source: https://github.com/oyvindln/adler2

## aead 0.5.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## aegis 0.9.12

- Licence: `MIT`
- Source: https://github.com/jedisct1/rust-aegis

## aes 0.8.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/block-ciphers

## aes-gcm 0.10.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/AEADs

## aho-corasick 1.1.4

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/aho-corasick

## alloc-no-stdlib 2.0.4

- Licence: `BSD-3-Clause`
- Source: https://github.com/dropbox/rust-alloc-no-stdlib

## alloc-stdlib 0.2.4

- Licence: `BSD-3-Clause`
- Source: https://github.com/dropbox/rust-alloc-no-stdlib

## allocator-api2 0.2.21

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/zakarumych/allocator-api2

## allocator-api2 0.4.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/zakarumych/allocator-api2

## anyhow 1.0.103

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/anyhow

## apple-native-keyring-store 1.0.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/open-source-cooperative/apple-native-keyring-store.git

## arc-swap 1.9.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/vorner/arc-swap

## aristo 0.4.1

- Licence: `MIT`
- Source: https://github.com/aretta-ai/aristo

## aristo-macros 0.4.1

- Licence: `MIT`
- Source: https://github.com/aretta-ai/aristo

## arrayvec 0.7.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/bluss/arrayvec

## as-any 0.3.2

- Licence: `MIT OR Apache-2.0`
- Source: https://codeberg.org/fogti/as-any

## async-lock 3.4.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/async-lock

## async-stream 0.3.6

- Licence: `MIT`
- Source: https://github.com/tokio-rs/async-stream

## async-stream-impl 0.3.6

- Licence: `MIT`
- Source: https://github.com/tokio-rs/async-stream

## async-trait 0.1.92

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/async-trait

## atomic-waker 1.1.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/atomic-waker

## aws-lc-rs 1.18.1

- Licence: `ISC AND (Apache-2.0 OR ISC)`
- Source: https://github.com/aws/aws-lc-rs

## aws-lc-sys 0.45.0

- Licence: `ISC AND (Apache-2.0 OR ISC) AND Apache-2.0 AND MIT AND BSD-3-Clause AND (Apache-2.0 OR ISC OR MIT) AND (Apache-2.0 OR ISC OR MIT-0)`
- Source: https://github.com/aws/aws-lc-rs

## base16ct 0.2.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/base16ct

## base64 0.13.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/marshallpierce/rust-base64

## base64 0.21.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/marshallpierce/rust-base64

## base64 0.22.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/marshallpierce/rust-base64

## base64 0.23.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/marshallpierce/rust-base64

## base64ct 1.8.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats

## bigdecimal 0.4.10

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/akubera/bigdecimal-rs

## bincode 1.3.3

- Licence: `MIT`
- Source: https://github.com/servo/bincode

## bit-set 0.8.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/contain-rs/bit-set

## bit-vec 0.8.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/contain-rs/bit-vec

## bitflags 1.3.2

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/bitflags/bitflags

## bitflags 2.13.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/bitflags/bitflags

## bitpacking 0.9.3

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/bitpacking

## blake2 0.10.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/hashes

## blake2b_simd 1.0.5

- Licence: `MIT`
- Source: https://github.com/oconnor663/blake2_simd

## block-buffer 0.10.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## block-buffer 0.12.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## block-padding 0.3.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## block2 0.6.2

- Licence: `MIT`
- Source: https://github.com/madsmtm/objc2

## bon 3.9.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/elastio/bon

## bon-macros 3.9.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/elastio/bon

## branches 0.4.4

- Licence: `MIT`
- Source: https://github.com/fereidani/branches

## brotli 8.0.4

- Licence: `BSD-3-Clause AND MIT`
- Source: https://github.com/dropbox/rust-brotli

## brotli-decompressor 5.0.3

- Licence: `BSD-3-Clause/MIT`
- Source: https://github.com/dropbox/rust-brotli-decompressor

## bs58 0.5.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/Nullus157/bs58-rs

## bumpalo 3.20.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/fitzgen/bumpalo

## bytemuck 1.25.0

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/bytemuck

## bytemuck_derive 1.10.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/bytemuck

## byteorder 1.5.0

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/byteorder

## bytes 1.12.1

- Licence: `MIT`
- Source: https://github.com/tokio-rs/bytes

## camino 1.2.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/camino-rs/camino

## cargo_metadata 0.19.2

- Licence: `MIT`
- Source: https://github.com/oli-obk/cargo_metadata

## cargo-platform 0.1.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/cargo

## census 0.4.2

- Licence: `MIT`
- Source: https://github.com/quickwit-inc/census

## cfb 0.7.3

- Licence: `MIT`
- Source: https://github.com/mdsteele/rust-cfb

## cfg_block 0.1.1

- Licence: `Apache-2.0`
- Source: https://github.com/pluots/cfg_block
- Override evidence: crate LICENSE file in Cargo.lock checksum-pinned cfg_block 0.1.1

## cfg-if 1.0.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/cfg-if

## chacha20 0.10.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/stream-ciphers

## chacha20 0.9.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/stream-ciphers

## chacha20poly1305 0.10.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/AEADs/tree/master/chacha20poly1305

## chrono 0.4.45

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/chronotope/chrono

## cipher 0.4.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## cipher 0.5.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## cmov 0.5.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/utils

## concurrent-queue 2.5.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/concurrent-queue

## const-oid 0.10.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats

## const-oid 0.9.6

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/const-oid

## constant_time_eq 0.1.5

- Licence: `CC0-1.0`
- Source: https://github.com/cesarb/constant_time_eq

## constant_time_eq 0.3.1

- Licence: `CC0-1.0 OR MIT-0 OR Apache-2.0`
- Source: https://github.com/cesarb/constant_time_eq

## constant_time_eq 0.4.2

- Licence: `CC0-1.0 OR MIT-0 OR Apache-2.0`
- Source: https://github.com/cesarb/constant_time_eq

## cookie 0.18.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/SergioBenitez/cookie-rs

## core-foundation 0.10.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/core-foundation-rs

## core-foundation 0.9.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/core-foundation-rs

## core-foundation-sys 0.8.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/core-foundation-rs

## core-graphics 0.25.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/core-foundation-rs

## core-graphics-types 0.2.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/core-foundation-rs

## cpufeatures 0.2.17

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## cpufeatures 0.3.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## crc32c 0.6.8

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/zowens/crc32c

## crc32fast 1.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/srijs/rust-crc32fast

## crossbeam-channel 0.5.15

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/crossbeam-rs/crossbeam

## crossbeam-deque 0.8.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/crossbeam-rs/crossbeam

## crossbeam-epoch 0.9.20

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/crossbeam-rs/crossbeam

## crossbeam-utils 0.8.21

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/crossbeam-rs/crossbeam

## crunchy 0.2.4

- Licence: `MIT`
- Source: https://github.com/eira-fransham/crunchy

## crypto-bigint 0.5.5

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/crypto-bigint

## crypto-common 0.1.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## crypto-common 0.2.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## cssparser 0.36.0

- Licence: `MPL-2.0`
- Source: https://github.com/servo/rust-cssparser

## cssparser-macros 0.6.1

- Licence: `MPL-2.0`
- Source: https://github.com/servo/rust-cssparser

## ctor 0.8.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/mmastrac/rust-ctor

## ctor-proc-macro 0.0.7

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/mmastrac/rust-ctor

## ctr 0.9.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/block-modes

## ctutils 0.4.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/utils

## curve25519-dalek 4.1.3

- Licence: `BSD-3-Clause`
- Source: https://github.com/dalek-cryptography/curve25519-dalek/tree/main/curve25519-dalek

## darling 0.23.0

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling_core 0.23.0

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## darling_macro 0.23.0

- Licence: `MIT`
- Source: https://github.com/TedDriggs/darling

## dashmap 6.2.1

- Licence: `MIT`
- Source: https://github.com/xacrimon/dashmap

## data-encoding 2.11.0

- Licence: `MIT`
- Source: https://github.com/ia0/data-encoding

## datasketches 0.2.0

- Licence: `Apache-2.0`
- Source: https://github.com/apache/datasketches-rust

## defmt 1.1.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/knurling-rs/defmt

## defmt-macros 1.1.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/knurling-rs/defmt

## defmt-parser 1.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/knurling-rs/defmt

## der 0.7.10

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/der

## deranged 0.5.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jhpratt/deranged

## derive_more 2.1.1

- Licence: `MIT`
- Source: https://github.com/JelteF/derive_more

## derive_more-impl 2.1.1

- Licence: `MIT`
- Source: https://github.com/JelteF/derive_more

## digest 0.10.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## digest 0.11.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## dirs 4.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/soc/dirs-rs

## dirs 6.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/soc/dirs-rs

## dirs-next 2.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/xdg-rs/dirs

## dirs-sys 0.3.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dirs-dev/dirs-sys-rs

## dirs-sys 0.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dirs-dev/dirs-sys-rs

## dirs-sys-next 0.1.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/xdg-rs/dirs/tree/master/dirs-sys

## dispatch2 0.3.1

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## displaydoc 0.2.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/yaahc/displaydoc

## dom_query 0.27.0

- Licence: `MIT`
- Source: https://github.com/niklak/dom_query

## downcast-rs 2.0.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/marcianx/downcast-rs

## dpi 0.1.2

- Licence: `Apache-2.0 AND MIT`
- Source: https://github.com/rust-windowing/winit

## dtoa 1.0.11

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/dtoa

## dtoa-short 0.3.5

- Licence: `MPL-2.0`
- Source: https://github.com/upsuper/dtoa-short

## dtor 0.3.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/mmastrac/rust-ctor

## dtor-proc-macro 0.0.6

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/mmastrac/rust-ctor

## dunce 1.0.5

- Licence: `CC0-1.0 OR MIT-0 OR Apache-2.0`
- Source: https://gitlab.com/kornelski/dunce

## dyn-clone 1.0.20

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/dyn-clone

## ecdsa 0.16.9

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/signatures/tree/master/ecdsa

## ed25519 2.2.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/signatures/tree/master/ed25519

## ed25519-dalek 2.2.0

- Licence: `BSD-3-Clause`
- Source: https://github.com/dalek-cryptography/curve25519-dalek/tree/main/ed25519-dalek

## ed25519-zebra 4.2.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/ZcashFoundation/ed25519-zebra

## either 1.16.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rayon-rs/either

## elliptic-curve 0.13.8

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/traits/tree/master/elliptic-curve

## embed_plist 1.2.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/nvzqz/embed-plist-rs

## env_filter 1.0.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-cli/env_logger

## env_logger 0.11.10

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-cli/env_logger

## equivalent 1.0.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/indexmap-rs/equivalent

## erased-serde 0.4.10

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/erased-serde

## errno 0.3.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/lambda-fairy/rust-errno

## event-listener 5.4.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/event-listener

## event-listener-strategy 0.5.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/event-listener-strategy

## eventsource-stream 0.2.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jpopesculian/eventsource-stream

## fallible-iterator 0.3.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sfackler/rust-fallible-iterator

## fastbloom 0.14.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/tomtomwombat/fastbloom/

## fastdivide 0.4.2

- Licence: `zlib-acknowledgement OR MIT`
- Source: https://github.com/fulmicoton/fastdivide

## fastrand 2.4.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/fastrand

## fdeflate 0.3.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/image-rs/fdeflate

## ff 0.13.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/zkcrypto/ff

## filetime 0.2.29

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/alexcrichton/filetime

## flate2 1.1.10

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/flate2-rs

## fnv 1.0.7

- Licence: `Apache-2.0 / MIT`
- Source: https://github.com/servo/rust-fnv

## foldhash 0.2.0

- Licence: `Zlib`
- Source: https://github.com/orlp/foldhash

## foreign-types 0.5.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sfackler/foreign-types

## foreign-types-macros 0.2.3

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sfackler/foreign-types

## foreign-types-shared 0.3.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sfackler/foreign-types

## form_urlencoded 1.2.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-url

## fs4 0.13.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/al8n/fs4-rs

## futures 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-channel 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-core 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-executor 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-io 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-macro 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-sink 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-task 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## futures-timer 3.0.4

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/async-rs/futures-timer

## futures-util 0.3.34

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/futures-rs

## genawaiter 0.99.1

- Licence: `MIT`
- Source: https://github.com/whatisaphone/genawaiter

## genawaiter-macro 0.99.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/whatisaphone/genawaiter

## generic-array 0.14.7

- Licence: `MIT`
- Source: https://github.com/fizyk20/generic-array.git

## getrandom 0.2.17

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/getrandom

## getrandom 0.3.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/getrandom

## getrandom 0.4.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/getrandom

## ghash 0.5.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/universal-hashes

## glob 0.3.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/glob

## group 0.13.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/zkcrypto/group

## h2 0.4.16

- Licence: `MIT`
- Source: https://github.com/hyperium/h2

## hashbrown 0.12.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/hashbrown

## hashbrown 0.14.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/hashbrown

## hashbrown 0.16.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/hashbrown

## hashbrown 0.17.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/hashbrown

## heck 0.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/withoutboats/heck

## hex 0.4.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/KokaKiwi/rust-hex

## hkdf 0.12.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/KDFs/

## hmac 0.12.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/MACs

## html5ever 0.38.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## htmlescape 0.3.1

- Licence: `Apache-2.0 / MIT / MPL-2.0`
- Source: https://github.com/veddan/rust-htmlescape

## http 1.4.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/hyperium/http

## http-body 1.0.1

- Licence: `MIT`
- Source: https://github.com/hyperium/http-body

## http-body-util 0.1.5

- Licence: `MIT`
- Source: https://github.com/hyperium/http-body

## httparse 1.10.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/seanmonstar/httparse

## httpdate 1.0.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/pyfisch/httpdate

## hybrid-array 0.4.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/hybrid-array

## hyper 1.11.1

- Licence: `MIT`
- Source: https://github.com/hyperium/hyper

## hyper-rustls 0.27.9

- Licence: `Apache-2.0 OR ISC OR MIT`
- Source: https://github.com/rustls/hyper-rustls

## hyper-util 0.1.20

- Licence: `MIT`
- Source: https://github.com/hyperium/hyper-util

## iana-time-zone 0.1.65

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/strawlab/iana-time-zone

## ico 0.5.0

- Licence: `MIT`
- Source: https://github.com/mdsteele/rust-ico

## icu_collator 2.2.1

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_collator_data 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_collections 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_locale 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_locale_core 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_locale_data 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_normalizer 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_normalizer_data 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_properties 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_properties_data 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## icu_provider 2.2.0

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## ident_case 1.0.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/TedDriggs/ident_case

## idna 1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-url/

## idna_adapter 1.2.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/hsivonen/idna_adapter

## indexmap 1.9.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/bluss/indexmap

## indexmap 2.14.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/indexmap-rs/indexmap

## infer 0.19.0

- Licence: `MIT`
- Source: https://github.com/bojand/infer

## Inflector 0.11.4

- Licence: `BSD-2-Clause`
- Source: https://github.com/whatisinternet/inflector

## inout 0.1.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## inout 0.2.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## intrusive-collections 0.9.7

- Licence: `Apache-2.0/MIT`
- Source: https://github.com/Amanieu/intrusive-rs

## inventory 0.3.24

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/inventory

## iota_stronghold 2.1.0

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/stronghold.rs

## iota-crypto 0.23.2

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/crypto.rs

## ipnet 2.12.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/krisprice/ipnet

## iterator-sorted 0.1.0

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/common-rs

## itertools 0.10.5

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/rust-itertools/itertools

## itertools 0.14.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-itertools/itertools

## itoa 1.0.18

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/itoa

## jiff 0.2.35

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/jiff

## jiff-core 0.1.0

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/jiff

## jiff-tzdb 0.1.8

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/jiff

## json-patch 3.0.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/idubrov/json-patch

## jsonptr 0.6.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/chanced/jsonptr

## k256 0.13.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/elliptic-curves/tree/master/k256

## keyboard-types 0.7.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/pyfisch/keyboard-types

## keyring 4.2.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/open-source-cooperative/keyring-rs

## keyring-core 1.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/open-source-cooperative/keyring-core.git

## lazy_static 1.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang-nursery/lazy-static.rs

## levenshtein_automata 0.2.1

- Licence: `MIT`
- Source: https://github.com/tantivy-search/levenshtein-automata

## libc 0.2.189

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/libc

## libloading 0.8.9

- Licence: `ISC`
- Source: https://github.com/nagisa/rust_libloading/

## libm 0.2.16

- Licence: `MIT`
- Source: https://github.com/rust-lang/compiler-builtins

## libmimalloc-sys 0.1.49

- Licence: `MIT`
- Source: https://github.com/purpleprotocol/mimalloc_rust/tree/master/libmimalloc-sys

## libsodium-sys-stable 1.24.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jedisct1/libsodium-sys-stable

## litemap 0.8.2

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## lock_api 0.4.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Amanieu/parking_lot

## log 0.4.32

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/log

## lru 0.16.4

- Licence: `MIT`
- Source: https://github.com/jeromefroe/lru-rs.git

## lru-slab 0.1.2

- Licence: `MIT OR Apache-2.0 OR Zlib`
- Source: https://github.com/Ralith/lru-slab

## lz4_flex 0.13.1

- Licence: `MIT`
- Source: https://github.com/pseitz/lz4_flex

## markup5ever 0.38.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## matchers 0.2.0

- Licence: `MIT`
- Source: https://github.com/hawkw/matchers

## measure_time 0.9.0

- Licence: `MIT`
- Source: https://github.com/PSeitz/rust_measure_time

## memchr 2.8.2

- Licence: `Unlicense OR MIT`
- Source: https://github.com/BurntSushi/memchr

## memmap2 0.9.11

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RazrFalcon/memmap2-rs

## memoffset 0.6.5

- Licence: `MIT`
- Source: https://github.com/Gilnaa/memoffset

## memoffset 0.9.1

- Licence: `MIT`
- Source: https://github.com/Gilnaa/memoffset

## miette 7.6.0

- Licence: `Apache-2.0`
- Source: https://github.com/zkat/miette

## miette-derive 7.6.0

- Licence: `Apache-2.0`
- Source: https://github.com/zkat/miette

## mimalloc 0.1.52

- Licence: `MIT`
- Source: https://github.com/purpleprotocol/mimalloc_rust

## mime 0.3.17

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/hyperium/mime

## mime_guess 2.0.5

- Licence: `MIT`
- Source: https://github.com/abonander/mime_guess

## minimal-lexical 0.2.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/Alexhuszagh/minimal-lexical

## minisign-verify 0.2.5

- Licence: `MIT`
- Source: https://github.com/jedisct1/rust-minisign-verify

## miniz_oxide 0.8.9

- Licence: `MIT OR Zlib OR Apache-2.0`
- Source: https://github.com/Frommi/miniz_oxide/tree/master/miniz_oxide

## miniz_oxide 0.9.1

- Licence: `MIT OR Zlib OR Apache-2.0`
- Source: https://github.com/Frommi/miniz_oxide/tree/master/miniz_oxide

## mio 1.2.1

- Licence: `MIT`
- Source: https://github.com/tokio-rs/mio

## muda 0.19.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/muda

## murmurhash32 0.3.1

- Licence: `MIT`
- Source: https://github.com/quickwit-inc/murmurhash32

## nanoid 0.4.0

- Licence: `MIT`
- Source: https://github.com/nikolay-govorov/nanoid.git

## new_debug_unreachable 1.0.6

- Licence: `MIT`
- Source: https://github.com/mbrubeck/rust-debug-unreachable

## nix 0.24.3

- Licence: `MIT`
- Source: https://github.com/nix-rust/nix

## nom 7.1.3

- Licence: `MIT`
- Source: https://github.com/Geal/nom

## nu-ansi-term 0.50.3

- Licence: `MIT`
- Source: https://github.com/nushell/nu-ansi-term

## num-bigint 0.4.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-bigint

## num-bigint-dig 0.8.6

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/dignifiedquire/num-bigint

## num-conv 0.2.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jhpratt/num-conv

## num-integer 0.1.46

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-integer

## num-iter 0.1.45

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-iter

## num-traits 0.2.19

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-num/num-traits

## oauth2 5.0.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/ramosbugs/oauth2-rs

## objc2 0.6.4

- Licence: `MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-app-kit 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-core-foundation 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-core-graphics 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-encode 4.1.0

- Licence: `MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-exception-helper 0.1.1

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-foundation 0.3.2

- Licence: `MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-io-surface 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-osa-kit 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## objc2-web-kit 0.3.2

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/madsmtm/objc2

## once_cell 1.21.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/matklad/once_cell

## oneshot 0.1.13

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/faern/oneshot

## opaque-debug 0.3.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/utils

## open 5.3.5

- Licence: `MIT`
- Source: https://github.com/Byron/open-rs

## openidconnect 4.0.1

- Licence: `MIT`
- Source: https://github.com/ramosbugs/openidconnect-rs

## option-ext 0.2.0

- Licence: `MPL-2.0`
- Source: https://github.com/soc/option-ext.git

## ordered-float 2.10.1

- Licence: `MIT`
- Source: https://github.com/reem/rust-ordered-float

## ordered-float 5.3.0

- Licence: `MIT`
- Source: https://github.com/reem/rust-ordered-float

## osakit 0.3.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/mdevils/rust-osakit

## ownedbytes 0.9.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## p256 0.13.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/elliptic-curves/tree/master/p256

## p384 0.13.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/elliptic-curves/tree/master/p384

## pack1 1.1.0

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/pack1

## parking 2.2.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/parking

## parking_lot 0.12.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Amanieu/parking_lot

## parking_lot_core 0.9.12

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Amanieu/parking_lot

## paste 1.0.15

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/paste

## pastey 0.2.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/as1100k/pastey

## pathdiff 0.2.3

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/Manishearth/pathdiff

## pbkdf2 0.12.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/password-hashes/tree/master/pbkdf2

## pem-rfc7468 0.7.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/pem-rfc7468

## percent-encoding 2.3.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-url/

## phf 0.13.1

- Licence: `MIT`
- Source: https://github.com/rust-phf/rust-phf

## phf_generator 0.13.1

- Licence: `MIT`
- Source: https://github.com/rust-phf/rust-phf

## phf_macros 0.13.1

- Licence: `MIT`
- Source: https://github.com/rust-phf/rust-phf

## phf_shared 0.13.1

- Licence: `MIT`
- Source: https://github.com/rust-phf/rust-phf

## pin-project 1.1.13

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/taiki-e/pin-project

## pin-project-internal 1.1.13

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/taiki-e/pin-project

## pin-project-lite 0.2.17

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/taiki-e/pin-project-lite

## pkcs1 0.7.5

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/pkcs1

## pkcs8 0.10.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/pkcs8

## plist 1.10.0

- Licence: `MIT`
- Source: https://github.com/ebarnard/rust-plist/

## png 0.17.16

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/image-rs/image-png

## png 0.18.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/image-rs/image-png

## polling 3.11.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/smol-rs/polling

## poly1305 0.8.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/universal-hashes

## polyval 0.6.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/universal-hashes

## potential_utf 0.1.5

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## powerfmt 0.2.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jhpratt/powerfmt

## ppv-lite86 0.2.21

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/cryptocorrosion/cryptocorrosion

## precomputed-hash 0.1.1

- Licence: `MIT`
- Source: https://github.com/emilio/precomputed-hash

## prettyplease 0.2.37

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/prettyplease

## primeorder 0.13.6

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/elliptic-curves/tree/master/primeorder

## proc-macro2 1.0.106

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/proc-macro2

## prost 0.14.4

- Licence: `Apache-2.0`
- Source: https://github.com/tokio-rs/prost

## prost-derive 0.14.4

- Licence: `Apache-2.0`
- Source: https://github.com/tokio-rs/prost

## quick-xml 0.41.0

- Licence: `MIT`
- Source: https://github.com/tafia/quick-xml

## quinn 0.11.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/quinn-rs/quinn

## quinn-proto 0.11.15

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/quinn-rs/quinn

## quinn-udp 0.5.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/quinn-rs/quinn

## quote 1.0.45

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/quote

## rand 0.10.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand 0.8.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand 0.9.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand_chacha 0.3.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand_chacha 0.9.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand_core 0.10.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand_core

## rand_core 0.6.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rand_core 0.9.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-random/rand

## rapidhash 4.4.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/hoxxep/rapidhash

## raw-window-handle 0.6.2

- Licence: `MIT OR Apache-2.0 OR Zlib`
- Source: https://github.com/rust-windowing/raw-window-handle

## rayon 1.12.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rayon-rs/rayon

## rayon-core 1.13.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rayon-rs/rayon

## ref-cast 1.0.25

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/ref-cast

## ref-cast-impl 1.0.25

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/ref-cast

## regex 1.12.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/regex

## regex-automata 0.4.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/regex

## regex-syntax 0.8.11

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/regex

## reqwest 0.12.28

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/seanmonstar/reqwest

## reqwest 0.13.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/seanmonstar/reqwest

## rfc6979 0.4.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/signatures/tree/master/rfc6979

## rfd 0.16.0

- Licence: `MIT`
- Source: https://github.com/PolyMeilex/rfd

## rig-core 0.39.0

- Licence: `MIT`
- Source: https://github.com/0xPlaygrounds/rig

## ring 0.17.14

- Licence: `Apache-2.0 AND ISC`
- Source: https://github.com/briansmith/ring

## roaring 0.11.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RoaringBitmap/roaring-rs

## rsa 0.9.10

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/RSA

## rust-argon2 1.0.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sru-systems/rust-argon2

## rust-argon2 2.1.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/sru-systems/rust-argon2

## rust-stemmers 1.2.0

- Licence: `MIT/BSD-3-Clause`
- Source: https://github.com/CurrySoftware/rust-stemmers

## rustc-hash 2.1.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/rust-lang/rustc-hash

## rustix 1.1.4

- Licence: `Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT`
- Source: https://github.com/bytecodealliance/rustix

## rustls 0.23.45

- Licence: `Apache-2.0 OR ISC OR MIT`
- Source: https://github.com/rustls/rustls

## rustls-native-certs 0.8.4

- Licence: `Apache-2.0 OR ISC OR MIT`
- Source: https://github.com/rustls/rustls-native-certs

## rustls-pki-types 1.14.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rustls/pki-types

## rustls-platform-verifier 0.7.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rustls/rustls-platform-verifier

## rustls-webpki 0.103.15

- Licence: `ISC`
- Source: https://github.com/rustls/webpki

## rustversion 1.0.22

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/rustversion

## ryu 1.0.23

- Licence: `Apache-2.0 OR BSL-1.0`
- Source: https://github.com/dtolnay/ryu

## salsa20 0.10.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/stream-ciphers

## same-file 1.0.6

- Licence: `Unlicense/MIT`
- Source: https://github.com/BurntSushi/same-file

## schemars 0.8.22

- Licence: `MIT`
- Source: https://github.com/GREsau/schemars

## schemars 0.9.0

- Licence: `MIT`
- Source: https://github.com/GREsau/schemars

## schemars 1.2.2

- Licence: `MIT`
- Source: https://github.com/GREsau/schemars

## schemars_derive 0.8.22

- Licence: `MIT`
- Source: https://github.com/GREsau/schemars

## schemars_derive 1.2.2

- Licence: `MIT`
- Source: https://github.com/GREsau/schemars

## scopeguard 1.2.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/bluss/scopeguard

## scrypt 0.11.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/password-hashes/tree/master/scrypt

## sec1 0.7.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/sec1

## security-framework 3.7.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/kornelski/rust-security-framework

## security-framework-sys 2.17.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/kornelski/rust-security-framework

## selectors 0.36.1

- Licence: `MPL-2.0`
- Source: https://github.com/servo/stylo

## semver 1.0.28

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/semver

## serde 1.0.229

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/serde

## serde_core 1.0.229

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/serde

## serde_derive 1.0.229

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/serde

## serde_derive_internals 0.29.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/serde

## serde_derive_internals 0.30.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/serde

## serde_json 1.0.151

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/serde-rs/json

## serde_path_to_error 0.1.20

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/path-to-error

## serde_plain 1.0.2

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/mitsuhiko/serde-plain

## serde_repr 0.1.20

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/serde-repr

## serde_spanned 1.1.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## serde_urlencoded 0.7.1

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/nox/serde_urlencoded

## serde_with 3.21.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jonasbb/serde_with/

## serde_with_macros 3.21.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/jonasbb/serde_with/

## serde-untagged 0.1.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/serde-untagged

## serde-value 0.7.0

- Licence: `MIT`
- Source: https://github.com/arcnmx/serde-value

## serialize-to-javascript 0.1.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/chippers/serialize-to-javascript

## serialize-to-javascript-impl 0.1.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/chippers/serialize-to-javascript

## servo_arc 0.4.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/stylo

## sha1 0.11.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/hashes

## sha1_smol 1.0.1

- Licence: `BSD-3-Clause`
- Source: https://github.com/mitsuhiko/sha1-smol

## sha2 0.10.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/hashes

## sha2 0.11.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/hashes

## sharded-slab 0.1.7

- Licence: `MIT`
- Source: https://github.com/hawkw/sharded-slab

## signal-hook-registry 1.4.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/vorner/signal-hook

## signature 2.2.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/traits/tree/master/signature

## simd-adler32 0.3.9

- Licence: `MIT`
- Source: https://github.com/mcountryman/simd-adler32

## simsimd 6.5.16

- Licence: `Apache-2.0`
- Source: https://github.com/ashvardanian/SimSIMD

## siphasher 1.0.3

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/jedisct1/rust-siphash

## sketches-ddsketch 0.4.0

- Licence: `Apache-2.0`
- Source: https://github.com/mheffner/rust-sketches-ddsketch

## slab 0.4.12

- Licence: `MIT`
- Source: https://github.com/tokio-rs/slab

## smallstr 0.3.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/murarth/smallstr

## smallvec 1.15.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-smallvec

## socket2 0.6.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rust-lang/socket2

## softaes 0.1.5

- Licence: `MIT`
- Source: https://github.com/jedisct1/rust-softaes

## specta 2.0.0-rc.22

- Licence: `MIT`
- Source: https://github.com/oscartbeaumont/specta

## specta-macros 2.0.0-rc.18

- Licence: `MIT`
- Source: https://github.com/oscartbeaumont/specta

## specta-serde 0.0.9

- Licence: `MIT`
- Source: https://github.com/oscartbeaumont/specta

## specta-typescript 0.0.9

- Licence: `MIT`
- Source: https://github.com/oscartbeaumont/specta

## spin 0.9.8

- Licence: `MIT`
- Source: https://github.com/mvdnes/spin-rs.git

## spki 0.7.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/formats/tree/master/spki

## stable_deref_trait 1.2.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/storyyeller/stable_deref_trait

## string_cache 0.9.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/string-cache

## stronghold_engine 2.0.1

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/stronghold.rs

## stronghold-derive 1.0.0

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/stronghold.rs

## stronghold-runtime 2.0.1

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/stronghold.rs

## stronghold-utils 1.0.0

- Licence: `Apache-2.0`
- Source: https://github.com/iotaledger/stronghold.rs

## strsim 0.11.1

- Licence: `MIT`
- Source: https://github.com/rapidfuzz/strsim-rs

## strum 0.26.3

- Licence: `MIT`
- Source: https://github.com/Peternator7/strum

## strum_macros 0.26.4

- Licence: `MIT`
- Source: https://github.com/Peternator7/strum

## subtle 2.6.1

- Licence: `BSD-3-Clause`
- Source: https://github.com/dalek-cryptography/subtle

## swift-rs 1.0.7

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Brendonovich/swift-rs

## symlink 0.1.0

- Licence: `MIT/Apache-2.0`
- Source: https://gitlab.com/chris-morgan/symlink

## syn 1.0.109

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/syn

## syn 2.0.118

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/syn

## syn 3.0.2

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/syn

## sync_wrapper 1.0.2

- Licence: `Apache-2.0`
- Source: https://github.com/Actyx/sync_wrapper

## synstructure 0.13.2

- Licence: `MIT`
- Source: https://github.com/mystor/synstructure

## system-configuration 0.7.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/mullvad/system-configuration-rs

## system-configuration-sys 0.6.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/mullvad/system-configuration-rs

## tantivy 0.26.1

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-bitpacker 0.10.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-columnar 0.7.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-common 0.11.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-fst 0.5.0

- Licence: `Unlicense/MIT`
- Source: https://github.com/quickwit-inc/fst

## tantivy-query-grammar 0.26.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-sstable 0.7.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-stacker 0.7.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tantivy-tokenizer-api 0.7.0

- Licence: `MIT`
- Source: https://github.com/quickwit-oss/tantivy

## tao 0.35.3

- Licence: `Apache-2.0`
- Source: https://github.com/tauri-apps/tao

## tar 0.4.46

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/composefs/tar-rs

## tauri 2.11.5

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri

## tauri-codegen 2.6.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri

## tauri-macros 2.6.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri

## tauri-plugin-dialog 2.7.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-plugin-fs 2.5.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-plugin-opener 2.5.5

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-plugin-process 2.3.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-plugin-stronghold 2.3.2

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-plugin-updater 2.11.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/plugins-workspace

## tauri-runtime 2.11.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri

## tauri-runtime-wry 2.11.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri

## tauri-specta 2.0.0-rc.21

- Licence: `MIT`
- Source: https://github.com/oscartbeaumont/tauri-specta

## tauri-specta-macros 2.0.0-rc.16

- Licence: `MIT`
- Source: https://github.com/oscartbeaumont/tauri-specta

## tauri-utils 2.9.3

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri

## tempfile 3.27.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Stebalien/tempfile

## tendril 0.5.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## thiserror 1.0.69

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/thiserror

## thiserror 2.0.20

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/thiserror

## thiserror-impl 1.0.69

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/thiserror

## thiserror-impl 2.0.20

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/thiserror

## thread_local 1.1.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Amanieu/thread_local-rs

## time 0.3.55

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/time-rs/time

## time-core 0.1.9

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/time-rs/time

## time-macros 0.2.32

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/time-rs/time

## tiny-keccak 2.0.2

- Licence: `CC0-1.0`
- Source: https://github.com/debris/tiny-keccak

## tinystr 0.8.3

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## tinyvec 1.11.0

- Licence: `Zlib OR Apache-2.0 OR MIT`
- Source: https://github.com/Lokathor/tinyvec

## tinyvec_macros 0.1.1

- Licence: `MIT OR Apache-2.0 OR Zlib`
- Source: https://github.com/Soveu/tinyvec_macros

## tokio 1.53.1

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tokio

## tokio-macros 2.7.0

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tokio

## tokio-rustls 0.26.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/rustls/tokio-rustls

## tokio-tungstenite 0.30.0

- Licence: `MIT`
- Source: https://github.com/snapview/tokio-tungstenite

## tokio-util 0.7.18

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tokio

## toml 1.1.2+spec-1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml_datetime 1.1.1+spec-1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml_parser 1.1.2+spec-1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## toml_writer 1.1.1+spec-1.1.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/toml-rs/toml

## tower 0.5.3

- Licence: `MIT`
- Source: https://github.com/tower-rs/tower

## tower-http 0.6.11

- Licence: `MIT`
- Source: https://github.com/tower-rs/tower-http

## tower-layer 0.3.3

- Licence: `MIT`
- Source: https://github.com/tower-rs/tower

## tower-service 0.3.3

- Licence: `MIT`
- Source: https://github.com/tower-rs/tower

## tracing 0.1.44

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-appender 0.2.5

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-attributes 0.1.31

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-core 0.1.36

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-futures 0.2.5

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-log 0.2.0

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-serde 0.2.0

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tracing-subscriber 0.3.23

- Licence: `MIT`
- Source: https://github.com/tokio-rs/tracing

## tray-icon 0.24.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/tauri-apps/tray-icon

## try-lock 0.2.5

- Licence: `MIT`
- Source: https://github.com/seanmonstar/try-lock

## tungstenite 0.30.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/snapview/tungstenite-rs

## turso 0.7.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_core 0.7.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_ext 0.7.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_macros 0.7.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_parser 0.7.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_sdk_kit 0.7.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_sdk_kit_macros 0.7.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_sync_engine 0.7.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## turso_sync_sdk_kit 0.7.2

- Licence: `MIT`
- Source: https://github.com/tursodatabase/turso

## twox-hash 2.1.2

- Licence: `MIT`
- Source: https://github.com/shepmaster/twox-hash

## typeid 1.0.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/typeid

## typenum 1.20.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/paholg/typenum

## typetag 0.2.22

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/typetag

## typetag-impl 0.2.22

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/dtolnay/typetag

## uncased 0.9.10

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/SergioBenitez/uncased

## unic-char-property 0.9.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/open-i18n/rust-unic/

## unic-char-range 0.9.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/open-i18n/rust-unic/

## unic-common 0.9.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/open-i18n/rust-unic/

## unic-ucd-ident 0.9.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/open-i18n/rust-unic/

## unic-ucd-version 0.9.0

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/open-i18n/rust-unic/

## unicase 2.9.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/seanmonstar/unicase

## unicode-ident 1.0.24

- Licence: `(MIT OR Apache-2.0) AND Unicode-3.0`
- Source: https://github.com/dtolnay/unicode-ident

## unicode-normalization 0.1.25

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/unicode-rs/unicode-normalization

## unicode-segmentation 1.13.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/unicode-rs/unicode-segmentation

## unicode-width 0.1.14

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/unicode-rs/unicode-width

## universal-hash 0.5.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/RustCrypto/traits

## untrusted 0.9.0

- Licence: `ISC`
- Source: https://github.com/briansmith/untrusted

## url 2.5.8

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/rust-url

## urlpattern 0.3.0

- Licence: `MIT`
- Source: https://github.com/denoland/rust-urlpattern

## utf-8 0.7.6

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/SimonSapin/rust-utf8

## utf16_iter 1.0.5

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/hsivonen/utf16_iter

## utf8_iter 1.0.4

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/hsivonen/utf8_iter

## utf8-ranges 1.0.5

- Licence: `Unlicense/MIT`
- Source: https://github.com/BurntSushi/utf8-ranges

## uuid 1.26.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/uuid-rs/uuid

## walkdir 2.5.0

- Licence: `Unlicense/MIT`
- Source: https://github.com/BurntSushi/walkdir

## want 0.3.1

- Licence: `MIT`
- Source: https://github.com/seanmonstar/want

## web_atoms 0.2.5

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/servo/html5ever

## webpki-roots 0.26.11

- Licence: `CDLA-Permissive-2.0`
- Source: https://github.com/rustls/webpki-roots

## webpki-roots 1.0.9

- Licence: `CDLA-Permissive-2.0`
- Source: https://github.com/rustls/webpki-roots

## window-vibrancy 0.6.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri-plugin-vibrancy

## winnow 1.0.3

- Licence: `MIT`
- Source: https://github.com/winnow-rs/winnow

## write16 1.0.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/hsivonen/write16

## writeable 0.6.3

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## wry 0.55.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/wry

## x25519-dalek 2.0.1

- Licence: `BSD-3-Clause`
- Source: https://github.com/dalek-cryptography/curve25519-dalek/tree/main/x25519-dalek

## xattr 1.6.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/Stebalien/xattr

## yoke 0.8.3

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## yoke-derive 0.8.2

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## yrs 0.27.4

- Licence: `MIT`
- Source: https://github.com/y-crdt/y-crdt/

## zerocopy 0.8.52

- Licence: `BSD-2-Clause OR Apache-2.0 OR MIT`
- Source: https://github.com/google/zerocopy

## zerocopy-derive 0.8.52

- Licence: `BSD-2-Clause OR Apache-2.0 OR MIT`
- Source: https://github.com/google/zerocopy

## zerofrom 0.1.8

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zerofrom-derive 0.1.7

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zeroize 1.9.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/utils

## zeroize_derive 1.5.0

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/RustCrypto/utils

## zerotrie 0.2.4

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zerovec 0.11.6

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zerovec-derive 0.11.3

- Licence: `Unicode-3.0`
- Source: https://github.com/unicode-org/icu4x

## zlib-rs 0.6.7

- Licence: `Zlib`
- Source: https://github.com/trifectatechfoundation/zlib-rs

## zmij 1.0.21

- Licence: `MIT`
- Source: https://github.com/dtolnay/zmij

## zstd 0.13.3

- Licence: `MIT`
- Source: https://github.com/gyscos/zstd-rs

## zstd-safe 7.2.4

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/gyscos/zstd-rs

## zstd-sys 2.0.16+zstd.1.5.7

- Licence: `MIT/Apache-2.0`
- Source: https://github.com/gyscos/zstd-rs

## JavaScript dependencies

## @ag-ui/client 0.0.59

- Licence: `MIT`
- Source: https://github.com/ag-ui-protocol/ag-ui#readme

## @ag-ui/core 0.0.59

- Licence: `MIT`
- Source: https://github.com/ag-ui-protocol/ag-ui#readme

## @ag-ui/encoder 0.0.59

- Licence: `MIT`
- Source: https://github.com/ag-ui-protocol/ag-ui#readme

## @ag-ui/proto 0.0.59

- Licence: `MIT`
- Source: https://github.com/ag-ui-protocol/ag-ui#readme

## @bufbuild/protobuf 2.14.1

- Licence: `(Apache-2.0 AND BSD-3-Clause)`
- Source: https://protobufes.com/

## @dnd-kit/accessibility 3.1.1

- Licence: `MIT`
- Source: https://github.com/clauderic/dnd-kit#readme

## @dnd-kit/core 6.3.1

- Licence: `MIT`
- Source: https://github.com/clauderic/dnd-kit#readme

## @dnd-kit/sortable 10.0.0

- Licence: `MIT`
- Source: https://github.com/clauderic/dnd-kit#readme

## @dnd-kit/utilities 3.2.2

- Licence: `MIT`
- Source: https://github.com/clauderic/dnd-kit#readme

## @floating-ui/core 1.8.0

- Licence: `MIT`
- Source: https://floating-ui.com

## @floating-ui/dom 1.8.0

- Licence: `MIT`
- Source: https://floating-ui.com

## @floating-ui/utils 0.2.12

- Licence: `MIT`
- Source: https://floating-ui.com

## @protobuf-ts/protoc 2.11.1

- Licence: `Apache-2.0`
- Source: https://github.com/timostamm/protobuf-ts

## @radix-ui/primitive 1.1.4

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/primitive 1.1.7

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-compose-refs 1.1.3

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-compose-refs 1.1.5

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-context 1.1.4

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-dialog 1.1.17

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-dismissable-layer 1.1.19

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-focus-guards 1.1.4

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-focus-scope 1.1.10

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-id 1.1.2

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-portal 1.1.12

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-presence 1.1.6

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-primitive 2.1.10

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-primitive 2.1.6

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-slot 1.3.0

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-slot 1.3.3

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-use-callback-ref 1.1.2

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-use-callback-ref 1.1.4

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-use-controllable-state 1.2.3

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-use-effect-event 0.0.3

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-use-effect-event 0.0.5

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-use-layout-effect 1.1.2

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @radix-ui/react-use-layout-effect 1.1.4

- Licence: `MIT`
- Source: https://radix-ui.com/primitives

## @tauri-apps/api 2.11.1

- Licence: `Apache-2.0 OR MIT`
- Source: https://github.com/tauri-apps/tauri#readme

## @tauri-apps/plugin-dialog 2.7.3

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/tauri-apps/plugins-workspace#readme

## @tauri-apps/plugin-process 2.3.1

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/tauri-apps/plugins-workspace#readme

## @tauri-apps/plugin-updater 2.11.0

- Licence: `MIT OR Apache-2.0`
- Source: https://github.com/tauri-apps/plugins-workspace#readme

## @tiptap/core 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-blockquote 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-bold 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-bubble-menu 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-bullet-list 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-character-count 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-code 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-code-block 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-collaboration 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-document 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-dropcursor 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-floating-menu 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-gapcursor 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-hard-break 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-heading 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-horizontal-rule 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-italic 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-link 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-list 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-list-item 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-list-keymap 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-ordered-list 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-paragraph 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-placeholder 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-strike 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-text 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-text-align 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extension-underline 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/extensions 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/pm 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/react 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/starter-kit 3.31.3

- Licence: `MIT`
- Source: https://tiptap.dev

## @tiptap/y-tiptap 3.0.7

- Licence: `MIT`
- Source: https://github.com/ueberdosis/y-tiptap#readme

## @types/debug 4.1.13

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/debug

## @types/estree 1.0.9

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/estree

## @types/estree-jsx 1.0.5

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/estree-jsx

## @types/hast 3.0.5

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hast

## @types/mdast 4.0.4

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mdast

## @types/ms 2.1.0

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/ms

## @types/react 19.3.0

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react

## @types/react-dom 19.3.0

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-dom

## @types/unist 2.0.11

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/unist

## @types/unist 3.0.3

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/unist

## @types/use-sync-external-store 0.0.6

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/use-sync-external-store

## @types/uuid 10.0.0

- Licence: `MIT`
- Source: https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/uuid

## @ungap/structured-clone 1.3.2

- Licence: `ISC`
- Source: https://github.com/ungap/structured-clone#readme

## aria-hidden 1.2.6

- Licence: `MIT`
- Source: https://github.com/theKashey/aria-hidden#readme

## bail 2.0.2

- Licence: `MIT`
- Source: https://github.com/wooorm/bail#readme

## ccount 2.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/ccount#readme

## character-entities 2.0.2

- Licence: `MIT`
- Source: https://github.com/wooorm/character-entities#readme

## character-entities-html4 2.1.0

- Licence: `MIT`
- Source: https://github.com/wooorm/character-entities-html4#readme

## character-entities-legacy 3.0.0

- Licence: `MIT`
- Source: https://github.com/wooorm/character-entities-legacy#readme

## character-reference-invalid 2.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/character-reference-invalid#readme

## comma-separated-tokens 2.0.3

- Licence: `MIT`
- Source: https://github.com/wooorm/comma-separated-tokens#readme

## compare-versions 6.1.1

- Licence: `MIT`
- Source: https://github.com/omichelsen/compare-versions#readme

## csstype 3.2.3

- Licence: `MIT`
- Source: https://github.com/frenic/csstype#readme

## debug 4.4.3

- Licence: `MIT`
- Source: https://github.com/debug-js/debug#readme

## decode-named-character-reference 1.3.0

- Licence: `MIT`
- Source: https://github.com/wooorm/decode-named-character-reference#readme

## dequal 2.0.3

- Licence: `MIT`
- Source: https://github.com/lukeed/dequal#readme

## detect-node-es 1.1.0

- Licence: `MIT`
- Source: https://github.com/thekashey/detect-node

## devlop 1.1.0

- Licence: `MIT`
- Source: https://github.com/wooorm/devlop#readme

## estree-util-is-identifier-name 3.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/estree-util-is-identifier-name#readme

## extend 3.0.2

- Licence: `MIT`
- Source: https://github.com/justmoon/node-extend#readme

## fast-equals 5.4.2

- Licence: `MIT`
- Source: https://github.com/planttheidea/fast-equals#readme

## fast-json-patch 3.1.1

- Licence: `MIT`
- Source: https://github.com/Starcounter-Jack/JSON-Patch

## get-nonce 1.0.1

- Licence: `MIT`
- Source: https://github.com/theKashey/get-nonce

## hast-util-to-jsx-runtime 2.3.6

- Licence: `MIT`
- Source: https://github.com/syntax-tree/hast-util-to-jsx-runtime#readme

## hast-util-whitespace 3.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/hast-util-whitespace#readme

## html-url-attributes 3.0.1

- Licence: `MIT`
- Source: https://github.com/rehypejs/rehype-minify/tree/main#readme

## inline-style-parser 0.2.7

- Licence: `MIT`
- Source: https://github.com/remarkablemark/inline-style-parser#readme

## is-alphabetical 2.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/is-alphabetical#readme

## is-alphanumerical 2.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/is-alphanumerical#readme

## is-decimal 2.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/is-decimal#readme

## is-hexadecimal 2.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/is-hexadecimal#readme

## is-plain-obj 4.1.0

- Licence: `MIT`
- Source: https://github.com/sindresorhus/is-plain-obj#readme

## isomorphic.js 0.2.5

- Licence: `MIT`
- Source: https://github.com/dmonad/isomorphic.js#readme

## lib0 0.2.117

- Licence: `MIT`
- Source: https://github.com/dmonad/lib0#readme

## linkifyjs 4.3.3

- Licence: `MIT`
- Source: https://linkify.js.org

## longest-streak 3.1.0

- Licence: `MIT`
- Source: https://github.com/wooorm/longest-streak#readme

## mdast-util-from-markdown 2.0.3

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-from-markdown#readme

## mdast-util-mdx-expression 2.0.1

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-mdx-expression#readme

## mdast-util-mdx-jsx 3.2.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-mdx-jsx#readme

## mdast-util-mdxjs-esm 2.0.1

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-mdxjs-esm#readme

## mdast-util-phrasing 4.1.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-phrasing#readme

## mdast-util-to-hast 13.2.1

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-to-hast#readme

## mdast-util-to-markdown 2.1.2

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-to-markdown#readme

## mdast-util-to-string 4.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/mdast-util-to-string#readme

## micromark 4.0.2

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-core-commonmark 2.0.3

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-factory-destination 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-factory-label 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-factory-space 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-factory-title 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-factory-whitespace 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-character 2.1.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-chunked 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-classify-character 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-combine-extensions 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-decode-numeric-character-reference 2.0.2

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-decode-string 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-encode 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-html-tag-name 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-normalize-identifier 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-resolve-all 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-sanitize-uri 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-subtokenize 2.1.0

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-symbol 2.0.1

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## micromark-util-types 2.0.2

- Licence: `MIT`
- Source: https://github.com/micromark/micromark/tree/main#readme

## ms 2.1.3

- Licence: `MIT`
- Source: https://github.com/vercel/ms#readme

## orderedmap 2.1.1

- Licence: `MIT`
- Source: https://github.com/marijnh/orderedmap#readme

## parse-entities 4.0.2

- Licence: `MIT`
- Source: https://github.com/wooorm/parse-entities#readme

## property-information 7.2.0

- Licence: `MIT`
- Source: https://github.com/wooorm/property-information#readme

## prosemirror-changeset 2.4.2

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-changeset/v/2.4.2

## prosemirror-commands 1.7.2

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-commands/v/1.7.2

## prosemirror-dropcursor 1.8.3

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-dropcursor/v/1.8.3

## prosemirror-gapcursor 1.4.1

- Licence: `MIT`
- Source: https://github.com/prosemirror/prosemirror-gapcursor#readme

## prosemirror-history 1.5.0

- Licence: `MIT`
- Source: https://github.com/prosemirror/prosemirror-history#readme

## prosemirror-inputrules 1.5.1

- Licence: `MIT`
- Source: https://github.com/prosemirror/prosemirror-inputrules#readme

## prosemirror-keymap 1.2.3

- Licence: `MIT`
- Source: https://github.com/prosemirror/prosemirror-keymap#readme

## prosemirror-model 1.25.11

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-model/v/1.25.11

## prosemirror-schema-list 1.5.1

- Licence: `MIT`
- Source: https://github.com/prosemirror/prosemirror-schema-list#readme

## prosemirror-state 1.4.4

- Licence: `MIT`
- Source: https://github.com/prosemirror/prosemirror-state#readme

## prosemirror-tables 1.8.5

- Licence: `MIT`
- Source: https://github.com/ProseMirror/prosemirror-tables#readme

## prosemirror-transform 1.12.1

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-transform/v/1.12.1

## prosemirror-view 1.42.3

- Licence: `MIT`
- Source: https://www.npmjs.com/package/prosemirror-view/v/1.42.3

## react 19.3.0

- Licence: `MIT`
- Source: https://react.dev/

## react-dom 19.3.0

- Licence: `MIT`
- Source: https://react.dev/

## react-markdown 10.1.0

- Licence: `MIT`
- Source: https://github.com/remarkjs/react-markdown#readme

## react-remove-scroll 2.7.2

- Licence: `MIT`
- Source: https://github.com/theKashey/react-remove-scroll#readme

## react-remove-scroll-bar 2.3.8

- Licence: `MIT`
- Source: https://github.com/theKashey/react-remove-scroll-bar#readme

## react-style-singleton 2.2.3

- Licence: `MIT`
- Source: https://github.com/theKashey/react-style-singleton#readme

## remark-parse 11.0.0

- Licence: `MIT`
- Source: https://remark.js.org

## remark-rehype 11.1.2

- Licence: `MIT`
- Source: https://github.com/remarkjs/remark-rehype#readme

## rope-sequence 1.3.4

- Licence: `MIT`
- Source: https://github.com/marijnh/rope-sequence#readme

## rxjs 7.8.2

- Licence: `Apache-2.0`
- Source: https://rxjs.dev

## scheduler 0.28.0

- Licence: `MIT`
- Source: https://react.dev/

## space-separated-tokens 2.0.2

- Licence: `MIT`
- Source: https://github.com/wooorm/space-separated-tokens#readme

## stringify-entities 4.0.4

- Licence: `MIT`
- Source: https://github.com/wooorm/stringify-entities#readme

## style-to-js 1.1.21

- Licence: `MIT`
- Source: https://github.com/remarkablemark/style-to-js#readme

## style-to-object 1.0.14

- Licence: `MIT`
- Source: https://github.com/remarkablemark/style-to-object#readme

## supports-color 10.2.2

- Licence: `MIT`
- Source: https://github.com/chalk/supports-color#readme

## trim-lines 3.0.1

- Licence: `MIT`
- Source: https://github.com/wooorm/trim-lines#readme

## trough 2.2.0

- Licence: `MIT`
- Source: https://github.com/wooorm/trough#readme

## tslib 2.8.1

- Licence: `0BSD`
- Source: https://www.typescriptlang.org/

## unified 11.0.5

- Licence: `MIT`
- Source: https://unifiedjs.com

## unist-util-is 6.0.1

- Licence: `MIT`
- Source: https://github.com/syntax-tree/unist-util-is#readme

## unist-util-position 5.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/unist-util-position#readme

## unist-util-stringify-position 4.0.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/unist-util-stringify-position#readme

## unist-util-visit 5.1.0

- Licence: `MIT`
- Source: https://github.com/syntax-tree/unist-util-visit#readme

## unist-util-visit-parents 6.0.2

- Licence: `MIT`
- Source: https://github.com/syntax-tree/unist-util-visit-parents#readme

## untruncate-json 0.0.1

- Licence: `MIT`
- Source: https://github.com/dphilipson/untruncate-json

## use-callback-ref 1.3.3

- Licence: `MIT`
- Source: https://github.com/theKashey/use-callback-ref#readme

## use-sidecar 1.1.3

- Licence: `MIT`
- Source: https://github.com/theKashey/use-sidecar

## use-sync-external-store 1.7.0

- Licence: `MIT`
- Source: https://github.com/react/react#readme

## uuid 11.1.1

- Licence: `MIT`
- Source: https://github.com/uuidjs/uuid#readme

## vfile 6.0.3

- Licence: `MIT`
- Source: https://github.com/vfile/vfile#readme

## vfile-message 4.0.3

- Licence: `MIT`
- Source: https://github.com/vfile/vfile-message#readme

## w3c-keyname 2.2.8

- Licence: `MIT`
- Source: https://github.com/marijnh/w3c-keyname#readme

## y-prosemirror 1.3.7

- Licence: `MIT`
- Source: https://github.com/yjs/y-prosemirror#readme

## y-protocols 1.0.7

- Licence: `MIT`
- Source: https://github.com/yjs/y-protocols#readme

## yjs 13.6.32

- Licence: `MIT`
- Source: https://docs.yjs.dev

## zod 3.25.76

- Licence: `MIT`
- Source: https://zod.dev

## zustand 5.0.15

- Licence: `MIT`
- Source: https://github.com/pmndrs/zustand

## zwitch 2.0.4

- Licence: `MIT`
- Source: https://github.com/wooorm/zwitch#readme
